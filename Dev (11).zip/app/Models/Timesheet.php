<?php
/**
 * Weekly (and monthly) timesheets: matrix, submit, approve, reject.
 *
 * A timesheet is one user + one period. Submitting locks the week's time entries
 * into timesheet_entries. Approval locks them from employee edits; rejection
 * unlocks them and stores a feedback note.
 */

declare(strict_types=1);

final class Timesheet extends Model
{
    public const STATUS_DRAFT     = 'Draft';
    public const STATUS_SUBMITTED = 'Submitted';
    public const STATUS_APPROVED  = 'Approved';
    public const STATUS_REJECTED  = 'Rejected';

    public const STATUSES = [
        self::STATUS_DRAFT,
        self::STATUS_SUBMITTED,
        self::STATUS_APPROVED,
        self::STATUS_REJECTED,
    ];

    public const DAY_KEYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

    public const DAY_LABELS = [
        'mon' => 'Mon',
        'tue' => 'Tue',
        'wed' => 'Wed',
        'thu' => 'Thu',
        'fri' => 'Fri',
        'sat' => 'Sat',
        'sun' => 'Sun',
    ];

    protected string $table = 'timesheets';

    protected array $columns = [
        'id', 'user_id', 'start_date', 'end_date',
        'total_seconds', 'billable_seconds', 'status',
        'submitted_at', 'approved_by', 'approved_at', 'rejection_reason',
        'created_at', 'updated_at',
    ];

    protected array $fillable = [
        'user_id', 'start_date', 'end_date',
        'total_seconds', 'billable_seconds', 'status',
        'submitted_at', 'approved_by', 'approved_at', 'rejection_reason',
    ];

    /** True when the timesheets table has been installed. */
    public static function installed(): bool
    {
        static $installed = null;

        if ($installed === null) {
            try {
                $installed = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = 'timesheets'"
                ) > 0;
            } catch (Throwable) {
                $installed = false;
            }
        }

        return $installed;
    }

    /**
     * Pivot time entries by Project/Task across Monday-Sunday with daily and row totals.
     *
     * @return array{
     *     week_start: string,
     *     week_end: string,
     *     days: list<array{key: string, date: string, label: string, short: string, is_today: bool, is_weekend: bool}>,
     *     rows: list<array<string, mixed>>,
     *     column_totals: array<string, int>,
     *     column_billable: array<string, int>,
     *     grand_total: int,
     *     billable_total: int,
     *     entry_count: int,
     *     timesheet: array<string, mixed>|null
     * }
     */
    public function getWeeklyMatrix(int $userId, string $weekStartDate): array
    {
        $bounds = self::weekBounds($weekStartDate);
        $days   = $this->dayMeta($bounds['start_local']);

        $emptyDays = [];
        $columnTotals = [];
        $columnBillable = [];
        foreach ($days as $day) {
            $emptyDays[$day['key']] = 0;
            $columnTotals[$day['key']] = 0;
            $columnBillable[$day['key']] = 0;
        }

        $entries = $this->entriesInRange($userId, $bounds['start_utc'], $bounds['end_utc']);

        $grouped = [];
        $entryCount = 0;
        $grandTotal = 0;
        $billableTotal = 0;

        foreach ($entries as $entry) {
            $localDate = FormatHelper::datetime((string) $entry['start_time'], 'Y-m-d');
            $dayKey    = $this->dayKeyForDate($localDate, $days);
            if ($dayKey === null) {
                continue;
            }

            $seconds  = (int) $entry['duration_seconds'];
            $billable = (int) $entry['is_billable'] === 1 ? $seconds : 0;
            $projectId = (int) $entry['project_id'];
            $taskId    = (int) ($entry['task_id'] ?? 0);
            $rowKey    = $projectId . ':' . $taskId;

            if (!isset($grouped[$rowKey])) {
                $grouped[$rowKey] = [
                    'project_id'       => $projectId,
                    'project_name'     => (string) ($entry['project_name'] ?? ''),
                    'project_code'     => (string) ($entry['project_code'] ?? ''),
                    'task_id'          => $taskId > 0 ? $taskId : null,
                    'task_name'        => (string) ($entry['task_name'] ?? ''),
                    'days'             => $emptyDays,
                    'billable_days'    => $emptyDays,
                    'total_seconds'    => 0,
                    'billable_seconds' => 0,
                    'entry_count'      => 0,
                ];
            }

            $grouped[$rowKey]['days'][$dayKey]          += $seconds;
            $grouped[$rowKey]['billable_days'][$dayKey] += $billable;
            $grouped[$rowKey]['total_seconds']          += $seconds;
            $grouped[$rowKey]['billable_seconds']       += $billable;
            $grouped[$rowKey]['entry_count']++;

            $columnTotals[$dayKey]   += $seconds;
            $columnBillable[$dayKey] += $billable;
            $grandTotal              += $seconds;
            $billableTotal           += $billable;
            $entryCount++;
        }

        uasort($grouped, static function (array $a, array $b): int {
            $byProject = strcasecmp((string) $a['project_name'], (string) $b['project_name']);
            if ($byProject !== 0) {
                return $byProject;
            }

            return strcasecmp((string) $a['task_name'], (string) $b['task_name']);
        });

        return [
            'week_start'      => $bounds['start_local']->format('Y-m-d'),
            'week_end'        => $bounds['end_local']->format('Y-m-d'),
            'days'            => $days,
            'rows'            => array_values($grouped),
            'column_totals'   => $columnTotals,
            'column_billable' => $columnBillable,
            'grand_total'     => $grandTotal,
            'billable_total'  => $billableTotal,
            'entry_count'     => $entryCount,
            'timesheet'       => $this->findForPeriod($userId, $bounds['start_local']->format('Y-m-d'), $bounds['end_local']->format('Y-m-d')),
        ];
    }

    /**
     * Month overview: one row per week that overlaps the month.
     *
     * @return array{
     *     month_start: string,
     *     month_end: string,
     *     month_label: string,
     *     weeks: list<array<string, mixed>>,
     *     grand_total: int,
     *     billable_total: int
     * }
     */
    public function getMonthlyOverview(int $userId, string $monthStartDate): array
    {
        $zone  = new DateTimeZone(FormatHelper::displayTimezone());
        $month = DateTimeImmutable::createFromFormat('!Y-m-d', $monthStartDate, $zone);
        if ($month === false) {
            $month = new DateTimeImmutable('first day of this month', $zone);
        }
        $month = $month->modify('first day of this month')->setTime(0, 0, 0);
        $monthEnd = $month->modify('last day of this month')->setTime(23, 59, 59);

        $cursor = $month->modify('Monday this week')->setTime(0, 0, 0);
        $weeks  = [];
        $grand  = 0;
        $billable = 0;

        while ($cursor <= $monthEnd) {
            $matrix = $this->getWeeklyMatrix($userId, $cursor->format('Y-m-d'));
            $status = (string) (($matrix['timesheet']['status'] ?? '') ?: self::STATUS_DRAFT);
            $weeks[] = [
                'week_start'      => $matrix['week_start'],
                'week_end'        => $matrix['week_end'],
                'total_seconds'   => $matrix['grand_total'],
                'billable_seconds'=> $matrix['billable_total'],
                'entry_count'     => $matrix['entry_count'],
                'status'          => $status,
                'timesheet_id'    => isset($matrix['timesheet']['id']) ? (int) $matrix['timesheet']['id'] : 0,
                'in_month'        => $cursor->format('Y-m') === $month->format('Y-m')
                    || (new DateTimeImmutable($matrix['week_end'], $zone))->format('Y-m') === $month->format('Y-m'),
            ];
            $grand    += $matrix['grand_total'];
            $billable += $matrix['billable_total'];
            $cursor = $cursor->modify('+7 days');
        }

        return [
            'month_start'    => $month->format('Y-m-d'),
            'month_end'      => $monthEnd->format('Y-m-d'),
            'month_label'    => $month->format('F Y'),
            'weeks'          => $weeks,
            'grand_total'    => $grand,
            'billable_total' => $billable,
        ];
    }

    /**
     * Aggregate every time entry for the week, lock them into a timesheet, set Submitted.
     *
     * @return array<string, mixed>
     */
    public function submitWeek(int $userId, string $weekStartDate): array
    {
        if (!self::installed() || !TimeEntry::installed()) {
            throw new RuntimeException('Timesheets are not installed yet.');
        }

        $bounds    = self::weekBounds($weekStartDate);
        $startDate = $bounds['start_local']->format('Y-m-d');
        $endDate   = $bounds['end_local']->format('Y-m-d');

        return Database::transaction(function () use ($userId, $bounds, $startDate, $endDate): array {
            $existing = $this->findForPeriod($userId, $startDate, $endDate, true);

            if ($existing !== null) {
                $status = (string) $existing['status'];
                if ($status === self::STATUS_SUBMITTED) {
                    throw new RuntimeException('This week is already submitted and waiting for approval.');
                }
                if ($status === self::STATUS_APPROVED) {
                    throw new RuntimeException('This week is already approved and cannot be submitted again.');
                }
            }

            if (class_exists('Timer') && Timer::installed()) {
                $running = Database::fetchOne(
                    'SELECT id FROM active_timers WHERE user_id = :user_id LIMIT 1',
                    ['user_id' => $userId]
                );
                if ($running !== null) {
                    throw new RuntimeException('Stop your running timer before submitting this week.');
                }
            }

            $entries = $this->entriesInRange($userId, $bounds['start_utc'], $bounds['end_utc'], true);
            if ($entries === []) {
                throw new RuntimeException('There is no time to submit for this week.');
            }

            $total = 0;
            $billable = 0;
            $ids = [];
            foreach ($entries as $entry) {
                $id = (int) $entry['id'];
                if ($id < 1) {
                    continue;
                }
                $ids[] = $id;
                $seconds = (int) $entry['duration_seconds'];
                $total += $seconds;
                if ((int) $entry['is_billable'] === 1) {
                    $billable += $seconds;
                }

                $lockedElsewhere = Database::fetchOne(
                    'SELECT te.timesheet_id, t.status, t.start_date, t.end_date
                     FROM timesheet_entries te
                     INNER JOIN timesheets t ON t.id = te.timesheet_id
                     WHERE te.time_entry_id = :id
                       AND t.status IN (:submitted, :approved)
                       AND (t.user_id <> :user_id OR t.start_date <> :start_date OR t.end_date <> :end_date)
                     LIMIT 1',
                    [
                        'id'         => $id,
                        'submitted'  => self::STATUS_SUBMITTED,
                        'approved'   => self::STATUS_APPROVED,
                        'user_id'    => $userId,
                        'start_date' => $startDate,
                        'end_date'   => $endDate,
                    ]
                );
                if ($lockedElsewhere !== null) {
                    throw new RuntimeException('A time entry is already locked on another timesheet.');
                }
            }

            if ($ids === []) {
                throw new RuntimeException('There is no time to submit for this week.');
            }

            if ($existing === null) {
                $id = $this->create([
                    'user_id'          => $userId,
                    'start_date'       => $startDate,
                    'end_date'         => $endDate,
                    'total_seconds'    => $total,
                    'billable_seconds' => $billable,
                    'status'           => self::STATUS_SUBMITTED,
                    'submitted_at'     => gmdate('Y-m-d H:i:s'),
                    'approved_by'      => null,
                    'approved_at'      => null,
                    'rejection_reason' => null,
                ]);
            } else {
                $id = (int) $existing['id'];
                Database::execute(
                    'UPDATE timesheets
                     SET total_seconds = :total_seconds,
                         billable_seconds = :billable_seconds,
                         status = :status,
                         submitted_at = UTC_TIMESTAMP(),
                         approved_by = NULL,
                         approved_at = NULL,
                         rejection_reason = NULL,
                         updated_at = UTC_TIMESTAMP()
                     WHERE id = :id',
                    [
                        'total_seconds'    => $total,
                        'billable_seconds' => $billable,
                        'status'           => self::STATUS_SUBMITTED,
                        'id'               => $id,
                    ]
                );
                Database::execute(
                    'DELETE FROM timesheet_entries WHERE timesheet_id = :id',
                    ['id' => $id]
                );
            }

            foreach ($ids as $entryId) {
                Database::execute(
                    'INSERT INTO timesheet_entries (timesheet_id, time_entry_id, created_at)
                     VALUES (:timesheet_id, :time_entry_id, UTC_TIMESTAMP())',
                    ['timesheet_id' => $id, 'time_entry_id' => $entryId]
                );
            }

            $row = $this->findWithRelations($id);
            if ($row === null) {
                throw new RuntimeException('Timesheet could not be submitted.');
            }

            return $row;
        });
    }

    /**
     * Approve a submitted timesheet and lock the underlying time entries.
     *
     * @return array<string, mixed>
     */
    public function approve(int $timesheetId, int $approverId): array
    {
        if (!self::installed()) {
            throw new RuntimeException('Timesheets are not installed yet.');
        }

        return Database::transaction(function () use ($timesheetId, $approverId): array {
            $row = $this->lockRow($timesheetId);
            if ($row === null) {
                throw new RuntimeException('Timesheet was not found.');
            }

            if ((int) $row['user_id'] === $approverId
                && !AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
                throw new RuntimeException('You cannot approve your own timesheet.');
            }

            $status = (string) $row['status'];
            if ($status === self::STATUS_APPROVED) {
                throw new RuntimeException('This timesheet is already approved.');
            }
            if ($status !== self::STATUS_SUBMITTED) {
                throw new RuntimeException('Only submitted timesheets can be approved.');
            }

            Database::execute(
                'UPDATE timesheets
                 SET status = :status,
                     approved_by = :approved_by,
                     approved_at = UTC_TIMESTAMP(),
                     rejection_reason = NULL,
                     updated_at = UTC_TIMESTAMP()
                 WHERE id = :id',
                [
                    'status'      => self::STATUS_APPROVED,
                    'approved_by' => $approverId,
                    'id'          => $timesheetId,
                ]
            );

            $this->lockTimeEntries($timesheetId, $approverId);

            $updated = $this->findWithRelations($timesheetId);
            if ($updated === null) {
                throw new RuntimeException('Timesheet could not be approved.');
            }

            return $updated;
        });
    }

    /**
     * Reject a submitted timesheet with feedback and unlock entries for editing.
     *
     * @return array<string, mixed>
     */
    public function reject(int $timesheetId, int $approverId, string $reason): array
    {
        if (!self::installed()) {
            throw new RuntimeException('Timesheets are not installed yet.');
        }

        $reason = trim($reason);
        if ($reason === '') {
            throw new InvalidArgumentException('A rejection reason is required.');
        }
        $reason = mb_substr($reason, 0, 500, 'UTF-8');

        return Database::transaction(function () use ($timesheetId, $approverId, $reason): array {
            $row = $this->lockRow($timesheetId);
            if ($row === null) {
                throw new RuntimeException('Timesheet was not found.');
            }

            if ((int) $row['user_id'] === $approverId) {
                throw new RuntimeException('You cannot reject your own timesheet.');
            }

            $status = (string) $row['status'];
            if ($status === self::STATUS_APPROVED) {
                throw new RuntimeException('An approved timesheet cannot be rejected.');
            }
            if ($status !== self::STATUS_SUBMITTED) {
                throw new RuntimeException('Only submitted timesheets can be rejected.');
            }

            Database::execute(
                'UPDATE timesheets
                 SET status = :status,
                     approved_by = :approved_by,
                     approved_at = UTC_TIMESTAMP(),
                     rejection_reason = :reason,
                     updated_at = UTC_TIMESTAMP()
                 WHERE id = :id',
                [
                    'status'      => self::STATUS_REJECTED,
                    'approved_by' => $approverId,
                    'reason'      => $reason,
                    'id'          => $timesheetId,
                ]
            );

            $this->unlockTimeEntries($timesheetId);

            Database::execute(
                'DELETE FROM timesheet_entries WHERE timesheet_id = :id',
                ['id' => $timesheetId]
            );

            $updated = $this->findWithRelations($timesheetId);
            if ($updated === null) {
                throw new RuntimeException('Timesheet could not be rejected.');
            }

            return $updated;
        });
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findWithRelations(int $id): ?array
    {
        if ($id < 1 || !self::installed()) {
            return null;
        }

        return Database::fetchOne(
            $this->selectSql() . ' WHERE t.id = :id LIMIT 1',
            ['id' => $id]
        );
    }

    /**
     * @return array<string, mixed>|null
     */
    public function findForPeriod(int $userId, string $startDate, string $endDate, bool $forUpdate = false): ?array
    {
        if (!self::installed()) {
            return null;
        }

        $sql = $this->selectSql() . ' WHERE t.user_id = :user_id AND t.start_date = :start_date AND t.end_date = :end_date LIMIT 1';
        if ($forUpdate) {
            $sql = 'SELECT t.* FROM timesheets t
                    WHERE t.user_id = :user_id AND t.start_date = :start_date AND t.end_date = :end_date
                    LIMIT 1 FOR UPDATE';
        }

        return Database::fetchOne($sql, [
            'user_id'    => $userId,
            'start_date' => $startDate,
            'end_date'   => $endDate,
        ]);
    }

    /**
     * Submitted timesheets waiting for (or filtered by) approval.
     *
     * @param array{status?: string, user_id?: int, q?: string} $filters
     * @return array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int, counts: array<string, int>}
     */
    public function queueForApprover(int $approverId, bool $isAdmin, array $filters, int $page = 1, int $perPage = 25): array
    {
        $perPage = min(100, max(1, $perPage));
        [$whereSql, $params] = $this->queueWhere($approverId, $isAdmin, $filters);

        $total = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM timesheets t
             INNER JOIN users u ON u.id = t.user_id' . $whereSql,
            $params
        );

        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min(max(1, $page), $pages);

        $params['limit']  = $perPage;
        $params['offset'] = ($page - 1) * $perPage;

        $items = Database::fetchAll(
            $this->selectSql() . $whereSql . '
             ORDER BY t.submitted_at DESC, t.id DESC
             LIMIT :limit OFFSET :offset',
            $params
        );

        return [
            'items'    => $items,
            'total'    => $total,
            'page'     => $page,
            'per_page' => $perPage,
            'pages'    => $pages,
            'counts'   => $this->queueCounts($approverId, $isAdmin),
        ];
    }

    /**
     * @return array<string, int>
     */
    public function queueCounts(int $approverId, bool $isAdmin): array
    {
        [$scopeSql, $scopeParams] = $this->approverScope($approverId, $isAdmin);

        $rows = Database::fetchAll(
            'SELECT t.status, COUNT(*) AS total
             FROM timesheets t
             INNER JOIN users u ON u.id = t.user_id
             WHERE ' . $scopeSql . '
             GROUP BY t.status',
            $scopeParams
        );

        $counts = [
            'Submitted' => 0,
            'Approved'  => 0,
            'Rejected'  => 0,
            'Draft'     => 0,
            'all'       => 0,
        ];
        foreach ($rows as $row) {
            $status = (string) $row['status'];
            $total  = (int) $row['total'];
            $counts[$status] = $total;
            $counts['all']  += $total;
        }

        return $counts;
    }

    /**
     * Time entries locked into a timesheet, with relations.
     *
     * @return list<array<string, mixed>>
     */
    public function entriesFor(int $timesheetId): array
    {
        if (!self::installed() || !TimeEntry::installed()) {
            return [];
        }

        $startCol   = TimeEntry::column('start_time') ?? 'id';
        $endCol     = TimeEntry::column('end_time');
        $durationCol = TimeEntry::column('duration_seconds');
        $breakCol   = TimeEntry::column('break_minutes');
        $descCol    = TimeEntry::column('description');
        $billableCol = TimeEntry::column('is_billable');
        $rateCol    = TimeEntry::column('billable_rate');
        $statusCol  = TimeEntry::column('status');
        $useTasks   = Task::installed();
        $taskSelect = $useTasks ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = $useTasks ? 'LEFT JOIN tasks tk ON tk.id = te.task_id' : '';

        $endSelect      = $endCol !== null ? "te.`{$endCol}` AS end_time" : 'NULL AS end_time';
        $durationSelect = $durationCol !== null ? "te.`{$durationCol}` AS duration_seconds" : '0 AS duration_seconds';
        $breakSelect    = $breakCol !== null ? "te.`{$breakCol}` AS break_minutes" : '0 AS break_minutes';
        $descSelect     = $descCol !== null ? "te.`{$descCol}` AS description" : 'NULL AS description';
        $billableSelect = $billableCol !== null ? "te.`{$billableCol}` AS is_billable" : '0 AS is_billable';
        $rateSelect     = $rateCol !== null ? "te.`{$rateCol}` AS billable_rate" : '0 AS billable_rate';
        $statusSelect   = $statusCol !== null ? "te.`{$statusCol}` AS status" : 'NULL AS status';

        return Database::fetchAll(
            "SELECT te.id, te.user_id, te.project_id, te.task_id,
                    te.`{$startCol}` AS start_time, {$endSelect}, {$durationSelect}, {$breakSelect},
                    {$descSelect}, {$billableSelect}, {$rateSelect}, {$statusSelect},
                    p.name AS project_name, p.project_code,
                    {$taskSelect}
             FROM timesheet_entries tse
             INNER JOIN time_entries te ON te.id = tse.time_entry_id
             INNER JOIN projects p ON p.id = te.project_id
             {$taskJoin}
             WHERE tse.timesheet_id = :id
             ORDER BY te.`{$startCol}` ASC, te.id ASC",
            ['id' => $timesheetId]
        );
    }

    /**
     * True when this viewer may open the timesheet (owner, admin, or a manager in scope).
     *
     * @param array<string, mixed> $timesheet
     */
    public function userCanView(array $timesheet, int $userId, bool $isAdmin, bool $canApprove): bool
    {
        if ((int) $timesheet['user_id'] === $userId) {
            return true;
        }

        if ($isAdmin) {
            return true;
        }

        if (!$canApprove) {
            return false;
        }

        return $this->isInApproverScope($timesheet, $userId);
    }

    /**
     * True when this viewer may approve/reject the timesheet.
     *
     * @param array<string, mixed> $timesheet
     */
    public function userCanDecide(array $timesheet, int $userId, bool $isAdmin, bool $canApprove): bool
    {
        if (!$canApprove) {
            return false;
        }

        if ((int) $timesheet['user_id'] === $userId) {
            return false;
        }

        if ($isAdmin) {
            return true;
        }

        return $this->isInApproverScope($timesheet, $userId);
    }

    /**
     * Notify a user in-app. Failures are swallowed so the action still completes.
     * Delegates to the Phase 9 engine so the "notifications_enabled" switch and
     * length limits are always applied.
     */
    public function notify(int $userId, string $type, string $title, string $message, string $link): void
    {
        NotificationHelper::push($userId, $type, $title, $message, $link);
    }

    /**
     * Managers/admins who should hear about a submission (not the submitter).
     *
     * @return list<int>
     */
    public function approverIdsFor(array $timesheet, int $submitterId): array
    {
        $ids = [];

        try {
            $admins = Database::fetchAll(
                "SELECT id FROM users WHERE role IN ('admin','manager') AND status = 'active' AND id <> :id",
                ['id' => $submitterId]
            );
            foreach ($admins as $row) {
                $ids[(int) $row['id']] = true;
            }
        } catch (Throwable) {
            return [];
        }

        $userId = (int) ($timesheet['user_id'] ?? $submitterId);

        try {
            $managers = Database::fetchAll(
                'SELECT DISTINCT p.manager_id AS id
                 FROM timesheet_entries tse
                 INNER JOIN time_entries te ON te.id = tse.time_entry_id
                 INNER JOIN projects p ON p.id = te.project_id
                 WHERE tse.timesheet_id = :tid AND p.manager_id IS NOT NULL AND p.manager_id <> :uid',
                ['tid' => (int) ($timesheet['id'] ?? 0), 'uid' => $userId]
            );
            foreach ($managers as $row) {
                $id = (int) $row['id'];
                if ($id > 0) {
                    $ids[$id] = true;
                }
            }
        } catch (Throwable) {
            // fall through with role-based list
        }

        return array_map('intval', array_keys($ids));
    }

    /** True when this user's week containing $utcDatetime is Submitted or Approved. */
    public function isPeriodLocked(int $userId, string $utcDatetime): bool
    {
        if ($userId < 1 || $utcDatetime === '' || !self::installed()) {
            return false;
        }

        try {
            $moment = new DateTimeImmutable($utcDatetime, new DateTimeZone('UTC'));
        } catch (Exception) {
            return false;
        }

        $local = $moment->setTimezone(new DateTimeZone(FormatHelper::displayTimezone()));
        $bounds = self::weekBounds($local->format('Y-m-d'));

        $row = Database::fetchOne(
            "SELECT status FROM timesheets
             WHERE user_id = :user_id AND start_date = :start_date AND end_date = :end_date
             LIMIT 1",
            [
                'user_id'    => $userId,
                'start_date' => $bounds['start_local']->format('Y-m-d'),
                'end_date'   => $bounds['end_local']->format('Y-m-d'),
            ]
        );

        return $row !== null && in_array((string) $row['status'], [self::STATUS_SUBMITTED, self::STATUS_APPROVED], true);
    }

    /**
     * Monday 00:00 through Sunday 23:59:59 in the viewer's timezone, plus UTC bounds.
     *
     * @return array{start_local: DateTimeImmutable, end_local: DateTimeImmutable, start_utc: string, end_utc: string}
     */
    public static function weekBounds(string $weekStartDate): array
    {
        $zone   = new DateTimeZone(FormatHelper::displayTimezone());
        $anchor = DateTimeImmutable::createFromFormat('!Y-m-d', $weekStartDate, $zone);
        if ($anchor === false) {
            $anchor = new DateTimeImmutable('today', $zone);
        }

        $startLocal = $anchor->modify('Monday this week')->setTime(0, 0, 0);
        $endLocal   = $startLocal->modify('+6 days')->setTime(23, 59, 59);

        return [
            'start_local' => $startLocal,
            'end_local'   => $endLocal,
            'start_utc'   => $startLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
            'end_utc'     => $endLocal->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s'),
        ];
    }

    /**
     * @return list<array<string, mixed>>
     */
    private function entriesInRange(int $userId, string $startUtc, string $endUtc, bool $forUpdate = false): array
    {
        if (!TimeEntry::installed()) {
            return [];
        }

        $lock       = $forUpdate ? ' FOR UPDATE' : '';
        $useTasks   = Task::installed();
        $taskJoin   = $useTasks ? 'LEFT JOIN tasks tk ON tk.id = te.task_id' : '';
        $taskSelect = $useTasks ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskOrder  = $useTasks ? 'tk.name ASC,' : '';

        $startCol     = TimeEntry::column('start_time') ?? 'id';
        $endCol       = TimeEntry::column('end_time');
        $durationCol  = TimeEntry::column('duration_seconds');
        $billableCol  = TimeEntry::column('is_billable');
        $statusCol    = TimeEntry::column('status');
        $descCol      = TimeEntry::column('description');

        $endSelect      = $endCol !== null ? "te.`{$endCol}` AS end_time" : 'NULL AS end_time';
        $durationSelect = $durationCol !== null ? "te.`{$durationCol}` AS duration_seconds" : '0 AS duration_seconds';
        $billableSelect = $billableCol !== null ? "te.`{$billableCol}` AS is_billable" : '0 AS is_billable';
        $statusSelect   = $statusCol !== null ? "te.`{$statusCol}` AS status" : 'NULL AS status';
        $descSelect     = $descCol !== null ? "te.`{$descCol}` AS description" : 'NULL AS description';
        $rangeFilter    = $startCol === 'id'
            ? '1 = 1'
            : "te.`{$startCol}` >= :start_utc AND te.`{$startCol}` <= :end_utc";

        return Database::fetchAll(
            "SELECT te.id, te.user_id, te.project_id, te.task_id,
                    te.`{$startCol}` AS start_time, {$endSelect}, {$durationSelect},
                    {$billableSelect}, {$statusSelect}, {$descSelect},
                    p.name AS project_name, p.project_code,
                    {$taskSelect}
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             {$taskJoin}
             WHERE te.user_id = :user_id
               AND {$rangeFilter}
             ORDER BY p.name ASC, {$taskOrder} te.`{$startCol}` ASC" . $lock,
            [
                'user_id'   => $userId,
                'start_utc' => $startUtc,
                'end_utc'   => $endUtc,
            ]
        );
    }

    /**
     * @return list<array{key: string, date: string, label: string, short: string, is_today: bool, is_weekend: bool}>
     */
    private function dayMeta(DateTimeImmutable $startLocal): array
    {
        $today = (new DateTimeImmutable('today', $startLocal->getTimezone()))->format('Y-m-d');
        $days  = [];

        for ($i = 0; $i < 7; $i++) {
            $day = $startLocal->modify('+' . $i . ' day');
            $key = self::DAY_KEYS[$i];
            $date = $day->format('Y-m-d');
            $dow  = (int) $day->format('N');
            $days[] = [
                'key'        => $key,
                'date'       => $date,
                'label'      => self::DAY_LABELS[$key],
                'short'      => $day->format('M j'),
                'is_today'   => $date === $today,
                'is_weekend' => $dow >= 6,
            ];
        }

        return $days;
    }

    /**
     * @param list<array{key: string, date: string}> $days
     */
    private function dayKeyForDate(string $localDate, array $days): ?string
    {
        foreach ($days as $day) {
            if ($day['date'] === $localDate) {
                return $day['key'];
            }
        }

        return null;
    }

    /** @return array<string, mixed>|null */
    private function lockRow(int $id): ?array
    {
        return Database::fetchOne(
            'SELECT * FROM timesheets WHERE id = :id LIMIT 1 FOR UPDATE',
            ['id' => $id]
        );
    }

    private function lockTimeEntries(int $timesheetId, int $approverId): void
    {
        $sets = [];
        $params = ['id' => $timesheetId];

        $statusCol = TimeEntry::column('status');
        if ($statusCol !== null) {
            $sets[] = "te.`{$statusCol}` = :status";
            $params['status'] = TimeEntry::STATUS_APPROVED;
        }

        $approvedByCol = TimeEntry::column('approved_by');
        if ($approvedByCol !== null) {
            $sets[] = "te.`{$approvedByCol}` = :approved_by";
            $params['approved_by'] = $approverId;
        }

        $approvedAtCol = TimeEntry::column('approved_at');
        if ($approvedAtCol !== null) {
            $sets[] = "te.`{$approvedAtCol}` = UTC_TIMESTAMP()";
        }

        if ($sets === []) {
            return;
        }

        Database::execute(
            'UPDATE time_entries te
             INNER JOIN timesheet_entries tse ON tse.time_entry_id = te.id
             SET ' . implode(', ', $sets) . '
             WHERE tse.timesheet_id = :id',
            $params
        );
    }

    private function unlockTimeEntries(int $timesheetId): void
    {
        $sets = [];
        $params = ['id' => $timesheetId];
        $where = ['tse.timesheet_id = :id'];

        $statusCol = TimeEntry::column('status');
        if ($statusCol !== null) {
            $sets[] = "te.`{$statusCol}` = :status";
            $params['status'] = TimeEntry::STATUS_PENDING;
            $where[] = "te.`{$statusCol}` <> 'Rejected'";
        }

        $approvedByCol = TimeEntry::column('approved_by');
        if ($approvedByCol !== null) {
            $sets[] = "te.`{$approvedByCol}` = NULL";
        }

        $approvedAtCol = TimeEntry::column('approved_at');
        if ($approvedAtCol !== null) {
            $sets[] = "te.`{$approvedAtCol}` = NULL";
        }

        if ($sets === []) {
            return;
        }

        Database::execute(
            'UPDATE time_entries te
             INNER JOIN timesheet_entries tse ON tse.time_entry_id = te.id
             SET ' . implode(', ', $sets) . '
             WHERE ' . implode(' AND ', $where),
            $params
        );
    }

    /**
     * @param array<string, mixed> $timesheet
     */
    private function isInApproverScope(array $timesheet, int $approverId): bool
    {
        $ownerId = (int) $timesheet['user_id'];

        $managed = (int) Database::fetchValue(
            'SELECT COUNT(*) FROM projects p
             WHERE p.manager_id = :mid
               AND EXISTS (
                   SELECT 1 FROM project_members pm
                   WHERE pm.project_id = p.id AND pm.user_id = :uid
               )',
            ['mid' => $approverId, 'uid' => $ownerId]
        );

        if ($managed > 0) {
            return true;
        }

        $shared = (int) Database::fetchValue(
            'SELECT COUNT(*)
             FROM timesheet_entries tse
             INNER JOIN time_entries te ON te.id = tse.time_entry_id
             INNER JOIN projects p ON p.id = te.project_id
             WHERE tse.timesheet_id = :tid
               AND (p.manager_id = :mid OR p.created_by = :mid)',
            ['tid' => (int) $timesheet['id'], 'mid' => $approverId]
        );

        return $shared > 0;
    }

    /**
     * @param array{status?: string, user_id?: int, q?: string} $filters
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function queueWhere(int $approverId, bool $isAdmin, array $filters): array
    {
        [$scopeSql, $params] = $this->approverScope($approverId, $isAdmin);
        $where = [$scopeSql];

        $status = (string) ($filters['status'] ?? self::STATUS_SUBMITTED);
        if ($status !== '' && $status !== 'all' && in_array($status, self::STATUSES, true)) {
            $where[] = 't.status = :status';
            $params['status'] = $status;
        } elseif ($status === '' || $status === self::STATUS_SUBMITTED) {
            $where[] = 't.status = :status';
            $params['status'] = self::STATUS_SUBMITTED;
        }

        $userId = (int) ($filters['user_id'] ?? 0);
        if ($userId > 0) {
            $where[] = 't.user_id = :filter_user';
            $params['filter_user'] = $userId;
        }

        $q = trim((string) ($filters['q'] ?? ''));
        if ($q !== '') {
            $where[] = 'u.name LIKE :q';
            $params['q'] = '%' . $q . '%';
        }

        return [' WHERE ' . implode(' AND ', $where), $params];
    }

    /**
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function approverScope(int $approverId, bool $isAdmin): array
    {
        if ($isAdmin) {
            // Admins can review the complete queue, including their own submitted week.
            return ['1 = 1', []];
        }

        $sql = 't.user_id <> :approver_id AND (
            EXISTS (
                SELECT 1 FROM projects p
                INNER JOIN project_members pm ON pm.project_id = p.id AND pm.user_id = t.user_id
                WHERE p.manager_id = :mid_members
            )
            OR EXISTS (
                SELECT 1 FROM timesheet_entries tse
                INNER JOIN time_entries te ON te.id = tse.time_entry_id
                INNER JOIN projects p2 ON p2.id = te.project_id
                WHERE tse.timesheet_id = t.id
                  AND (p2.manager_id = :mid_proj OR p2.created_by = :mid_created)
            )
            OR u.role = \'employee\'
        )';

        return [$sql, [
            'approver_id'  => $approverId,
            'mid_members'  => $approverId,
            'mid_proj'     => $approverId,
            'mid_created'  => $approverId,
        ]];
    }

    private function selectSql(): string
    {
        return 'SELECT t.id, t.user_id, t.start_date, t.end_date,
                       t.total_seconds, t.billable_seconds, t.status,
                       t.submitted_at, t.approved_by, t.approved_at, t.rejection_reason,
                       t.created_at, t.updated_at,
                       u.name AS user_name, u.email AS user_email, u.role AS user_role, u.job_title AS user_job_title,
                       approver.name AS approved_by_name
                FROM timesheets t
                INNER JOIN users u ON u.id = t.user_id
                LEFT JOIN users approver ON approver.id = t.approved_by';
    }
}
