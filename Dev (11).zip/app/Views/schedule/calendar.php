<?php
/**
 * Month / week / day calendar of planned work.
 *
 * @var string $calendarView
 * @var string $activeTab
 * @var int    $focusUserId
 * @var list<array<string, mixed>> $people
 * @var bool $canCreate
 * @var bool $canTeam
 * @var bool $canAssign
 * @var int  $defaultUser
 * @var string $timezone
 */

$calendarView = in_array($calendarView ?? 'week', ['month', 'week', 'day'], true) ? $calendarView : 'week';
$focusUserId  = (int) ($focusUserId ?? 0);
$canCreate    = $canCreate ?? false;
$canTeam      = $canTeam ?? false;
$people       = $people ?? [];
$timezone     = $timezone ?? 'UTC';
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Schedule</h2>
        <p class="page-lead">Plan work, spot overlaps, and move blocks on the calendar. Times in <?= e(str_replace('_', ' ', $timezone)) ?>.</p>
    </div>
    <?php if ($canCreate): ?>
        <button type="button" class="btn btn-primary" id="scheduleNewBtn">
            <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>Plan work
        </button>
    <?php endif; ?>
</div>

<nav class="filter-tabs" aria-label="Schedule views">
    <a class="filter-tab<?= ($activeTab ?? 'calendar') === 'calendar' ? ' is-active' : '' ?>" href="<?= e(url('/schedule')) ?>">Calendar</a>
    <a class="filter-tab<?= ($activeTab ?? '') === 'mine' ? ' is-active' : '' ?>" href="<?= e(url('/schedule/my')) ?>">My schedule</a>
    <?php if ($canTeam): ?>
        <a class="filter-tab<?= ($activeTab ?? '') === 'team' ? ' is-active' : '' ?>" href="<?= e(url('/schedule/team')) ?>">Team</a>
    <?php endif; ?>
</nav>

<div class="filter-bar">
    <div class="btn-group" role="group" aria-label="Calendar range">
        <button type="button" class="btn btn-outline-secondary cal-view-btn<?= $calendarView === 'month' ? ' active' : '' ?>" data-cal-view="month">Month</button>
        <button type="button" class="btn btn-outline-secondary cal-view-btn<?= $calendarView === 'week' ? ' active' : '' ?>" data-cal-view="week">Week</button>
        <button type="button" class="btn btn-outline-secondary cal-view-btn<?= $calendarView === 'day' ? ' active' : '' ?>" data-cal-view="day">Day</button>
    </div>
    <div class="d-flex gap-2 align-items-center">
        <button type="button" class="btn btn-outline-secondary" id="calPrev" aria-label="Previous"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></button>
        <button type="button" class="btn btn-outline-secondary" id="calToday">Today</button>
        <button type="button" class="btn btn-outline-secondary" id="calNext" aria-label="Next"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></button>
    </div>
    <h3 class="cal-title" id="calTitle"></h3>
    <?php if ($canTeam && $people !== []): ?>
        <div class="ms-auto">
            <label for="calUserFilter" class="visually-hidden">Person</label>
            <select id="calUserFilter" class="form-select">
                <option value="0">Everyone</option>
                <?php foreach ($people as $person): ?>
                    <option value="<?= (int) $person['id'] ?>"<?= $focusUserId === (int) $person['id'] ? ' selected' : '' ?>><?= e($person['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
    <?php endif; ?>
</div>

<div class="cal-legend">
    <span><i class="cal-dot" style="background:#12426f"></i> Scheduled</span>
    <span><i class="cal-dot" style="background:#0b7a75"></i> In progress</span>
    <span><i class="cal-dot" style="background:#1c6a2c"></i> Completed</span>
    <span><i class="cal-dot" style="background:#b56a00"></i> High / urgent</span>
    <span><i class="cal-dot" style="background:#962222"></i> Missed</span>
</div>

<div id="scheduleCalendar"
     class="cal-root"
     data-view="<?= e($calendarView) ?>"
     data-user-id="<?= $focusUserId ?>"
     data-events-url="<?= e(url('/schedule/events')) ?>"
     data-store-url="<?= e(url('/schedule')) ?>"
     data-tasks-url="<?= e(url('/schedule/tasks')) ?>"
     data-assignees-url="<?= e(url('/schedule/assignees')) ?>"
     data-timezone="<?= e($timezone) ?>"
     data-can-create="<?= $canCreate ? '1' : '0' ?>"
     data-can-edit="<?= !empty($canEdit) ? '1' : '0' ?>"
     data-can-delete="<?= !empty($canDelete) ? '1' : '0' ?>"
     data-has-tasks="<?= !empty($hasTasks) ? '1' : '0' ?>">
</div>

<?php require APP_PATH . '/Views/schedule/modal_form.php'; ?>
