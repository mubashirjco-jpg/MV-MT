<?php
/**
 * Tasks tab of the project page: filter, inline add, task table, quick actions.
 * Included by projects/view.php (shares its variables).
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $tasks
 * @var array{all: int, active: int, done: int} $taskCounts
 * @var string $taskFilter   active|done|all
 * @var string $taskSearch
 * @var bool $canCreateTask
 * @var bool $canEditTask
 * @var bool $canDeleteTask
 * @var bool $canAssignTask
 * @var bool $canTrack
 */

$projectId   = (int) $project['id'];
$projectUrl  = url('/projects/' . $projectId);
$today       = gmdate('Y-m-d');
$hasFilter   = $taskSearch !== '' || $taskFilter !== 'active';
$taskStatusClass = static fn (string $status): string => match ($status) {
    'In Progress' => 'active',
    'Done'        => 'completed',
    default       => 'planning',
};
$canTrack    = !empty($canTrack);
$showActions = $canEditTask || $canDeleteTask || $canTrack;
$showKebab   = $canEditTask || $canDeleteTask;
?>
<section class="panel task-panel">
    <div class="task-toolbar">
        <form method="get" action="<?= e($projectUrl) ?>" class="task-toolbar-filters">
            <input type="hidden" name="tab" value="tasks">
            <div class="task-filter-select">
                <label for="task-status-filter" class="visually-hidden">Show</label>
                <select id="task-status-filter" name="task_status" class="form-select form-select-sm">
                    <option value="active"<?= $taskFilter === 'active' ? ' selected' : '' ?>>Show active (<?= (int) $taskCounts['active'] ?>)</option>
                    <option value="done"<?= $taskFilter === 'done' ? ' selected' : '' ?>>Show done (<?= (int) $taskCounts['done'] ?>)</option>
                    <option value="all"<?= $taskFilter === 'all' ? ' selected' : '' ?>>Show all (<?= (int) $taskCounts['all'] ?>)</option>
                </select>
            </div>
            <div class="task-search-field">
                <i class="fa-solid fa-magnifying-glass" aria-hidden="true"></i>
                <label for="task-search" class="visually-hidden">Search tasks</label>
                <input type="search" id="task-search" name="task_q" maxlength="100" class="form-control form-control-sm"
                       placeholder="Search by name" value="<?= e($taskSearch) ?>">
            </div>
        </form>

        <?php if ($canCreateTask): ?>
            <form method="post" action="<?= e(url('/projects/' . $projectId . '/tasks')) ?>" class="task-add-form" data-single-submit>
                <?= csrf_field() ?>
                <label for="new-task-name" class="visually-hidden">Add new task</label>
                <input type="text" id="new-task-name" name="name" maxlength="160" required
                       class="form-control form-control-sm" placeholder="Add new Task" autocomplete="off">
                <button type="submit" class="btn btn-primary btn-sm task-add-btn">ADD</button>
            </form>
        <?php endif; ?>
    </div>

    <div class="task-table-band">
        <span class="task-band-title">Tasks</span>
        <span class="count-pill"><?= (int) $taskCounts['all'] ?></span>
        <?php if ($hasFilter): ?>
            <a class="task-band-reset" href="<?= e($projectUrl . '?tab=tasks') ?>">Reset filter</a>
        <?php endif; ?>
    </div>

    <?php if ($tasks === []): ?>
        <div class="empty-state">
            <i class="fa-solid fa-list-check" aria-hidden="true"></i>
            <?php if ($hasFilter && $taskCounts['all'] > 0): ?>
                <p>No tasks match this filter.</p>
            <?php else: ?>
                <p>This project has no tasks yet.<?= $canCreateTask ? ' Type a name above and press ADD to create the first one.' : '' ?></p>
            <?php endif; ?>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table task-table mb-0">
                <thead>
                    <tr>
                        <th class="task-col-name">Name <i class="fa-solid fa-sort" aria-hidden="true"></i></th>
                        <th class="task-col-assignees">Assignees</th>
                        <th class="task-col-estimate">Estimate</th>
                        <th class="task-col-due">Due</th>
                        <th class="task-col-status">Status</th>
                        <?php if ($showActions): ?><th class="text-end task-col-actions">Actions</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tasks as $task): ?>
                        <?php
                        $taskId  = (int) $task['id'];
                        $isDone  = (string) $task['status'] === 'Done';
                        $overdue = !$isDone && !empty($task['due_date']) && (string) $task['due_date'] < $today;
                        $payload = [
                            'name'            => (string) $task['name'],
                            'description'     => (string) ($task['description'] ?? ''),
                            'status'          => (string) $task['status'],
                            'estimated_hours' => (float) $task['estimated_hours'] > 0 ? rtrim(rtrim(number_format((float) $task['estimated_hours'], 2, '.', ''), '0'), '.') : '',
                            'due_date'        => (string) ($task['due_date'] ?? ''),
                            'assignee_ids'    => $task['assignee_ids'],
                        ];
                        ?>
                        <tr<?= $isDone ? ' class="task-done"' : '' ?>>
                            <td data-label="Name">
                                <span class="fw-medium task-name"><?= e($task['name']) ?></span>
                                <?php if (!empty($task['description'])): ?>
                                    <div class="small text-secondary text-truncate task-desc"><?= e($task['description']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td data-label="Assignees">
                                <?php if ($task['assignees'] === []): ?>
                                    <span class="assignee-chip assignee-any">Anyone</span>
                                <?php else: ?>
                                    <?php foreach ($task['assignees'] as $assignee): ?>
                                        <span class="assignee-chip"><?= e($assignee['name']) ?></span>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </td>
                            <td data-label="Estimate"><?= (float) $task['estimated_hours'] > 0 ? e(number_format((float) $task['estimated_hours'], 1)) . ' h' : '—' ?></td>
                            <td data-label="Due" class="<?= $overdue ? 'text-danger fw-medium' : '' ?>">
                                <?= !empty($task['due_date']) ? e(FormatHelper::date($task['due_date'] . ' 00:00:00', 'M j, Y')) : '—' ?>
                            </td>
                            <td data-label="Status"><span class="status-badge status-<?= e($taskStatusClass((string) $task['status'])) ?>"><?= e($task['status']) ?></span></td>
                            <?php if ($showActions): ?>
                                <td data-label="Actions" class="text-end text-nowrap">
                                    <div class="task-row-actions">
                                        <?php if ($canTrack && !$isDone): ?>
                                            <button type="button" class="btn btn-primary btn-sm task-start-btn"
                                                    data-timer-start
                                                    data-project-id="<?= $projectId ?>"
                                                    data-task-id="<?= $taskId ?>"
                                                    data-billable="<?= (int) $project['is_billable'] ?>">
                                                <i class="fa-solid fa-play" aria-hidden="true"></i> Start
                                            </button>
                                        <?php endif; ?>
                                        <?php if ($showKebab): ?>
                                            <div class="dropdown">
                                                <button type="button" class="btn btn-icon btn-sm task-kebab" data-bs-toggle="dropdown"
                                                        data-bs-auto-close="true" aria-expanded="false" aria-label="Task actions">
                                                    <i class="fa-solid fa-ellipsis-vertical" aria-hidden="true"></i>
                                                </button>
                                                <ul class="dropdown-menu dropdown-menu-end">
                                                    <?php if ($canEditTask): ?>
                                                        <li>
                                                            <button type="button" class="dropdown-item" data-bs-toggle="modal" data-bs-target="#taskModal"
                                                                    data-task-edit="<?= e(json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)) ?>"
                                                                    data-task-action="<?= e(url('/tasks/' . $taskId)) ?>">
                                                                <i class="fa-solid fa-pen fa-fw me-2" aria-hidden="true"></i>Edit task
                                                            </button>
                                                        </li>
                                                        <li>
                                                            <form method="post" action="<?= e(url('/tasks/' . $taskId . '/status')) ?>" data-single-submit>
                                                                <?= csrf_field() ?>
                                                                <input type="hidden" name="status" value="<?= $isDone ? 'Open' : 'Done' ?>">
                                                                <button type="submit" class="dropdown-item">
                                                                    <i class="fa-solid <?= $isDone ? 'fa-rotate-left' : 'fa-check' ?> fa-fw me-2" aria-hidden="true"></i><?= $isDone ? 'Reopen task' : 'Mark as done' ?>
                                                                </button>
                                                            </form>
                                                        </li>
                                                    <?php endif; ?>
                                                    <?php if ($canDeleteTask): ?>
                                                        <?php if ($canEditTask): ?><li><hr class="dropdown-divider"></li><?php endif; ?>
                                                        <li>
                                                            <form method="post" action="<?= e(url('/tasks/' . $taskId . '/delete')) ?>" data-confirm="Delete task <?= e($task['name']) ?>? Planned schedule blocks keep their time but lose the task link.">
                                                                <?= csrf_field() ?>
                                                                <button type="submit" class="dropdown-item text-danger">
                                                                    <i class="fa-solid fa-trash fa-fw me-2" aria-hidden="true"></i>Delete task
                                                                </button>
                                                            </form>
                                                        </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php if ($canCreateTask || $canEditTask): ?>
    <?php require APP_PATH . '/Views/tasks/form_modal.php'; ?>
<?php endif; ?>
