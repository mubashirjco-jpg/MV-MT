<?php
/**
 * Shared project navigation, matching the Clockify-style project tabs.
 *
 * @var array<string, mixed> $project
 * @var string $activeProjectTab
 * @var bool $tasksReady
 * @var array<string, int> $taskCounts
 * @var bool $canEdit
 */

$projectId = (int) $project['id'];
$base = url('/projects/' . $projectId);

$tabs = [
    'tasks' => [
        'label' => 'Tasks',
        'href'  => $base . '?tab=tasks',
        'show'  => $tasksReady,
        'badge' => $tasksReady ? (int) ($taskCounts['all'] ?? 0) : null,
    ],
    'access' => [
        'label' => 'Access',
        'href'  => $base . '?tab=access',
        'show'  => true,
        'badge' => null,
    ],
    'status' => [
        'label' => 'Status',
        'href'  => $base . '?tab=status',
        'show'  => true,
        'badge' => null,
    ],
    'forecast' => [
        'label' => 'Forecast',
        'href'  => url('/projects/' . $projectId . '/dashboard'),
        'show'  => true,
        'badge' => null,
    ],
    'note' => [
        'label' => 'Note',
        'href'  => $base . '?tab=note',
        'show'  => true,
        'badge' => null,
    ],
    'settings' => [
        'label' => 'Settings',
        'href'  => url('/projects/' . $projectId . '/edit'),
        'show'  => $canEdit,
        'badge' => null,
    ],
];
?>
<nav class="project-tabs-wrap" aria-label="Project sections">
    <div class="project-tabs" role="tablist">
        <?php foreach ($tabs as $key => $tab): ?>
            <?php if (!$tab['show']) { continue; } ?>
            <a class="project-tab<?= $activeProjectTab === $key ? ' is-active' : '' ?>"
               href="<?= e($tab['href']) ?>"
               <?= $activeProjectTab === $key ? 'aria-current="page"' : '' ?>>
                <?= e($tab['label']) ?>
                <?php if ($tab['badge'] !== null): ?>
                    <span class="count-pill"><?= (int) $tab['badge'] ?></span>
                <?php endif; ?>
            </a>
        <?php endforeach; ?>
    </div>
</nav>
