<?php
/**
 * System settings (Phase 9): company name, currency symbol, default hourly rate,
 * working hours per day and the default timezone.
 *
 * Settings live in the key/value `settings` table. Only the keys listed in
 * $editable can be written from this screen, so a crafted POST cannot create
 * arbitrary configuration rows.
 */

declare(strict_types=1);

final class SettingsController extends Controller
{
    /** @var list<string> allow-list of writable setting keys */
    private const EDITABLE = [
        'company_name',
        'currency_symbol',
        'currency',
        'default_hourly_rate',
        'working_hours_per_day',
        'default_timezone',
    ];

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN]);
    }

    /** GET /settings */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $this->view('settings/index', [
            'pageTitle' => 'System settings',
            'settings'  => $this->load(),
            'timezones' => DateTimeZone::listIdentifiers(),
            'currencies' => ['USD', 'EUR', 'GBP', 'PKR', 'INR', 'AED', 'SAR', 'AUD', 'CAD', 'JPY'],
        ]);
    }

    /** GET /settings/audit-logs : searchable, filterable audit trail. */
    public function auditLogs(Request $request, array $params): void
    {
        PermissionHelper::require('activity.view');

        $filters = [
            'q'       => trim((string) $request->input('q', '')),
            'module'  => (string) $request->input('module', 'all'),
            'action'  => trim((string) $request->input('action', '')),
            'user_id' => (int) $request->input('user_id', 0),
        ];

        $model = new ActivityLog();
        $result = $model->search($filters, (int) $request->input('page', 1), 25);

        $this->view('settings/audit_logs', [
            'pageTitle' => 'Activity log',
            'result'    => $result,
            'filters'   => $filters,
            'modules'   => $model->modules(),
        ]);
    }

    /** POST /settings */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'company_name'         => 'required|string|max:160',
            'currency_symbol'      => 'required|string|max:6',
            'currency'             => 'required|string|max:3',
            'default_hourly_rate'  => 'required|numeric|min:0|max:100000',
            'working_hours_per_day'=> 'required|numeric|min:1|max:24',
            'default_timezone'     => 'required|timezone',
        ], '/settings', [
            'company_name'          => 'Company name',
            'currency_symbol'       => 'Currency symbol',
            'currency'              => 'Currency code',
            'default_hourly_rate'   => 'Default hourly rate',
            'working_hours_per_day' => 'Working hours per day',
            'default_timezone'      => 'Timezone',
        ]);

        $before = $this->load();
        $after  = [];

        Database::transaction(function () use ($data, &$after): void {
            foreach (self::EDITABLE as $key) {
                if (!array_key_exists($key, $data)) {
                    continue;
                }

                $value = (string) $data[$key];

                $this->put($key, $value);
                $after[$key] = $value;
            }
        });

        LoggerHelper::logEvent('settings.updated', LoggerHelper::MODULE_SETTINGS, null, $before, $after);

        $this->flash('success', 'System settings were saved.');
        $this->redirect('/settings');
    }

    /* ------------------------------------------------------------- helpers */

    /** @return array<string, string> */
    private function load(): array
    {
        $rows = Database::fetchAll(
            'SELECT setting_key, setting_value FROM settings WHERE setting_key IN ('
            . implode(', ', array_fill(0, count(self::EDITABLE), '?')) . ')',
            self::EDITABLE
        );

        $settings = [];
        foreach ($rows as $row) {
            $settings[(string) $row['setting_key']] = (string) ($row['setting_value'] ?? '');
        }

        // Sensible defaults for keys a fresh database may not have yet.
        $settings += [
            'company_name'          => (string) Config::get('app.name', 'TimeTrack'),
            'currency_symbol'       => '$',
            'currency'              => 'USD',
            'default_hourly_rate'   => '0',
            'working_hours_per_day' => '8',
            'default_timezone'      => (string) Config::get('app.timezone', 'UTC'),
        ];

        return $settings;
    }

    private function put(string $key, string $value): void
    {
        Database::execute(
            'INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
             VALUES (:key, :value, :type, :grp, NULL)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP()',
            [
                'key'   => $key,
                'value' => $value,
                'type'  => in_array($key, ['working_hours_per_day'], true) ? 'int' : 'string',
                'grp'   => in_array($key, ['currency_symbol', 'currency', 'default_hourly_rate'], true) ? 'billing' : 'general',
            ]
        );
    }
}
