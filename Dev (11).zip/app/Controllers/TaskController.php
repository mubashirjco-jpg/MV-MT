<?php
/**
 * Tasks inside projects: create, edit, change status, delete.
 *
 * Tasks are listed on the project page (ProjectController::show, "Tasks" tab); this
 * controller only handles the state-changing actions and always sends the user back there.
 *
 * Access: a user needs the matching tasks.* permission AND must be able to see the project
 * (admin / projects.view_all, project manager, creator or member). Changing assignees
 * additionally needs tasks.assign.
 */

declare(strict_types=1);

final class TaskController extends Controller
{
    private Task $tasks;
    private Project $projects;
    private ProjectMember $members;

    public function __construct()
    {
        parent::__construct(true);
        $this->tasks    = new Task();
        $this->projects = new Project();
        $this->members  = new ProjectMember();
    }

    /** POST /projects/{id}/tasks */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.create');

        $project = $this->loadProject((int) ($params['id'] ?? 0));
        $back    = '/projects/' . (int) $project['id'] . '?tab=tasks';
        $this->assertProjectOpen($project, $back);

        $data = $this->validatedTask($back);

        if ($this->tasks->nameTaken((int) $project['id'], $data['name'])) {
            $this->fail($back, 'A task named "' . $data['name'] . '" already exists in this project.');
        }

        $id = $this->tasks->create([
            'project_id'      => (int) $project['id'],
            'name'            => $data['name'],
            'description'     => $data['description'],
            'status'          => $data['status'] ?? Task::STATUS_OPEN,
            'estimated_hours' => $data['estimated_hours'] ?? 0,
            'due_date'        => $data['due_date'],
            'created_by'      => (int) AuthHelper::id(),
        ]);

        $assigneeIds = [];
        if (PermissionHelper::has('tasks.assign')) {
            $assigneeIds = $this->postedAssigneeIds();
            $this->tasks->syncAssignees(
                $id,
                $assigneeIds,
                $this->members->userIdsForProject((int) $project['id'])
            );
        }

        LoggerHelper::audit('task.created', 'task', $id, ['project_id' => (int) $project['id'], 'name' => $data['name']]);
        $this->notifyAssignees($assigneeIds, (string) $data['name'], $id, (int) $project['id'], (string) ($project['name'] ?? ''));
        $this->flash('success', 'Task "' . $data['name'] . '" was added.');
        $this->redirect($back);
    }

    /** POST /tasks/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.edit');

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $back = '/projects/' . (int) $project['id'] . '?tab=tasks';

        $data = $this->validatedTask($back);

        if ($this->tasks->nameTaken((int) $project['id'], $data['name'], (int) $task['id'])) {
            $this->fail($back, 'A task named "' . $data['name'] . '" already exists in this project.');
        }

        $this->tasks->update((int) $task['id'], [
            'name'            => $data['name'],
            'description'     => $data['description'],
            'status'          => $data['status'] ?? (string) $task['status'],
            'estimated_hours' => $data['estimated_hours'] ?? 0,
            'due_date'        => $data['due_date'],
        ]);

        $assigneeIds = [];
        if (PermissionHelper::has('tasks.assign')) {
            $assigneeIds = $this->postedAssigneeIds();
            $this->tasks->syncAssignees(
                (int) $task['id'],
                $assigneeIds,
                $this->members->userIdsForProject((int) $project['id'])
            );
        }

        LoggerHelper::audit('task.updated', 'task', (int) $task['id'], ['name' => $data['name']]);
        $this->notifyAssignees($assigneeIds, (string) $data['name'], (int) $task['id'], (int) $project['id'], (string) ($project['name'] ?? ''));
        $this->flash('success', 'Task "' . $data['name'] . '" was updated.');
        $this->redirect($back);
    }

    /** POST /tasks/{id}/status */
    public function status(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.edit');

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $back   = '/projects/' . (int) $project['id'] . '?tab=tasks';
        $status = (string) $request->input('status', '');

        if (!in_array($status, Task::STATUSES, true)) {
            $this->fail($back, 'Choose a valid task status.');
        }

        if ($status !== (string) $task['status']) {
            $this->tasks->setStatus((int) $task['id'], $status);
            LoggerHelper::audit('task.status_changed', 'task', (int) $task['id'], [
                'from' => (string) $task['status'],
                'to'   => $status,
            ]);
        }

        $this->flash('success', '"' . $task['name'] . '" is now ' . $status . '.');
        $this->redirect($back);
    }

    /** POST /tasks/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.delete');

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));

        $this->tasks->deleteWithLinks((int) $task['id']);

        LoggerHelper::audit('task.deleted', 'task', (int) $task['id'], [
            'project_id' => (int) $project['id'],
            'name'       => (string) $task['name'],
        ]);
        $this->flash('success', 'Task "' . $task['name'] . '" was deleted.');
        $this->redirect('/projects/' . (int) $project['id'] . '?tab=tasks');
    }

    /** @return array<string, mixed> */
    private function loadProject(int $id): array
    {
        if ($id < 1 || !Task::installed()) {
            $this->notFound();
        }

        $project = $this->projects->findWithRelations($id);
        if ($project === null) {
            $this->notFound();
        }

        if (!$this->projects->userCanView($project, (int) AuthHelper::id(), PermissionHelper::has('projects.view_all'))) {
            $this->forbidden();
        }

        return $project;
    }

    /** @return array{0: array<string, mixed>, 1: array<string, mixed>} [task, project] */
    private function loadTask(int $id): array
    {
        if ($id < 1 || !Task::installed()) {
            $this->notFound();
        }

        $task = $this->tasks->find($id);
        if ($task === null) {
            $this->notFound();
        }

        return [$task, $this->loadProject((int) $task['project_id'])];
    }

    /** @param array<string, mixed> $project */
    private function assertProjectOpen(array $project, string $back): void
    {
        if ((string) $project['status'] === Project::STATUS_ARCHIVED) {
            $this->fail($back, 'Archived projects cannot receive new tasks.');
        }
    }

    /** @return array<string, mixed> */
    private function validatedTask(string $back): array
    {
        $validator = ValidatorHelper::make($this->request->all(), [
            'name'            => 'required|string|max:160',
            'description'     => 'nullable|string|max:2000',
            'status'          => 'nullable|in:' . implode(',', Task::STATUSES),
            'estimated_hours' => 'nullable|numeric|min:0|max:9999',
            'due_date'        => 'nullable|date',
        ], [
            'name'            => 'Task name',
            'description'     => 'Description',
            'status'          => 'Status',
            'estimated_hours' => 'Estimated hours',
            'due_date'        => 'Due date',
        ]);

        if ($validator->fails()) {
            $errors = array_values($validator->errors());
            $this->fail($back, (string) ($errors[0] ?? 'Please check the task details.'));
        }

        $data = $validator->validated();
        $data['description'] = isset($data['description']) && $data['description'] !== '' ? $data['description'] : null;
        $data['due_date']    = isset($data['due_date']) && $data['due_date'] !== '' ? $data['due_date'] : null;

        return $data;
    }

    /** @return list<int> */
    private function postedAssigneeIds(): array
    {
        $raw = $this->request->input('assignee_ids', []);
        if (!is_array($raw)) {
            $raw = $raw === null || $raw === '' ? [] : [$raw];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Notify everyone newly responsible for a task (never the person who made the change).
     *
     * @param list<int> $assigneeIds
     */
    private function notifyAssignees(array $assigneeIds, string $taskName, int $taskId, int $projectId, string $projectName): void
    {
        $actor = (int) AuthHelper::id();

        foreach ($assigneeIds as $assigneeId) {
            if ($assigneeId === $actor) {
                continue;
            }
            NotificationHelper::taskAssigned($assigneeId, $taskName, $taskId, $projectId, $projectName);
            LoggerHelper::taskAssigned($taskId, $assigneeId, $taskName, $projectId);
        }
    }

    private function fail(string $back, string $message): never
    {
        $this->flash('danger', $message);
        $this->redirect($back);
    }
}
