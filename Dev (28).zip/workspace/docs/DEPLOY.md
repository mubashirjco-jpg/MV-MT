# Deploying TimeTrack (shared hosting)

The workflow is always the same three steps:

1. **Upload the files** (see "Files you must NOT upload" below).
2. **Run `database/UPGRADE_LIVE.sql` once** in phpMyAdmin (Import, or paste into the SQL tab).
   The last result is a checklist: every row must say `OK`. The script is safe to run twice and
   works on MariaDB and MySQL 8. It never deletes users, projects, tasks, schedules or time entries.
3. **Open `/health`** (must show `ok`), then sign in as admin and open `/admin/health` (no failures).

`UPGRADE_LIVE.sql` upgrades an existing TimeTrack database. It does not create the base tables
(users, projects, time_entries, ...). For a brand-new empty database, first import a phpMyAdmin export
of an existing TimeTrack database, then run `UPGRADE_LIVE.sql`.

Always take a phpMyAdmin Export backup of the database before step 2.

## Files you must NOT upload to live

| Path | Why |
|---|---|
| `config/database.php` | Holds the live database password. Never overwrite the live copy with a copy from a zip or a laptop. |
| `config/config.php` (after you have set `APP_KEY` on live) | Re-uploading the original puts the `CHANGE_ME...` placeholder back and desktop-agent pairing stops. Keep the live copy, or set `APP_KEY` again. |
| `storage/sessions/*` | Live login sessions (and anyone who has them is signed in). Upload only the empty folder with its `.gitkeep`. |
| `storage/logs/*` | Live application logs. Upload only the empty folder with its `.gitkeep`. |
| `storage/idle_settings.cache` | Runtime cache, recreated automatically. |
| `storage/maintenance.flag` | If present on live, the site shows the maintenance page. |
| `public/uploads/*` | Live uploads (logos, files). Never overwrite. |
| `*.sql` dumps, `*.zip`, `_dev/` | Database exports and archives must never sit in a web folder. |

`tools/build-release.sh` / `tools/build-release.ps1` build a zip that already leaves all of these out
(except the two config files, which you manage by hand as described above).

## First-time settings on live

- `config/config.php`: replace the `CHANGE_ME_PASTE_A_LONG_RANDOM_SECRET_HERE` placeholder after
  `'APP_KEY'` with a random secret of 32 or more characters (for example `php -r "echo bin2hex(random_bytes(32));"`).
  Until then the Desktop Agent page refuses to generate pairing codes and `/admin/health` shows APP_KEY as failed.
- `APP_ENV=production` and `APP_DEBUG=0` (the defaults).
- `security.bind_session_to_browser` in `config/config.php` (default `true`): set it to `false` if people are
  signed out when they move between Chrome, Edge and in-app browsers. Every forced sign-out is logged
  in `storage/logs` as "Session dropped" with the old and new browser family.
- Cron (Hostinger): `php tools/cron_auto_stop.php` every minute; `php tools/cron_cleanup.php` once a day.
- SMTP (invitations and password reset): sign in as admin, open System settings, Mail / SMTP.
  Set host, port (587 TLS or 465 SSL), username, password, From name and From email, then Send test.
  The SMTP password is encrypted with APP_KEY and is never shown again. Leave the password field blank to keep the stored value.
  Until SMTP is configured, invitations are saved as pending and can be resent after mail works.
  Invitation links expire after the number of days you set (default 7). Resend rotates the token so the old link stops working.
- Optional: `php tools/golive.php --check` (APP_KEY, database and schema checks) and
  `php tools/golive.php --name=... --email=... --password=...` to create the real admin account.

## Atomic swap (cPanel File Manager)

1. Take a phpMyAdmin backup of the live database.
2. Upload the release zip to a sibling folder, for example `public_html/Dev-new`, and extract it so
   `public_html/Dev-new/public/index.php` exists.
3. Copy `config/database.php` and `config/config.php` from the live folder into `Dev-new/config/`.
4. Copy `public/uploads/` from live into `Dev-new/public/uploads/`.
5. Confirm `storage/sessions` and `storage/logs` are writable (0750).
6. Rename live `public_html/Dev` to `public_html/Dev-prev`, then `Dev-new` to `Dev`.
7. Run `database/UPGRADE_LIVE.sql` (step 2 above) if this release changed the database, then hit `/health`.
8. Keep `Dev-prev` until the next successful deploy. To roll back, rename `Dev` to `Dev-bad` and `Dev-prev` back to `Dev`.
   (`UPGRADE_LIVE.sql` also drops `clients.company` and `time_entries.status/approved_*` and merges duplicate
   timesheets, so rolling back to code older than this release means restoring the phpMyAdmin backup too.)

## Maintenance flag (503 + Retry-After)

Create an empty file at `storage/maintenance.flag`. The front controller (`public/index.php`) serves
`public/maintenance.html` with HTTP 503 and `Retry-After: 120` only when that flag file exists. Other 503s
(PHP fatals, host limits) are not rewritten to this page. Delete the flag file to restore the app.
Workspace Settings -> Maintenance mode still blocks non-admin login independently of the flag.

## Build a clean release zip

From the project root:

```bash
# Linux/macOS: writes TimeTrack-release-YYYYMMDD.zip one level above the project
bash tools/build-release.sh
```

```powershell
# Windows
powershell -File tools/build-release.ps1
```

Both scripts verify the finished zip themselves and exit with an error if it contains sessions, logs,
`idle_settings.cache`, `maintenance.flag`, dumps or `_dev/`, or if `database/UPGRADE_LIVE.sql` is missing.
