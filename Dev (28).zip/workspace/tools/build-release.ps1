# Build a clean TimeTrack release zip.
#
# Left OUT of the zip (runtime data and secrets that must never be uploaded to live):
#   storage\sessions\*, storage\logs\*, storage\idle_settings.cache, storage\maintenance.flag,
#   public\uploads\*, *.log, sess_*, database dumps (*u897128490*, *.sql.gz, *.dump), _dev\, *.zip, .git\
# Kept as placeholders so the folders exist after upload:
#   storage\sessions\.gitkeep, storage\logs\.gitkeep, public\uploads\.htaccess
#
# The script verifies the finished zip and exits with an error if anything above slipped in.
param(
    [string]$Out = ""
)

$Root = Split-Path -Parent $PSScriptRoot
if ($Out -eq "") {
    $stamp = Get-Date -Format "yyyyMMdd"
    $Out = Join-Path (Split-Path -Parent $Root) "TimeTrack-release-$stamp.zip"
}

$exclude = @(
    '^\.git\\',
    '^storage\\sessions\\',
    '^storage\\logs\\',
    '^storage\\idle_settings\.cache$',
    '^storage\\maintenance\.flag$',
    '^public\\uploads\\',
    '\.log$',
    'sess_',
    'u897128490',
    '\.sql\.gz$',
    '\.dump$',
    '^_dev\\',
    '\.zip$'
)

Add-Type -AssemblyName System.IO.Compression.FileSystem
if (Test-Path $Out) { Remove-Item $Out }
$zip = [System.IO.Compression.ZipFile]::Open($Out, 'Create')
Get-ChildItem -Path $Root -Recurse -File -Force | ForEach-Object {
    $rel = $_.FullName.Substring($Root.Length + 1)
    $skip = $false
    foreach ($pat in $exclude) {
        if ($rel -match $pat) { $skip = $true; break }
    }
    if (-not $skip) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $_.FullName, ($rel -replace '\\', '/')) | Out-Null
    }
}

# Re-add the placeholders that keep the runtime directories in the tree.
foreach ($placeholder in @('storage\sessions\.gitkeep', 'storage\logs\.gitkeep', 'public\uploads\.htaccess')) {
    $p = Join-Path $Root $placeholder
    if (Test-Path $p) {
        [System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip, $p, ($placeholder -replace '\\', '/')) | Out-Null
    }
}

# Verify: the release must not contain sessions, logs, caches, flags or dumps.
$names = $zip.Entries | ForEach-Object { $_.FullName }
$zip.Dispose()

$bad = $names | Where-Object {
    $_ -match 'sess_|\.log$|storage/idle_settings\.cache|storage/maintenance\.flag|u897128490|\.sql\.gz$|\.dump$|(^|/)_dev/' -or
    ($_ -match '^storage/(sessions|logs)/' -and $_ -notmatch '\.gitkeep$')
}
Write-Host "Wrote $Out"
if ($bad) {
    Write-Host "FAIL: the release zip contains files that must not be uploaded:" -ForegroundColor Red
    $bad | ForEach-Object { Write-Host "  $_" -ForegroundColor Red }
    exit 1
}
if (-not ($names -contains 'database/UPGRADE_LIVE.sql')) {
    Write-Host "FAIL: database/UPGRADE_LIVE.sql is missing from the zip" -ForegroundColor Red
    exit 1
}
Write-Host "OK: no sessions, logs, caches, flags or dumps in the zip."
