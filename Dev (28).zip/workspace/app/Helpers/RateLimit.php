<?php
/**
 * Lightweight rate limiter backed by activity_logs (already written for audits).
 * Used to slow invitation send/resend and public invitation-accept attempts.
 */

declare(strict_types=1);

final class RateLimitHelper
{
    public static function tooMany(string $action, string $ip, int $limit, int $minutes): bool
    {
        if ($ip === '' || $limit < 1) {
            return false;
        }

        try {
            $count = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM activity_logs
                 WHERE action = :action AND ip_address = :ip
                   AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL :mins MINUTE)',
                ['action' => $action, 'ip' => $ip, 'mins' => $minutes]
            );
        } catch (Throwable $e) {
            LoggerHelper::debug('Rate limit lookup failed', ['error' => $e->getMessage()]);

            return false;
        }

        return $count >= $limit;
    }
}
