<?php
/**
 * Typed workspace-policy access and the Step 15 enforcement matrix.
 *
 * Menu hiding is not access control. Controllers must call FeatureFlagsHelper
 * or these policy checks so a crafted URL cannot skip a disabled module.
 *
 * Batch 1: module on/off and hide-* gates, sidebar helper, matrix.
 * Batch 2: lock_time, rounding, daily_capacity, week_start, approval_period.
 * Batch 3 (this sub-batch): creation/edit/visibility policies.
 */

declare(strict_types=1);

final class WorkspacePolicy
{
    /**
     * setting => [where enforced, http, how to test, batch]
     *
     * @var array<string, array{where:string, http:string, test:string, batch:int}>
     */
    public const MATRIX = [
        'timesheet_enabled' => [
            'where' => 'TimesheetController::__construct; SidebarHelper flag timesheet',
            'http'  => '404 when off',
            'test'  => 'Off: /timesheets and /timesheets/team 404, sidebar Timesheet gone. On: page loads.',
            'batch' => 1,
        ],
        'scheduling_enabled' => [
            'where' => 'ScheduleController::__construct; SidebarHelper flag scheduling',
            'http'  => '404 when off',
            'test'  => 'Off: /schedule, /schedule/my, /schedule/team 404 and sidebar Schedule gone. On: Schedule is in TRACK and calendar loads.',
            'batch' => 1,
        ],
        'time_approval_enabled' => [
            'where' => 'TimesheetController approval actions via FeatureFlagsHelper::requireTimeApproval',
            'http'  => '404 when off (also 404 if timesheet_enabled is off)',
            'test'  => 'Off: /timesheets/team, approve/reject/batch 404. On: queue loads for approvers.',
            'batch' => 1,
        ],
        'hide_tracker' => [
            'where' => 'TimerController::__construct requireTracker; SidebarHelper flag tracker',
            'http'  => '404 when hidden (all roles)',
            'test'  => 'On: /time and /time/status 404, timer bar gone. Off: tracker loads.',
            'batch' => 1,
        ],
        'hide_projects' => [
            'where' => 'ProjectController and TaskController constructors requireProjects',
            'http'  => '403 for employee/client; admins/managers still allowed',
            'test'  => 'On as employee: /projects 403. On as admin: projects still open.',
            'batch' => 1,
        ],
        'hide_team' => [
            'where' => 'ScheduleController::teamSchedule requireTeam; SidebarHelper flag team',
            'http'  => '403 for employee/client; privileged roles allowed',
            'test'  => 'On as employee: /schedule/team 403. On as manager: team schedule loads.',
            'batch' => 1,
        ],
        'hide_reports' => [
            'where' => 'ProjectController::dashboard requireReports',
            'http'  => '403 for employee/client; privileged roles allowed',
            'test'  => 'On as employee: /projects/{id}/dashboard 403. Off: dashboard loads.',
            'batch' => 1,
        ],
        'force_timer' => [
            'where' => 'FeatureFlagsHelper::allowManual / requireManual; TimerController::manualStore',
            'http'  => '403 on POST /time/manual when on',
            'test'  => 'On: Add time hidden, POST /time/manual 403. Off: manual form works if allow_manual_time_entries=1.',
            'batch' => 1,
        ],
        'allow_manual_time_entries' => [
            'where' => 'FeatureFlagsHelper::allowManual (system setting); TimerController::manualStore',
            'http'  => '403 on POST /time/manual when off',
            'test'  => 'Off at /settings: Add time hidden, POST /time/manual 403. On: manual form works unless force_timer.',
            'batch' => 1,
        ],
        'lock_time_enabled' => [
            'where' => 'TimeEntry create/update/delete when a submitted/approved timesheet covers the day',
            'http'  => '409 on write into a locked period',
            'test'  => 'On: cannot add/edit time on a day whose timesheet is Submitted/Approved. Off: only the linked entries stay locked.',
            'batch' => 2,
        ],
        'time_rounding_minutes' => [
            'where' => 'TimeEntry::computeDuration rounds duration_seconds',
            'http'  => 'n/a (value rewritten server-side)',
            'test'  => 'Set 15: a 7-minute entry stores 900s (or 0 rejected). Set 1: stores exact seconds.',
            'batch' => 2,
        ],
        'daily_capacity' => [
            'where' => 'TimeEntry create/update warns or rejects when the local day would exceed capacity',
            'http'  => '422 when over capacity (limit)',
            'test'  => 'Set 1 hour: second hour-long entry that day is rejected. UI shows remaining capacity.',
            'batch' => 2,
        ],
        'week_start' => [
            'where' => 'Timesheet::weekBounds, WeekDashboardHelper, ScheduleController::teamSchedule',
            'http'  => 'n/a (week grid shifts)',
            'test'  => 'Sunday: timesheet/dashboard/team schedule weeks start Sunday. Monday: start Monday.',
            'batch' => 2,
        ],
        'approval_period' => [
            'where' => 'Timesheet::periodBounds / submitPeriod',
            'http'  => 'n/a (range changes)',
            'test'  => 'Weekly=7 days, semi-monthly=1-15 or 16-end, monthly=full month. Submit uses that range.',
            'batch' => 2,
        ],
        'edit_time_others_policy' => [
            'where' => 'WorkspacePolicy::assertCanMutateTimeEntry; TimerController update/delete/description',
            'http'  => '403 if policy denies the actor',
            'test'  => 'admins: only admin edits others. admins_team_managers: admin and manager. Employee never.',
            'batch' => 3,
        ],
        'project_creation_policy' => [
            'where' => 'WorkspacePolicy::requireCanCreateProject in ProjectController create/store',
            'http'  => '403 if policy denies the actor',
            'test'  => 'admins: employee POST /projects 403. anyone: employee with projects.create succeeds.',
            'batch' => 3,
        ],
        'task_creation_policy' => [
            'where' => 'WorkspacePolicy::requireCanCreateTask in TaskController create/store',
            'http'  => '403 if policy denies the actor',
            'test'  => 'admins: employee POST task 403. admins_project_managers: project manager succeeds.',
            'batch' => 3,
        ],
        'default_project_visibility' => [
            'where' => 'ProjectController::store sets is_public from workspace default',
            'http'  => 'n/a (insert default)',
            'test'  => 'public: new project is_public=1. private: is_public=0. Form does not override unless Access tab is used later.',
            'batch' => 3,
        ],
        'regular_user_time_visibility' => [
            'where' => 'TimeEntry::listFiltered, Timer::getVisibleActive, TimerController::index/active',
            'http'  => 'n/a (query scoped); 403 if user_id filter is someone else under own',
            'test'  => 'own: employee sees only self. public: own plus public-project time. all: all visible-project time.',
            'batch' => 3,
        ],
    ];

    public static function currentId(): int
    {
        try {
            return Workspace::currentId();
        } catch (Throwable $e) {
            LoggerHelper::debug('Workspace id unavailable', ['error' => $e->getMessage()]);
            return 0;
        }
    }

    public static function string(string $key, ?string $fallback = null): string
    {
        $defaults = Workspace::DEFAULT_SETTINGS;
        if (!array_key_exists($key, $defaults)) {
            throw new InvalidArgumentException('Unknown workspace setting: ' . $key);
        }

        $default = $fallback ?? (string) $defaults[$key];
        $workspaceId = self::currentId();
        if ($workspaceId < 1) {
            return $default;
        }

        try {
            return SettingsService::workspaceString($workspaceId, $key, $default);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return $default;
        }
    }

    public static function int(string $key, ?int $fallback = null): int
    {
        $raw = self::string($key, $fallback === null ? null : (string) $fallback);

        return is_numeric($raw) ? (int) $raw : ($fallback ?? 0);
    }

    public static function float(string $key, ?float $fallback = null): float
    {
        $raw = self::string($key, $fallback === null ? null : (string) $fallback);

        return is_numeric($raw) ? (float) $raw : ($fallback ?? 0.0);
    }

    public static function weekStart(): string
    {
        $value = strtolower(self::string('week_start', 'monday'));

        return $value === 'sunday' ? 'sunday' : 'monday';
    }

    public static function approvalPeriod(): string
    {
        $value = strtolower(self::string('approval_period', 'weekly'));

        return in_array($value, ['weekly', 'semi-monthly', 'monthly'], true) ? $value : 'weekly';
    }

    public static function dailyCapacityHours(): float
    {
        return max(1.0, min(24.0, self::float('daily_capacity', 8.0)));
    }

    public static function dailyCapacitySeconds(): int
    {
        return (int) round(self::dailyCapacityHours() * 3600);
    }

    public static function timeRoundingMinutes(): int
    {
        return max(1, min(60, self::int('time_rounding_minutes', 1)));
    }

    public static function defaultProjectIsPublic(): bool
    {
        return self::string('default_project_visibility', 'private') === 'public';
    }

    public static function regularUserTimeVisibility(): string
    {
        $value = self::string('regular_user_time_visibility', 'own');

        return in_array($value, ['all', 'public', 'own'], true) ? $value : 'own';
    }

    public static function editTimeOthersPolicy(): string
    {
        $value = self::string('edit_time_others_policy', 'admins');

        return in_array($value, ['admins', 'admins_team_managers'], true) ? $value : 'admins';
    }

    public static function projectCreationPolicy(): string
    {
        $value = self::string('project_creation_policy', 'admins');

        return in_array($value, ['admins', 'admins_project_managers', 'anyone'], true) ? $value : 'admins';
    }

    public static function taskCreationPolicy(): string
    {
        $value = self::string('task_creation_policy', 'admins_project_managers');

        return in_array($value, ['admins', 'admins_project_managers', 'anyone'], true) ? $value : 'admins_project_managers';
    }

    public static function isProjectManager(): bool
    {
        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER)) {
            return true;
        }

        $userId = (int) AuthHelper::id();
        if ($userId < 1) {
            return false;
        }

        try {
            return (int) Database::fetchValue(
                "SELECT COUNT(*) FROM project_members
                 WHERE user_id = :user_id AND LOWER(project_role) = 'manager'",
                ['user_id' => $userId]
            ) > 0;
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return false;
        }
    }

    public static function allowsByCreationPolicy(string $policy): bool
    {
        return match ($policy) {
            'anyone' => AuthHelper::check(),
            'admins_project_managers' => AuthHelper::hasRole(AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER) || self::isProjectManager(),
            default => AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
        };
    }

    public static function canCreateProject(): bool
    {
        return PermissionHelper::has('projects.create') && self::allowsByCreationPolicy(self::projectCreationPolicy());
    }

    public static function canCreateTask(): bool
    {
        return PermissionHelper::has('tasks.create') && self::allowsByCreationPolicy(self::taskCreationPolicy());
    }

    public static function canEditTimeForOthers(): bool
    {
        if (!PermissionHelper::has('time.edit_all')) {
            return false;
        }

        if (AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            return true;
        }

        return self::editTimeOthersPolicy() === 'admins_team_managers'
            && AuthHelper::hasRole(AuthHelper::ROLE_MANAGER);
    }

    public static function requireCanCreateProject(): void
    {
        if (!self::canCreateProject()) {
            self::deny(403, 'project_creation_policy');
        }
    }

    public static function requireCanCreateTask(): void
    {
        if (!self::canCreateTask()) {
            self::deny(403, 'task_creation_policy');
        }
    }

    public static function requireCanEditTimeForOthers(): void
    {
        if (!self::canEditTimeForOthers()) {
            self::deny(403, 'edit_time_others_policy');
        }
    }

    public static function assertCanMutateTimeEntry(int $ownerId): void
    {
        // Permission time.edit_all is not enough; edit_time_others_policy must also allow the actor.
        if ($ownerId === (int) AuthHelper::id()) {
            return;
        }

        self::requireCanEditTimeForOthers();
    }

    public static function appliesRegularTimeVisibility(): bool
    {
        return AuthHelper::check()
            && !PermissionHelper::has('time.view_all')
            && !FeatureFlagsHelper::isPrivileged();
    }

    public static function canBrowseOthersTime(): bool
    {
        if (PermissionHelper::has('time.view_all')) {
            return true;
        }

        return self::appliesRegularTimeVisibility()
            && self::regularUserTimeVisibility() !== 'own';
    }

    /**
     * Restrict time rows a regular user may see. Privileged callers must not use this.
     *
     * @return array{0: string, 1: array<string, mixed>}
     */
    public static function regularTimeVisibilityClause(
        int $viewerId,
        string $projectAlias = 'p',
        string $entryUserExpr = 'te.user_id'
    ): array {
        $alias = preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $projectAlias) === 1 ? $projectAlias : 'p';
        $userExpr = preg_match('/^[A-Za-z_][A-Za-z0-9_]*\.[A-Za-z_][A-Za-z0-9_]*$/', $entryUserExpr) === 1
            ? $entryUserExpr
            : 'te.user_id';

        $mode = self::regularUserTimeVisibility();
        if ($viewerId < 1 || $mode === 'own' || ($mode === 'public' && !Project::extrasReady())) {
            return [$userExpr . ' = :rtv_viewer', ['rtv_viewer' => $viewerId]];
        }

        if ($mode === 'public') {
            return [
                '(' . $userExpr . ' = :rtv_viewer OR `' . $alias . '`.`is_public` = 1)',
                ['rtv_viewer' => $viewerId],
            ];
        }

        $public = Project::extrasReady() ? ' OR `' . $alias . '`.`is_public` = 1' : '';

        return [
            '(' . $userExpr . ' = :rtv_viewer
                OR `' . $alias . '`.`manager_id` = :rtv_mgr
                OR `' . $alias . '`.`created_by` = :rtv_creator
                OR EXISTS (
                    SELECT 1 FROM project_members pm
                    WHERE pm.project_id = `' . $alias . '`.id AND pm.user_id = :rtv_member
                )' . $public . ')',
            [
                'rtv_viewer'  => $viewerId,
                'rtv_mgr'     => $viewerId,
                'rtv_creator' => $viewerId,
                'rtv_member'  => $viewerId,
            ],
        ];
    }

    public static function roundSeconds(int $seconds): int
    {
        $minutes = self::timeRoundingMinutes();
        if ($minutes <= 1) {
            return max(0, $seconds);
        }

        $step = $minutes * 60;

        return max(0, (int) (round($seconds / $step) * $step));
    }

    public static function weekModifier(): string
    {
        return self::weekStart() === 'sunday' ? 'Sunday this week' : 'Monday this week';
    }

    private static function deny(int $status, string $feature): never
    {
        LoggerHelper::warning('Workspace policy denied', [
            'user_id' => AuthHelper::id(),
            'feature' => $feature,
            'status'  => $status,
        ]);

        throw new HttpException($status);
    }
}
