<?php
/**
 * Reusable HTML/text email templates with {{variable}} substitution.
 *
 * Variables are HTML-escaped in the HTML body and left plain in the text body.
 * Unknown variables become empty strings. Invitation tokens never enter a template
 * except as a fully formed invitation_url.
 */

declare(strict_types=1);

final class MailTemplate
{
    public const INVITATION = 'invitation';
    public const INVITATION_RESENT = 'invitation_resent';
    public const WELCOME = 'welcome';
    public const PASSWORD_RESET = 'password_reset';
    public const ASSIGNMENT = 'assignment';

    /**
     * @param array<string, mixed> $vars
     * @return array{subject: string, html: string, text: string}
     */
    public static function render(string $name, array $vars): array
    {
        $vars = self::normalize($vars);
        $spec = self::spec($name, $vars);

        return [
            'subject' => self::replace($spec['subject'], $vars, false),
            'html' => self::layout(self::replace($spec['html'], $vars, true), $vars),
            'text' => self::replace($spec['text'], $vars, false),
        ];
    }

    /**
     * @param array<string, mixed> $vars
     * @return array<string, string>
     */
    private static function normalize(array $vars): array
    {
        $out = [];
        foreach ($vars as $key => $value) {
            if (is_array($value)) {
                $value = implode("\n", array_map(static fn ($item): string => (string) $item, $value));
            }
            $out[(string) $key] = (string) $value;
        }

        $out['company_name'] = $out['company_name'] ?? SettingsService::appName();
        $out['support_email'] = $out['support_email'] ?? SmtpSettings::replyTo();
        $out['year'] = $out['year'] ?? gmdate('Y');

        return $out;
    }

    /**
     * @param array<string, string> $vars
     * @return array{subject: string, html: string, text: string}
     */
    private static function spec(string $name, array $vars): array
    {
        return match ($name) {
            self::INVITATION, self::INVITATION_RESENT => self::invitation($name === self::INVITATION_RESENT),
            self::WELCOME => self::welcome(),
            self::PASSWORD_RESET => self::passwordReset(),
            self::ASSIGNMENT => self::assignment(),
            default => throw new InvalidArgumentException('Unknown email template.'),
        };
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function invitation(bool $resent): array
    {
        $subject = $resent
            ? '{{company_name}}: your invitation was resent'
            : '{{company_name}}: you have been invited';

        $lead = $resent
            ? 'Your invitation to join {{company_name}} was resent. The previous link no longer works.'
            : 'You have been invited to join {{company_name}}.';

        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">{$lead}</p>
<p style="margin:0 0 16px;">Your account has been prepared with the following access:</p>
<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 20px;width:100%;">
  <tr><td style="padding:4px 0;color:#5b6d6c;width:120px;">Role</td><td style="padding:4px 0;"><strong>{{role}}</strong></td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;">Team</td><td style="padding:4px 0;">{{team}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;vertical-align:top;">Projects</td><td style="padding:4px 0;">{{projects_html}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;vertical-align:top;">Tasks</td><td style="padding:4px 0;">{{tasks_html}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;">Invited by</td><td style="padding:4px 0;">{{invited_by}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;">Expires</td><td style="padding:4px 0;">{{expiry_date}}</td></tr>
</table>
<p style="margin:0 0 24px;">Click the button below to activate your account and create your password. This link can be used only once.</p>
<p style="margin:0 0 24px;text-align:center;">
  <a href="{{invitation_url}}" style="display:inline-block;background:#0b7a75;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:6px;font-weight:600;">Accept invitation</a>
</p>
<p style="margin:0;color:#5b6d6c;font-size:13px;">If the button does not work, copy this address into your browser:<br>{{invitation_url}}</p>
HTML;

        $text = "Hello {{user_name}},\n\n{$lead}\n\n"
            . "Role: {{role}}\nTeam: {{team}}\nProjects:\n{{projects}}\nTasks:\n{{tasks}}\n"
            . "Invited by: {{invited_by}}\nExpires: {{expiry_date}}\n\n"
            . "Activate your account (single-use link):\n{{invitation_url}}\n";

        return ['subject' => $subject, 'html' => $html, 'text' => $text];
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function welcome(): array
    {
        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">Your {{company_name}} account is now active. You can sign in with {{email}}.</p>
<p style="margin:0 0 24px;text-align:center;">
  <a href="{{login_url}}" style="display:inline-block;background:#0b7a75;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:6px;font-weight:600;">Sign in</a>
</p>
HTML;
        $text = "Hello {{user_name}},\n\nYour {{company_name}} account is now active. Sign in at {{login_url}} with {{email}}.\n";

        return [
            'subject' => 'Welcome to {{company_name}}',
            'html' => $html,
            'text' => $text,
        ];
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function passwordReset(): array
    {
        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">A password reset was requested for your {{company_name}} account.</p>
<p style="margin:0 0 24px;text-align:center;">
  <a href="{{reset_url}}" style="display:inline-block;background:#0b7a75;color:#ffffff;text-decoration:none;padding:12px 28px;border-radius:6px;font-weight:600;">Reset password</a>
</p>
<p style="margin:0;color:#5b6d6c;font-size:13px;">This link expires on {{expiry_date}}. If you did not request a reset, you can ignore this email.</p>
HTML;
        $text = "Hello {{user_name}},\n\nReset your {{company_name}} password: {{reset_url}}\nExpires: {{expiry_date}}\n";

        return [
            'subject' => '{{company_name}} password reset',
            'html' => $html,
            'text' => $text,
        ];
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function assignment(): array
    {
        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">{{invited_by}} updated your access on {{company_name}}.</p>
<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 20px;width:100%;">
  <tr><td style="padding:4px 0;color:#5b6d6c;width:120px;">Role</td><td style="padding:4px 0;"><strong>{{role}}</strong></td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;">Team</td><td style="padding:4px 0;">{{team}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;vertical-align:top;">Projects</td><td style="padding:4px 0;">{{projects_html}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;vertical-align:top;">Tasks</td><td style="padding:4px 0;">{{tasks_html}}</td></tr>
</table>
HTML;
        $text = "Hello {{user_name}},\n\n{{invited_by}} updated your access.\nRole: {{role}}\nTeam: {{team}}\nProjects:\n{{projects}}\nTasks:\n{{tasks}}\n";

        return [
            'subject' => '{{company_name}}: your access was updated',
            'html' => $html,
            'text' => $text,
        ];
    }

    /**
     * @param array<string, string> $vars
     */
    private static function layout(string $inner, array $vars): string
    {
        $company = htmlspecialchars($vars['company_name'] ?? 'TimeTrack', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $support = htmlspecialchars($vars['support_email'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $year = htmlspecialchars($vars['year'] ?? gmdate('Y'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $supportLine = $support !== ''
            ? '<p style="margin:16px 0 0;color:#5b6d6c;font-size:13px;">Questions? Contact ' . $support . '.</p>'
            : '';

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f3f5f2;font-family:system-ui,-apple-system,'Segoe UI',Roboto,Arial,sans-serif;color:#17282a;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f5f2;padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #dde3df;">
        <tr><td style="background:#0f2a2b;color:#ffffff;padding:20px 28px;font-size:18px;font-weight:600;">{$company}</td></tr>
        <tr><td style="padding:28px;">{$inner}{$supportLine}</td></tr>
        <tr><td style="padding:16px 28px;background:#f8faf9;color:#5b6d6c;font-size:12px;">&copy; {$year} {$company}</td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
    }

    /**
     * @param array<string, string> $vars
     */
    private static function replace(string $template, array $vars, bool $escapeHtml): string
    {
        return (string) preg_replace_callback('/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/', static function (array $m) use ($vars, $escapeHtml): string {
            $value = $vars[$m[1]] ?? '';
            if ($escapeHtml && !str_ends_with($m[1], '_html') && !str_ends_with($m[1], '_url')) {
                return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            }

            return $value;
        }, $template);
    }
}
