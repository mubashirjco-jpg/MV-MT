<?php
/**
 * Bulk data reset ("fresh start") and the SQL backup that goes with it.
 *
 * What it can remove is a fixed, hard-coded list of application tables grouped by
 * topic. Nothing is ever built from user input: the request only picks group keys,
 * which are validated against GROUPS, expanded to include every group they depend on,
 * and mapped to table names defined in this file. Table names are therefore never
 * attacker-controlled, so interpolating them (with backticks) into SQL is safe.
 *
 * Never touched, in any mode: roles, permissions, role_permissions, settings,
 * workspaces, workspace_settings, and the logged-in admin's own account.
 *
 * Used only by DataResetController (Admin role + workspace.manage permission).
 */

declare(strict_types=1);

final class DataResetHelper
{
    /** Exact phrase the admin must type to confirm. */
    public const CONFIRM_PHRASE = 'RESET DATA';

    /** Wrong confirmations allowed before a cool-down, and the cool-down length. */
    public const MAX_FAILURES = 5;
    public const LOCK_SECONDS = 900;

    /** Rows per INSERT statement and per SELECT chunk in the backup file. */
    private const BACKUP_CHUNK = 500;

    /**
     * Group definitions, in DELETION order (child data first, parents last).
     *
     *  label    - shown in the UI
     *  help     - one-line description shown under the label
     *  tables   - tables cleared by this group, children first
     *  requires - groups that must be cleared together with this one, because their
     *             rows point at this group's rows (clearing only this group would
     *             leave dangling references)
     *  keepUser - the 'users' group never deletes the logged-in admin
     *
     * @var array<string, array{label: string, help: string, tables: list<string>, requires: list<string>, keepUser?: bool}>
     */
    private const GROUPS = [
        'time' => [
            'label'    => 'Time data',
            'help'     => 'Time entries, running timers, idle events and all timesheets (submitted, approved, rejected).',
            'tables'   => ['timer_idle_events', 'timesheet_entries', 'timesheets', 'active_timers', 'time_entries'],
            'requires' => [],
        ],
        'schedule' => [
            'label'    => 'Schedule',
            'help'     => 'Planned schedule blocks and their recurrence rules.',
            'tables'   => ['schedule_recurrences', 'schedules'],
            'requires' => [],
        ],
        'tasks' => [
            'label'    => 'Tasks',
            'help'     => 'All tasks and task assignees. Needs time data and schedule cleared too.',
            'tables'   => ['task_assignees', 'tasks'],
            'requires' => ['time', 'schedule'],
        ],
        'projects' => [
            'label'    => 'Projects',
            'help'     => 'All projects, project members and favourites. Needs tasks, time data and schedule cleared too.',
            'tables'   => ['project_favorites', 'project_members', 'projects'],
            'requires' => ['tasks'],
        ],
        'clients' => [
            'label'    => 'Clients',
            'help'     => 'All clients and client portal logins. Needs projects (and everything under them) cleared too.',
            'tables'   => ['client_users', 'clients'],
            'requires' => ['projects'],
        ],
        'logs' => [
            'label'    => 'Notifications & audit log',
            'help'     => 'In-app notifications and the audit trail. This reset itself is logged again afterwards.',
            'tables'   => ['notifications', 'activity_logs'],
            'requires' => [],
        ],
        'agents' => [
            'label'    => 'Desktop agent devices',
            'help'     => 'Paired desktop agent devices, pairing codes and pairing attempts.',
            'tables'   => ['desktop_agent_pairing_codes', 'agent_pair_attempts', 'desktop_agent_devices'],
            'requires' => [],
        ],
        'users' => [
            'label'    => 'Users',
            'help'     => 'Every user account EXCEPT yours. Needs everything above cleared too, so nothing points at a deleted user.',
            'tables'   => ['users'],
            'requires' => ['time', 'schedule', 'tasks', 'projects', 'clients', 'logs', 'agents'],
            'keepUser' => true,
        ],
    ];

    /* ------------------------------------------------------------------ metadata */

    /**
     * Group metadata plus the number of rows each group would remove.
     *
     * @return array<string, array{label: string, help: string, requires: list<string>, rows: int}>
     */
    public static function overview(int $keepUserId): array
    {
        $out = [];
        foreach (self::GROUPS as $key => $group) {
            $out[$key] = [
                'label'    => $group['label'],
                'help'     => $group['help'],
                'requires' => $group['requires'],
                'rows'     => self::countGroup($key, $keepUserId),
            ];
        }

        return $out;
    }

    /** True when $key is a known group. */
    public static function isGroup(string $key): bool
    {
        return isset(self::GROUPS[$key]);
    }

    /**
     * Turn raw request input into a validated, dependency-complete group list in
     * deletion order. Unknown keys are dropped; every required group is added.
     *
     * @param mixed $input Typically $_POST['groups'] (array of group keys)
     * @return list<string>
     */
    public static function normalize(mixed $input): array
    {
        if (!is_array($input)) {
            return [];
        }

        $selected = [];
        foreach ($input as $key) {
            if (is_string($key) && isset(self::GROUPS[$key])) {
                $selected[$key] = true;
            }
        }

        // Expand dependencies until nothing new is added (graph is tiny and acyclic).
        do {
            $before = count($selected);
            foreach (array_keys($selected) as $key) {
                foreach (self::GROUPS[$key]['requires'] as $required) {
                    $selected[$required] = true;
                }
            }
        } while (count($selected) > $before);

        // Re-emit in canonical deletion order.
        return array_values(array_filter(
            array_keys(self::GROUPS),
            static fn (string $key): bool => isset($selected[$key])
        ));
    }

    /**
     * Existing tables for the given groups, in deletion order.
     *
     * @param list<string> $groups Output of normalize()
     * @return list<string>
     */
    public static function tablesFor(array $groups): array
    {
        $tables = [];
        foreach ($groups as $key) {
            foreach (self::GROUPS[$key]['tables'] ?? [] as $table) {
                if (SchemaHelper::tableExists($table)) {
                    $tables[] = $table;
                }
            }
        }

        return $tables;
    }

    /* ------------------------------------------------------------------ counting */

    private static function countGroup(string $key, int $keepUserId): int
    {
        $total = 0;
        foreach (self::GROUPS[$key]['tables'] as $table) {
            if (!SchemaHelper::tableExists($table)) {
                continue;
            }

            if ($table === 'users') {
                $total += (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM `users` WHERE id <> :keep',
                    ['keep' => $keepUserId]
                );
                continue;
            }

            $total += (int) Database::fetchValue('SELECT COUNT(*) FROM `' . $table . '`');
        }

        return $total;
    }

    /* ------------------------------------------------------------------ reset */

    /**
     * Delete all rows of the selected groups in ONE transaction.
     *
     * Foreign key checks are switched off only for this connection while rows are
     * removed (the selected groups are always dependency-complete, so no dangling
     * references are left) and are ALWAYS switched back on afterwards. If anything
     * fails the transaction rolls back and nothing is deleted.
     *
     * @param list<string> $groups Output of normalize()
     * @return array<string, int> table => rows deleted
     */
    public static function reset(array $groups, int $keepUserId): array
    {
        if ($groups === [] || $keepUserId < 1) {
            throw new InvalidArgumentException('Nothing to reset.');
        }

        $deleted = [];

        Database::query('SET FOREIGN_KEY_CHECKS = 0');
        try {
            Database::transaction(function () use ($groups, $keepUserId, &$deleted): void {
                foreach ($groups as $key) {
                    foreach (self::GROUPS[$key]['tables'] as $table) {
                        if (!SchemaHelper::tableExists($table)) {
                            continue;
                        }

                        $deleted[$table] = $table === 'users'
                            ? Database::execute('DELETE FROM `users` WHERE id <> :keep', ['keep' => $keepUserId])
                            : Database::execute('DELETE FROM `' . $table . '`');
                    }
                }
            });
        } finally {
            // Must never stay off for the rest of the request, even after an exception.
            Database::query('SET FOREIGN_KEY_CHECKS = 1');
        }

        // Fresh numbering (IDs start from 1 again). DDL commits implicitly, so it runs
        // after the transaction. Failures here are cosmetic and ignored.
        foreach (array_keys($deleted) as $table) {
            try {
                Database::query('ALTER TABLE `' . $table . '` AUTO_INCREMENT = 1');
            } catch (Throwable $e) {
                LoggerHelper::debug('AUTO_INCREMENT reset skipped', ['table' => $table, 'error' => $e->getMessage()]);
            }
        }

        return $deleted;
    }

    /* ------------------------------------------------------------------ backup */

    /**
     * Stream a restorable .sql file (INSERT statements only) with the current rows of
     * every table the selected groups would clear, then end the request.
     *
     * The file contains the full users table when the Users group is selected,
     * INCLUDING password hashes, so the UI warns the admin to store it securely.
     *
     * @param list<string> $groups Output of normalize()
     */
    public static function streamBackup(array $groups): never
    {
        $tables = array_reverse(self::tablesFor($groups)); // parents first so it restores cleanly
        $pdo    = Database::connection();

        // Free the session lock so other tabs are not blocked during a long download.
        AuthHelper::releaseSession();
        @set_time_limit(300);
        while (ob_get_level() > 0) {
            ob_end_clean();
        }

        $filename = 'timetrack-backup-' . gmdate('Ymd-His') . '.sql';
        header('Content-Type: application/sql; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate');
        header('Pragma: no-cache');

        echo "-- TimeTrack data backup (UTC " . gmdate('Y-m-d H:i:s') . ")\n";
        echo "-- Groups: " . implode(', ', $groups) . "\n";
        echo "-- Restore: import this file into the same database AFTER a reset.\n";
        echo "-- Contains personal data" . (in_array('users', $groups, true) ? " and password hashes" : '') . ". Store it securely.\n\n";
        echo "SET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n";

        foreach ($tables as $table) {
            echo "-- Table `" . $table . "`\n";

            for ($offset = 0; ; $offset += self::BACKUP_CHUNK) {
                $rows = Database::fetchAll(
                    'SELECT * FROM `' . $table . '` ORDER BY 1 LIMIT ' . self::BACKUP_CHUNK . ' OFFSET ' . $offset
                );
                if ($rows === []) {
                    break;
                }

                $columns = '`' . implode('`,`', array_map(
                    static fn (string $c): string => str_replace('`', '``', $c),
                    array_keys($rows[0])
                )) . '`';

                $values = [];
                foreach ($rows as $row) {
                    $values[] = '(' . implode(',', array_map(
                        static fn (mixed $v): string => $v === null ? 'NULL' : $pdo->quote((string) $v),
                        array_values($row)
                    )) . ')';
                }

                echo 'INSERT INTO `' . $table . '` (' . $columns . ") VALUES\n" . implode(",\n", $values) . ";\n";
                flush();

                if (count($rows) < self::BACKUP_CHUNK) {
                    break;
                }
            }

            echo "\n";
        }

        echo "SET FOREIGN_KEY_CHECKS = 1;\n";
        exit;
    }
}
