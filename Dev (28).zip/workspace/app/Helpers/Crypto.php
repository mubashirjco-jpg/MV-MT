<?php
/**
 * Symmetric encryption for secrets stored in the database (SMTP password).
 *
 * Uses AES-256-GCM keyed from APP_KEY. Ciphertext is never logged. Failures
 * return null so callers can treat a missing/unreadable secret as "not set".
 */

declare(strict_types=1);

final class CryptoHelper
{
    private const PREFIX = 'v1:';
    private const CIPHER = 'aes-256-gcm';

    public static function encrypt(string $plaintext): ?string
    {
        if ($plaintext === '') {
            return '';
        }

        $key = self::key();
        if ($key === null) {
            return null;
        }

        $iv = random_bytes(12);
        $tag = '';
        $cipher = openssl_encrypt($plaintext, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv, $tag, '', 16);
        if ($cipher === false || $tag === '') {
            return null;
        }

        return self::PREFIX . base64_encode($iv . $tag . $cipher);
    }

    public static function decrypt(?string $payload): ?string
    {
        if ($payload === null || $payload === '') {
            return '';
        }

        if (!str_starts_with($payload, self::PREFIX)) {
            return null;
        }

        $key = self::key();
        if ($key === null) {
            return null;
        }

        $raw = base64_decode(substr($payload, strlen(self::PREFIX)), true);
        if ($raw === false || strlen($raw) < 29) {
            return null;
        }

        $iv = substr($raw, 0, 12);
        $tag = substr($raw, 12, 16);
        $cipher = substr($raw, 28);
        $plain = openssl_decrypt($cipher, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv, $tag);
        if ($plain === false) {
            return null;
        }

        return $plain;
    }

    public static function isEncrypted(?string $payload): bool
    {
        return is_string($payload) && str_starts_with($payload, self::PREFIX);
    }

    private static function key(): ?string
    {
        $secret = (string) Config::get('app.key', '');
        if ($secret === '' || str_starts_with($secret, 'CHANGE_ME')) {
            LoggerHelper::warning('Crypto unavailable: APP_KEY is not configured');
            return null;
        }

        return hash('sha256', $secret, true);
    }
}
