<?php
/**
 * Team page (Phase 14): members, roles, the projects each person is on and weekly workload.
 *
 *   GET /team          directory + workload for one week (?week=Y-m-d, filters, sort)
 *   GET /team/{id}     one member: projects, 6-week workload trend, open tasks
 *
 * Read-only: there is no POST route, so nothing here needs CSRF handling.
 *
 * Access
 *   - admin, manager and employee roles only (clients never see the team).
 *   - Gated by the existing "team" workspace switch (FeatureFlagsHelper::requireTeam).
 *   - People and projects are scoped by Team::people / Team::projectsByUser.
 *   - Hours and task counts for OTHER people need schedule.view_team (admin, manager);
 *     an employee sees the directory but only their own workload.
 */

declare(strict_types=1);

final class TeamController extends Controller
{
    private Team $team;

    public function __construct()
    {
        parent::__construct(true, [
            AuthHelper::ROLE_ADMIN,
            AuthHelper::ROLE_MANAGER,
            AuthHelper::ROLE_EMPLOYEE,
        ]);

        PermissionHelper::require('projects.view');
        FeatureFlagsHelper::requireTeam();

        $this->team = new Team();
    }

    /** GET /team */
    public function index(Request $request, array $params): void
    {
        $viewerId    = (int) AuthHelper::id();
        $viewAll     = PermissionHelper::has('projects.view_all');
        $canWorkload = PermissionHelper::has('schedule.view_team');
        $planning    = FeatureFlagsHelper::schedulingEnabled() && Team::schedulesReady();

        [$weekStart, $weekEnd] = $this->weekBounds((string) $request->input('week', ''));
        [$startUtc, $endUtc]   = $this->utcRange($weekStart, $weekEnd);

        $projectOptions = $this->team->projectOptions($viewerId, $viewAll);
        $validProjects  = array_map(static fn (array $p): int => (int) $p['id'], $projectOptions);

        $projectFilter = (int) $request->input('project', 0);
        if (!in_array($projectFilter, $validProjects, true)) {
            $projectFilter = 0; // never filter by a project the viewer cannot see
        }

        $filters = [
            'q'       => mb_substr(trim((string) $request->input('q', '')), 0, 80),
            'role'    => (string) $request->input('role', ''),
            'status'  => (string) $request->input('status', 'active'),
            'project' => $projectFilter,
        ];
        if (!in_array($filters['role'], ['admin', 'manager', 'employee'], true)) {
            $filters['role'] = '';
        }
        if (!in_array($filters['status'], ['active', 'inactive', 'suspended', 'all'], true)) {
            $filters['status'] = 'active';
        }

        $sort = (string) $request->input('sort', 'name');
        if (!in_array($sort, ['name', 'load', 'projects'], true)) {
            $sort = 'name';
        }

        $people = $this->team->people($filters, $viewerId, $viewAll);
        $ids    = array_map(static fn (array $p): int => (int) $p['id'], $people);

        // Workload numbers of other people are only for roles that may view the team schedule.
        $loadIds = $canWorkload ? $ids : array_values(array_intersect($ids, [$viewerId]));

        $projects = $this->safe(fn (): array => $this->team->projectsByUser($ids, $viewerId, $viewAll), []);
        $planned  = $planning
            ? $this->safe(fn (): array => $this->team->planned($loadIds, $startUtc, $endUtc, $viewerId, $viewAll), [])
            : [];
        $tracked  = $this->safe(fn (): array => $this->team->tracked($loadIds, $startUtc, $endUtc, $viewerId, $viewAll), []);
        [$todayStart, $todayEnd] = $this->utcRange(
            (new DateTimeImmutable('today', new DateTimeZone(FormatHelper::displayTimezone())))->setTime(0, 0, 0),
            (new DateTimeImmutable('today', new DateTimeZone(FormatHelper::displayTimezone())))->modify('+1 day')->setTime(0, 0, 0)
        );
        $todayTracked = $this->safe(
            fn (): array => $this->team->tracked($loadIds, $todayStart, $todayEnd, $viewerId, $viewAll),
            []
        );
        $tasks    = $this->safe(
            fn (): array => $this->team->taskCounts($loadIds, $this->todayLocal(), $viewerId, $viewAll),
            []
        );

        $capacity = $this->weeklyCapacitySeconds();
        $rows     = [];
        foreach ($people as $person) {
            $uid     = (int) $person['id'];
            $hasLoad = in_array($uid, $loadIds, true);
            $rows[]  = $person + $this->workloadFigures(
                $hasLoad,
                $planning,
                (int) ($planned[$uid]['planned_seconds'] ?? 0),
                (int) ($planned[$uid]['blocks'] ?? 0),
                (int) ($tracked[$uid] ?? 0),
                $capacity
            ) + [
                'projects'        => $projects[$uid] ?? [],
                'open_tasks'      => (int) ($tasks[$uid]['open'] ?? 0),
                'overdue'         => (int) ($tasks[$uid]['overdue'] ?? 0),
                'today_seconds'   => $hasLoad ? (int) ($todayTracked[$uid] ?? 0) : 0,
                'today_shared'    => $hasLoad,
            ];
        }

        usort($rows, static function (array $a, array $b) use ($sort): int {
            return match ($sort) {
                'load'     => [$b['load_seconds'], $a['name']] <=> [$a['load_seconds'], $b['name']],
                'projects' => [count($b['projects']), $a['name']] <=> [count($a['projects']), $b['name']],
                default    => strcasecmp((string) $a['name'], (string) $b['name']),
            };
        });

        $this->render('team/index', [
            'pageTitle'      => 'Team',
            'rows'           => $rows,
            'summary'        => $this->summary($rows, $capacity),
            'filters'        => $filters + ['sort' => $sort],
            'projectOptions' => $projectOptions,
            'weekStart'      => $weekStart,
            'weekEnd'        => $weekEnd,
            'prevWeek'       => $weekStart->modify('-7 days')->format('Y-m-d'),
            'nextWeek'       => $weekStart->modify('+7 days')->format('Y-m-d'),
            'isThisWeek'     => $weekStart->format('Y-m-d') === $this->weekBounds('')[0]->format('Y-m-d'),
            'capacityHours'  => $capacity / 3600,
            'planning'       => $planning,
            'canWorkload'    => $canWorkload,
            'viewerId'       => $viewerId,
        ]);
    }

    /** GET /team/{id} */
    public function show(Request $request, array $params): void
    {
        $id       = (int) ($params['id'] ?? 0);
        $viewerId = (int) AuthHelper::id();
        $viewAll  = PermissionHelper::has('projects.view_all');

        $person = $id > 0 ? $this->team->person($id, $viewerId, $viewAll) : null;
        if ($person === null) {
            $this->notFound(); // not on the team, or not someone the viewer may see
        }

        $canLoad  = PermissionHelper::has('schedule.view_team') || $id === $viewerId;
        $planning = FeatureFlagsHelper::schedulingEnabled() && Team::schedulesReady();
        $capacity = $this->weeklyCapacitySeconds();

        [$weekStart, $weekEnd] = $this->weekBounds((string) $request->input('week', ''));
        [$startUtc, $endUtc]   = $this->utcRange($weekStart, $weekEnd);

        $projects = $this->safe(fn (): array => $this->team->projectsByUser([$id], $viewerId, $viewAll), [])[$id] ?? [];

        $perProject = $canLoad
            ? $this->safe(fn (): array => $this->team->perProject($id, $startUtc, $endUtc, $viewerId, $viewAll, $planning), [])
            : [];

        $trend = [];
        $tasks = [];
        $week  = $this->workloadFigures(false, $planning, 0, 0, 0, $capacity);

        if ($canLoad) {
            $planned = $planning
                ? $this->safe(fn (): array => $this->team->planned([$id], $startUtc, $endUtc, $viewerId, $viewAll), [])
                : [];
            $tracked = $this->safe(fn (): array => $this->team->tracked([$id], $startUtc, $endUtc, $viewerId, $viewAll), []);
            $week    = $this->workloadFigures(
                true,
                $planning,
                (int) ($planned[$id]['planned_seconds'] ?? 0),
                (int) ($planned[$id]['blocks'] ?? 0),
                (int) ($tracked[$id] ?? 0),
                $capacity
            );

            // Six weeks: three back, this one, two ahead.
            for ($offset = -3; $offset <= 2; $offset++) {
                $from = $weekStart->modify(($offset >= 0 ? '+' : '') . ($offset * 7) . ' days');
                $to   = $from->modify('+7 days');
                [$fromUtc, $toUtc] = $this->utcRange($from, $to);

                $p = $planning
                    ? $this->safe(fn (): array => $this->team->planned([$id], $fromUtc, $toUtc, $viewerId, $viewAll), [])
                    : [];
                $t = $this->safe(fn (): array => $this->team->tracked([$id], $fromUtc, $toUtc, $viewerId, $viewAll), []);

                $trend[] = [
                    'start'   => $from,
                    'planned' => (int) ($p[$id]['planned_seconds'] ?? 0),
                    'tracked' => (int) ($t[$id] ?? 0),
                    'current' => $offset === 0,
                ];
            }

            $tasks = $this->safe(fn (): array => $this->team->openTasks($id, $viewerId, $viewAll, 10), []);
        }

        $today = $this->todayLocal();
        $this->render('team/show', [
            'pageTitle'  => (string) $person['name'],
            'person'     => $person,
            'projects'   => $projects,
            'perProject' => $perProject,
            'week'       => $week,
            'trend'      => $trend,
            'tasks'      => $tasks,
            'overdue'    => count(array_filter(
                $tasks,
                static fn (array $t): bool => !empty($t['due_date']) && (string) $t['due_date'] < $today
            )),
            'today'      => $today,
            'weekStart'  => $weekStart,
            'weekEnd'    => $weekEnd,
            'prevWeek'   => $weekStart->modify('-7 days')->format('Y-m-d'),
            'nextWeek'   => $weekStart->modify('+7 days')->format('Y-m-d'),
            'isThisWeek' => $weekStart->format('Y-m-d') === $this->weekBounds('')[0]->format('Y-m-d'),
            'capacityHours' => $capacity / 3600,
            'planning'   => $planning,
            'canLoad'    => $canLoad,
            'isSelf'     => $id === $viewerId,
        ]);
    }

    /* ------------------------------------------------------------------ helpers */

    /**
     * Turns raw seconds into the figures the views show.
     *
     * The measure that fills the capacity bar is planned time when scheduling is on and
     * tracked time otherwise, so the page stays useful on workspaces that do not plan.
     *
     * @return array<string, mixed>
     */
    private function workloadFigures(bool $hasLoad, bool $planning, int $planned, int $blocks, int $tracked, int $capacity): array
    {
        if (!$hasLoad) {
            return [
                'has_load' => false, 'planned_seconds' => 0, 'tracked_seconds' => 0, 'blocks' => 0,
                'load_seconds' => 0, 'load_percent' => 0, 'load_state' => 'hidden', 'load_label' => '',
            ];
        }

        $load    = $planning ? $planned : $tracked;
        $percent = $capacity > 0 ? (int) round($load / $capacity * 100) : 0;

        if ($load <= 0) {
            [$state, $label] = ['none', $planning ? 'Nothing planned' : 'No time tracked'];
        } elseif ($percent < 60) {
            [$state, $label] = ['available', 'Available'];
        } elseif ($percent <= 100) {
            [$state, $label] = ['balanced', 'Balanced'];
        } else {
            [$state, $label] = ['over', 'Over capacity'];
        }

        return [
            'has_load'        => true,
            'planned_seconds' => $planned,
            'tracked_seconds' => $tracked,
            'blocks'          => $blocks,
            'load_seconds'    => $load,
            'load_percent'    => $percent,
            'load_state'      => $state,
            'load_label'      => $label,
        ];
    }

    /**
     * Headline numbers over the people whose workload the viewer may see.
     *
     * @param list<array<string, mixed>> $rows
     * @return array<string, mixed>
     */
    private function summary(array $rows, int $capacity): array
    {
        $counted = array_values(array_filter($rows, static fn (array $r): bool => !empty($r['has_load'])));
        $load    = array_sum(array_column($counted, 'load_seconds'));
        $tracked = array_sum(array_column($counted, 'tracked_seconds'));
        $planned = array_sum(array_column($counted, 'planned_seconds'));
        $over    = count(array_filter($counted, static fn (array $r): bool => $r['load_state'] === 'over'));
        $free    = count(array_filter($counted, static fn (array $r): bool => in_array($r['load_state'], ['available', 'none'], true)));

        return [
            'members'     => count($rows),
            'counted'     => count($counted),
            'planned'     => (int) $planned,
            'tracked'     => (int) $tracked,
            'avg_percent' => ($counted !== [] && $capacity > 0)
                ? (int) round($load / (count($counted) * $capacity) * 100)
                : 0,
            'over'        => $over,
            'available'   => $free,
            'overdue'     => (int) array_sum(array_column($rows, 'overdue')),
        ];
    }

    /** Workspace daily capacity (Workspace → Policies) times five working days. */
    private function weeklyCapacitySeconds(): int
    {
        return WorkspacePolicy::dailyCapacitySeconds() * Team::WORK_DAYS;
    }

    /**
     * Start (inclusive) and end (exclusive) of the week in the display timezone,
     * using the same week-start rule as the Team schedule page.
     *
     * @return array{0: DateTimeImmutable, 1: DateTimeImmutable}
     */
    private function weekBounds(string $value): array
    {
        $zone   = new DateTimeZone(FormatHelper::displayTimezone());
        $anchor = new DateTimeImmutable('today', $zone);

        if ($value !== '') {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $zone);
            $errors = DateTimeImmutable::getLastErrors();
            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                $anchor = $parsed;
            }
        }

        $start = $anchor->modify(WorkspacePolicy::weekModifier())->setTime(0, 0, 0);

        return [$start, $start->modify('+7 days')];
    }

    /** @return array{0: string, 1: string} UTC "Y-m-d H:i:s" pair */
    private function utcRange(DateTimeImmutable $from, DateTimeImmutable $to): array
    {
        $utc = new DateTimeZone('UTC');

        return [
            $from->setTimezone($utc)->format('Y-m-d H:i:s'),
            $to->setTimezone($utc)->format('Y-m-d H:i:s'),
        ];
    }

    private function todayLocal(): string
    {
        return (new DateTimeImmutable('today', new DateTimeZone(FormatHelper::displayTimezone())))->format('Y-m-d');
    }

    /**
     * Runs one optional data block. A failure (for example a table from a phase that is not
     * installed yet) is logged and replaced by $fallback so the rest of the page still renders.
     *
     * @template T
     * @param callable(): T $callback
     * @param T $fallback
     * @return T
     */
    private function safe(callable $callback, mixed $fallback): mixed
    {
        try {
            return $callback();
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return $fallback;
        }
    }
}
