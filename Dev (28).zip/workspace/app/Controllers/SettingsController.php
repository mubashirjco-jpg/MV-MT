<?php
/**
 * Global/system settings: identity, formats, billing defaults, timezone, timer cap.
 * Workspace identity and workspace policies are managed separately under /workspace.
 *
 * Settings live in the key/value `settings` table. Only SYSTEM_DEFAULTS keys can be
 * written from this screen, so a crafted POST cannot create arbitrary configuration rows.
 */

declare(strict_types=1);

final class SettingsController extends Controller
{
    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN]);
    }

    /** GET /settings */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $this->render('settings/index', [
            'pageTitle' => 'System settings',
            'settings'  => SettingsService::system(),
            'smtp'      => SmtpSettings::public(),
            'smtpEncryptions' => SmtpSettings::ENCRYPTIONS,
            'timezones' => DateTimeZone::listIdentifiers(),
            'currencies' => SettingsService::CURRENCIES,
            'dateFormats' => SettingsService::DATE_FORMATS,
            'timeFormats' => SettingsService::TIME_FORMATS,
            'appKeyOk'  => DesktopAgent::keyConfigured(),
        ]);
    }

    /** GET /settings/audit-logs : searchable, filterable audit trail. */
    public function auditLogs(Request $request, array $params): void
    {
        PermissionHelper::require('activity.view');

        $filters = [
            'q'       => trim((string) $request->input('q', '')),
            'module'  => (string) $request->input('module', 'all'),
            'action'  => trim((string) $request->input('action', '')),
            'user_id' => (int) $request->input('user_id', 0),
        ];

        $model = new ActivityLog();
        $result = $model->search($filters, (int) $request->input('page', 1), 25);

        $this->render('settings/audit_logs', [
            'pageTitle' => 'Activity log',
            'result'    => $result,
            'filters'   => $filters,
            'modules'   => $model->modules(),
        ]);
    }

    /** POST /settings */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'app_name'            => 'required|string|max:80',
            'company_email'       => 'required|email|max:190',
            'date_format'         => 'required|string|max:20',
            'time_format'         => 'required|in:' . implode(',', SettingsService::TIME_FORMATS),
            'currency_symbol'     => 'required|string|max:6',
            'currency'            => 'required|in:' . implode(',', SettingsService::CURRENCIES),
            'default_hourly_rate' => 'required|numeric|min:0|max:100000',
            'default_timezone'    => 'required|timezone',
            'timer_max_hours'     => 'required|numeric|min:1|max:24',
            'timer_reminder_minutes' => 'required|numeric|min:0|max:240',
        ], '/settings', [
            'app_name'            => 'Application name',
            'company_email'       => 'Company email',
            'date_format'         => 'Date format',
            'time_format'         => 'Time format',
            'currency_symbol'     => 'Currency symbol',
            'currency'            => 'Currency code',
            'default_hourly_rate' => 'Default hourly rate',
            'default_timezone'    => 'Timezone',
            'timer_max_hours'     => 'Timer maximum hours',
            'timer_reminder_minutes' => 'Still-working reminder',
        ]);

        if (!in_array((string) $data['date_format'], SettingsService::DATE_FORMATS, true)) {
            $this->backWithErrors('/settings', ['date_format' => 'Date format is invalid.']);
        }

        $before = SettingsService::system();
        $after  = [];

        Database::transaction(function () use ($data, $request, &$after): void {
            $writes = [
                'app_name' => trim((string) $data['app_name']),
                'company_email' => strtolower(trim((string) $data['company_email'])),
                'date_format' => (string) $data['date_format'],
                'time_format' => (string) $data['time_format'],
                'currency_symbol' => (string) $data['currency_symbol'],
                'currency' => (string) $data['currency'],
                'default_hourly_rate' => (string) $data['default_hourly_rate'],
                'default_timezone' => (string) $data['default_timezone'],
                'timer_max_hours' => (string) max(1, min(24, (int) $data['timer_max_hours'])),
                'timer_reminder_minutes' => (string) max(0, min(240, (int) $data['timer_reminder_minutes'])),
                'allow_manual_time_entries' => $request->input('allow_manual_time_entries') ? '1' : '0',
                'notifications_enabled' => $request->input('notifications_enabled') ? '1' : '0',
                'maintenance_mode' => $request->input('maintenance_mode') ? '1' : '0',
            ];
            foreach ($writes as $key => $value) {
                SettingsService::setSystem($key, $value);
                $after[$key] = $value;
            }
        });

        LoggerHelper::logEvent('settings.updated', LoggerHelper::MODULE_SETTINGS, null, $before, $after);

        $this->flash('success', 'System settings were saved.');
        $this->redirect('/settings');
    }

    /** POST /settings/smtp */
    public function updateSmtp(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'smtp_host' => 'nullable|string|max:190',
            'smtp_port' => 'required|int|min:1|max:65535',
            'smtp_username' => 'nullable|string|max:190',
            'smtp_password' => 'nullable|string|max:255',
            'smtp_encryption' => 'required|in:' . implode(',', SmtpSettings::ENCRYPTIONS),
            'smtp_from_name' => 'nullable|string|max:120',
            'smtp_from_email' => 'nullable|email|max:190',
            'smtp_reply_to' => 'nullable|email|max:190',
            'invite_expiry_days' => 'required|int|min:1|max:90',
        ], '/settings#smtp', [
            'smtp_host' => 'SMTP host',
            'smtp_port' => 'SMTP port',
            'smtp_username' => 'SMTP username',
            'smtp_password' => 'SMTP password',
            'smtp_encryption' => 'Encryption',
            'smtp_from_name' => 'From name',
            'smtp_from_email' => 'From email',
            'smtp_reply_to' => 'Reply-To',
            'invite_expiry_days' => 'Invitation expiry',
        ]);

        $password = (string) ($data['smtp_password'] ?? '');
        $replacePassword = $password !== '';

        try {
            SmtpSettings::save([
                'smtp_enabled' => $request->input('smtp_enabled') ? '1' : '0',
                'smtp_host' => trim((string) ($data['smtp_host'] ?? '')),
                'smtp_port' => (string) max(1, min(65535, (int) $data['smtp_port'])),
                'smtp_username' => trim((string) ($data['smtp_username'] ?? '')),
                'smtp_password' => $password,
                'smtp_encryption' => (string) $data['smtp_encryption'],
                'smtp_from_name' => trim((string) ($data['smtp_from_name'] ?? '')),
                'smtp_from_email' => strtolower(trim((string) ($data['smtp_from_email'] ?? ''))),
                'smtp_reply_to' => strtolower(trim((string) ($data['smtp_reply_to'] ?? ''))),
                'invite_expiry_days' => (string) max(1, min(90, (int) $data['invite_expiry_days'])),
            ], $replacePassword);
        } catch (RuntimeException $e) {
            $this->flash('danger', $e->getMessage());
            $this->redirect('/settings#smtp');
        }

        LoggerHelper::logEvent('settings.smtp_updated', LoggerHelper::MODULE_SETTINGS, null, null, [
            'host' => trim((string) ($data['smtp_host'] ?? '')),
            'port' => (int) $data['smtp_port'],
            'encryption' => (string) $data['smtp_encryption'],
            'enabled' => $request->input('smtp_enabled') ? '1' : '0',
            'password_changed' => $replacePassword ? '1' : '0',
        ]);

        $this->flash('success', 'Mail settings were saved.');
        $this->redirect('/settings#smtp');
    }

    /** POST /settings/smtp/test */
    public function testSmtp(Request $request, array $params): void
    {
        PermissionHelper::require('settings.manage');

        $data = $this->validate([
            'test_email' => 'required|email|max:190',
        ], '/settings#smtp', ['test_email' => 'Test email']);

        if (RateLimitHelper::tooMany('mail.test_sent', $request->ip(), 8, 15)) {
            $this->flash('danger', 'Too many test emails from this address. Wait a few minutes and try again.');
            $this->redirect('/settings#smtp');
        }

        $to = strtolower((string) $data['test_email']);
        $app = SettingsService::appName();
        $result = Mailer::send(
            $to,
            $app . ' test email',
            '<p>This is a test message from ' . htmlspecialchars($app, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '. SMTP is working.</p>',
            'This is a test message from ' . $app . '. SMTP is working.'
        );

        LoggerHelper::logEvent(
            $result['ok'] ? 'mail.test_sent' : 'mail.test_failed',
            LoggerHelper::MODULE_MAIL,
            null,
            null,
            ['ok' => $result['ok'] ? '1' : '0']
        );

        if ($result['ok']) {
            $this->flash('success', 'Test email sent.');
        } else {
            $this->flash('danger', $result['error'] !== '' ? $result['error'] : 'The test email could not be sent.');
        }
        $this->redirect('/settings#smtp');
    }
}
