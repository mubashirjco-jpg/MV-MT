<?php
/**
 * AJAX endpoints for the notification bell (Phase 9).
 *
 * Every method operates only on the signed-in user's own notifications; the
 * user_id guard lives in SQL, so an attacker cannot mark someone else's row read
 * even by guessing an id.
 */

declare(strict_types=1);

final class NotificationController extends Controller
{
    public function __construct()
    {
        parent::__construct(true); // any authenticated role
        PermissionHelper::require('notifications.view');
    }

    /** GET /notifications/unread : header dropdown payload. */
    public function getUnread(Request $request, array $params): void
    {
        $userId = (int) AuthHelper::id();

        if (!Notification::installed()) {
            $this->json(['ok' => true, 'unread' => 0, 'items' => []]);
        }

        $model = new Notification();

        $items = array_map(
            static fn (array $n): array => [
                'id'        => (int) $n['id'],
                'type'      => (string) $n['type'],
                'title'     => (string) $n['title'],
                'message'   => (string) ($n['message'] ?? ''),
                'link'      => (string) ($n['link'] ?? ''),
                'is_read'   => (bool) $n['is_read'],
                'created'   => FormatHelper::datetime((string) $n['created_at'], 'M j, H:i'),
            ],
            $model->recent($userId, 8)
        );

        // Read-only endpoint: release the session lock before the response.
        AuthHelper::releaseSession();

        $this->json([
            'ok'     => true,
            'unread' => $model->unreadCount($userId),
            'items'  => $items,
        ]);
    }

    /** POST /notifications/{id}/read */
    public function markAsRead(Request $request, array $params): void
    {
        $id     = (int) ($params['id'] ?? 0);
        $userId = (int) AuthHelper::id();
        $model  = new Notification();

        $ok = $id > 0 && $model->markRead($id, $userId);

        $this->json([
            'ok'     => true,
            'changed' => $ok,
            'unread' => $model->unreadCount($userId),
        ]);
    }

    /** POST /notifications/read-all */
    public function markAllAsRead(Request $request, array $params): void
    {
        $userId = (int) AuthHelper::id();
        $model  = new Notification();

        $changed = $model->markAllRead($userId);

        $this->json(['ok' => true, 'changed' => $changed, 'unread' => 0]);
    }
}
