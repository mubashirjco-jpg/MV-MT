<?php
/**
 * Data reset ("fresh start"): bulk-delete selected data groups after a SQL backup.
 *
 * Security layers, all enforced server-side:
 *  1. Admin role (constructor) AND the workspace.manage permission on every action.
 *  2. POST + CSRF for every state-changing or data-exporting action (router-enforced).
 *  3. The admin must re-enter their own password (a hijacked session is not enough).
 *  4. The admin must type the exact phrase RESET DATA.
 *  5. Wrong password/phrase attempts are counted per session; after MAX_FAILURES the
 *     reset is locked for LOCK_SECONDS.
 *  6. Only whitelisted groups run; dependencies are added automatically; the logged-in
 *     admin account is never deleted; the whole delete runs in one transaction.
 *  7. The action is written to the audit log.
 */

declare(strict_types=1);

final class DataResetController extends Controller
{
    private const SESSION_FAILS = '_data_reset_fails';
    private const SESSION_LOCK  = '_data_reset_locked_until';

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN]);
    }

    /** GET /workspace/data-reset */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('workspace.manage');

        $workspace = Workspace::current();
        if ($workspace === null) {
            throw new HttpException(500, 'Workspace has not been initialized.');
        }

        $userId = (int) AuthHelper::id();

        $this->render('workspace/data_reset', [
            'pageTitle'    => 'Reset data',
            'workspace'    => $workspace,
            'groups'       => DataResetHelper::overview($userId),
            'phrase'       => DataResetHelper::CONFIRM_PHRASE,
            'lockedFor'    => $this->lockedSeconds(),
            'selected'     => DataResetHelper::normalize($request->input('groups', [])),
        ]);
    }

    /** POST /workspace/data-reset/backup  -> downloads a .sql file, changes nothing. */
    public function backup(Request $request, array $params): void
    {
        PermissionHelper::require('workspace.manage');

        $groups = DataResetHelper::normalize($request->input('groups', []));
        if ($groups === []) {
            $this->flash('warning', 'Choose at least one data group to back up.');
            $this->redirect('/workspace/data-reset');
        }

        LoggerHelper::logEvent('data.backup', 'workspace', null, null, null, ['groups' => $groups]);

        DataResetHelper::streamBackup($groups);
    }

    /** POST /workspace/data-reset */
    public function reset(Request $request, array $params): void
    {
        PermissionHelper::require('workspace.manage');

        $back = '/workspace/data-reset';

        $wait = $this->lockedSeconds();
        if ($wait > 0) {
            $this->flash('danger', 'Too many failed attempts. Try again in ' . (int) ceil($wait / 60) . ' minute(s).');
            $this->redirect($back);
        }

        $groups = DataResetHelper::normalize($request->input('groups', []));
        if ($groups === []) {
            $this->flash('warning', 'Choose at least one data group to remove.');
            $this->redirect($back);
        }

        $userId = (int) AuthHelper::id();

        // Layer 4: exact phrase (case-sensitive, trimmed).
        $phrase = trim((string) $request->input('confirm_phrase', ''));
        if (!hash_equals(DataResetHelper::CONFIRM_PHRASE, $phrase)) {
            $this->recordFailure($userId, 'phrase');
            $this->flash('danger', 'Confirmation phrase did not match. Type ' . DataResetHelper::CONFIRM_PHRASE . ' exactly.');
            $this->redirect($back);
        }

        // Layer 3: current password of the logged-in admin.
        $hash = (string) Database::fetchValue('SELECT password FROM users WHERE id = :id', ['id' => $userId]);
        $password = (string) $request->input('password', '');
        if ($hash === '' || $password === '' || !password_verify($password, $hash)) {
            $this->recordFailure($userId, 'password');
            $this->flash('danger', 'Your password was incorrect. Nothing was deleted.');
            $this->redirect($back);
        }

        // Deliberate acknowledgement that a backup was considered.
        if ((string) $request->input('understand', '') !== '1') {
            $this->flash('warning', 'Tick the box to confirm you understand this cannot be undone.');
            $this->redirect($back);
        }

        $before = [];
        foreach (DataResetHelper::overview($userId) as $key => $info) {
            if (in_array($key, $groups, true)) {
                $before[$key] = $info['rows'];
            }
        }

        try {
            $deleted = DataResetHelper::reset($groups, $userId);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $this->flash('danger', 'The reset failed and was rolled back. Nothing was deleted. See the application log for details.');
            $this->redirect($back);
        }

        unset($_SESSION[self::SESSION_FAILS], $_SESSION[self::SESSION_LOCK]);

        // Written AFTER the delete so it survives even when the audit log was cleared.
        LoggerHelper::logEvent(
            'data.reset',
            'workspace',
            null,
            ['rows_before' => $before],
            ['rows_deleted' => $deleted],
            ['groups' => $groups]
        );

        $this->flash('success', 'Reset complete. Removed ' . number_format(array_sum($deleted)) . ' row(s) from: ' . implode(', ', $groups) . '.');
        $this->redirect($back);
    }

    /* ------------------------------------------------------------------ throttling */

    /** Seconds left on the cool-down, 0 when not locked. */
    private function lockedSeconds(): int
    {
        $until = (int) ($_SESSION[self::SESSION_LOCK] ?? 0);

        return max(0, $until - time());
    }

    private function recordFailure(int $userId, string $reason): void
    {
        $fails = (int) ($_SESSION[self::SESSION_FAILS] ?? 0) + 1;
        $_SESSION[self::SESSION_FAILS] = $fails;

        LoggerHelper::logEvent('data.reset_denied', 'workspace', null, null, null, ['reason' => $reason, 'attempt' => $fails]);

        if ($fails >= DataResetHelper::MAX_FAILURES) {
            $_SESSION[self::SESSION_LOCK]  = time() + DataResetHelper::LOCK_SECONDS;
            $_SESSION[self::SESSION_FAILS] = 0;
        }
    }
}
