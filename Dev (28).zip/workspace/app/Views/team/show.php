<?php
/**
 * One team member (Phase 14).
 *
 * @var array<string, mixed>        $person
 * @var list<array<string, mixed>>  $projects
 * @var array<int, array<string, int>> $perProject   project_id => tracked, planned, open_tasks
 * @var array<string, mixed>        $week            load figures for the selected week
 * @var list<array<string, mixed>>  $trend           six weeks of planned / tracked seconds
 * @var list<array<string, mixed>>  $tasks           next open tasks
 * @var int                         $overdue
 * @var string                      $today
 * @var DateTimeImmutable           $weekStart
 * @var DateTimeImmutable           $weekEnd
 * @var string                      $prevWeek
 * @var string                      $nextWeek
 * @var bool                        $isThisWeek
 * @var float                       $capacityHours
 * @var bool                        $planning
 * @var bool                        $canLoad
 * @var bool                        $isSelf
 */

$hours    = static fn (int $seconds): string => number_format($seconds / 3600, 1);
$capLabel = rtrim(rtrim(number_format($capacityHours, 1), '0'), '.');
$initial  = mb_strtoupper(mb_substr((string) $person['name'], 0, 1, 'UTF-8'), 'UTF-8');
$base     = url('/team/' . (int) $person['id']);

$weekEndShown = $weekEnd->modify('-1 day');
$weekLabel    = $weekStart->format('M j') . ' – ' . $weekEndShown->format('M j, Y');

$trendMax = 1;
foreach ($trend as $point) {
    $trendMax = max($trendMax, (int) $point['planned'], (int) $point['tracked']);
}
$trendMax = max($trendMax, (int) round($capacityHours * 3600));

require __DIR__ . '/_styles.php';
?>
<div class="page-toolbar">
    <div>
        <a class="small" href="<?= e(url('/team?week=' . $weekStart->format('Y-m-d'))) ?>"><i class="fa-solid fa-arrow-left me-1" aria-hidden="true"></i>Team</a>
        <h2 class="page-heading mt-1"><?= e($person['name']) ?><?= $isSelf ? ' (you)' : '' ?></h2>
    </div>
    <?php if ($canLoad): ?>
        <div class="tm-week" role="group" aria-label="Choose week">
            <a class="btn btn-outline-secondary" href="<?= e($base . '?week=' . $prevWeek) ?>" aria-label="Previous week"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></a>
            <span class="tm-week-label"><?= e($weekLabel) ?></span>
            <a class="btn btn-outline-secondary" href="<?= e($base . '?week=' . $nextWeek) ?>" aria-label="Next week"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a>
            <?php if (!$isThisWeek): ?>
                <a class="btn btn-outline-secondary" href="<?= e($base) ?>">This week</a>
            <?php endif; ?>
        </div>
    <?php endif; ?>
</div>

<section class="panel mb-4">
    <div class="tm-head">
        <span class="avatar" aria-hidden="true"><?= e($initial) ?></span>
        <div class="me-auto">
            <div class="d-flex align-items-center gap-2 flex-wrap">
                <span class="role-pill role-<?= e(strtolower((string) $person['role'])) ?>"><?= e($person['role_name']) ?></span>
                <?php if ($person['status'] !== 'active'): ?>
                    <span class="status-badge status-inactive"><?= e(ucfirst((string) $person['status'])) ?></span>
                <?php endif; ?>
            </div>
            <?php if (!empty($person['job_title'])): ?><div class="mt-1"><?= e($person['job_title']) ?></div><?php endif; ?>
            <a class="tm-sub" href="mailto:<?= e($person['email']) ?>"><?= e($person['email']) ?></a>
        </div>
        <div class="tm-sub text-md-end">
            <?= count($projects) ?> open project<?= count($projects) === 1 ? '' : 's' ?><br>
            Time zone: <?= e($person['timezone'] ?: 'UTC') ?>
        </div>
    </div>
</section>

<?php if ($canLoad): ?>
    <div class="kpi-grid mb-4">
        <article class="kpi-card">
            <p class="kpi-label"><?= $planning ? 'Planned' : 'Tracked' ?> this week</p>
            <p class="kpi-value"><?= e($hours((int) $week['load_seconds'])) ?>h</p>
            <p class="kpi-sub"><?= (int) $week['load_percent'] ?>% of <?= e($capLabel) ?>h · <?= e($week['load_label']) ?></p>
        </article>
        <?php if ($planning): ?>
            <article class="kpi-card">
                <p class="kpi-label">Tracked so far</p>
                <p class="kpi-value"><?= e($hours((int) $week['tracked_seconds'])) ?>h</p>
                <p class="kpi-sub"><?= (int) $week['blocks'] ?> planned block<?= (int) $week['blocks'] === 1 ? '' : 's' ?></p>
            </article>
        <?php endif; ?>
        <article class="kpi-card">
            <p class="kpi-label">Open tasks</p>
            <p class="kpi-value"><?= count($tasks) >= 10 ? '10+' : count($tasks) ?></p>
            <p class="kpi-sub"><?= (int) $overdue ?> overdue</p>
        </article>
    </div>
<?php endif; ?>

<section class="panel mb-4">
    <div class="panel-head"><h2 class="panel-title">Projects <span class="count-pill"><?= count($projects) ?></span></h2></div>
    <?php if ($projects === []): ?>
        <div class="empty-state"><i class="fa-solid fa-diagram-project" aria-hidden="true"></i><p>Not on any open project you can see.</p></div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table table-stack mb-0">
                <thead>
                    <tr>
                        <th>Project</th><th>Project role</th><th>Status</th>
                        <?php if ($canLoad): ?>
                            <?php if ($planning): ?><th>Planned (week)</th><?php endif; ?>
                            <th>Tracked (week)</th><th>Open tasks</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($projects as $project): ?>
                        <?php $figures = $perProject[(int) $project['project_id']] ?? ['tracked' => 0, 'planned' => 0, 'open_tasks' => 0]; ?>
                        <tr>
                            <td data-label="Project">
                                <a href="<?= e(url('/projects/' . (int) $project['project_id'])) ?>"><strong><?= e($project['name']) ?></strong></a>
                                <?php if (!empty($project['project_code'])): ?><span class="tm-sub"><?= e($project['project_code']) ?></span><?php endif; ?>
                            </td>
                            <td data-label="Project role"><?= e(ucfirst((string) $project['project_role'])) ?></td>
                            <td data-label="Status"><?= e($project['status']) ?></td>
                            <?php if ($canLoad): ?>
                                <?php if ($planning): ?><td data-label="Planned"><?= $figures['planned'] > 0 ? e($hours($figures['planned'])) . 'h' : '<span class="tm-muted">–</span>' ?></td><?php endif; ?>
                                <td data-label="Tracked"><?= $figures['tracked'] > 0 ? e($hours($figures['tracked'])) . 'h' : '<span class="tm-muted">–</span>' ?></td>
                                <td data-label="Open tasks"><?= $figures['open_tasks'] > 0 ? (int) $figures['open_tasks'] : '<span class="tm-muted">–</span>' ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php if ($canLoad): ?>
    <section class="panel mb-4">
        <div class="panel-head"><h2 class="panel-title">Six-week workload</h2></div>
        <div class="tm-trend" role="img" aria-label="Planned and tracked hours for six weeks around the selected week">
            <?php foreach ($trend as $point): ?>
                <?php
                $pp = (int) round(((int) $point['planned'] / $trendMax) * 100);
                $tp = (int) round(((int) $point['tracked'] / $trendMax) * 100);
                ?>
                <div class="tm-trend-col<?= $point['current'] ? ' is-current' : '' ?>">
                    <div class="tm-trend-bars">
                        <?php if ($planning): ?>
                            <div class="tm-trend-bar" style="height:<?= max(1, $pp) ?>%" title="Planned <?= e($hours((int) $point['planned'])) ?>h"></div>
                        <?php endif; ?>
                        <div class="tm-trend-bar is-tracked" style="height:<?= max(1, $tp) ?>%" title="Tracked <?= e($hours((int) $point['tracked'])) ?>h"></div>
                    </div>
                    <span class="tm-trend-label"><?= e($point['start']->format('M j')) ?></span>
                </div>
            <?php endforeach; ?>
        </div>
        <div class="tm-legend">
            <?php if ($planning): ?><span><i></i>Planned</span><?php endif; ?>
            <span><i class="is-tracked"></i>Tracked</span>
            <span>Tallest bar = <?= e($hours($trendMax)) ?>h (weekly capacity <?= e($capLabel) ?>h)</span>
        </div>
    </section>

    <section class="panel">
        <div class="panel-head"><h2 class="panel-title">Next open tasks</h2></div>
        <?php if ($tasks === []): ?>
            <div class="empty-state"><i class="fa-regular fa-circle-check" aria-hidden="true"></i><p>No open tasks assigned.</p></div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table data-table table-stack mb-0">
                    <thead><tr><th>Task</th><th>Project</th><th>Status</th><th>Priority</th><th>Due</th></tr></thead>
                    <tbody>
                        <?php foreach ($tasks as $task): ?>
                            <?php $late = !empty($task['due_date']) && (string) $task['due_date'] < $today; ?>
                            <tr>
                                <td data-label="Task"><?= e($task['task_name']) ?></td>
                                <td data-label="Project"><a href="<?= e(url('/projects/' . (int) $task['project_id'])) ?>"><?= e($task['project_code'] ?: $task['project_name']) ?></a></td>
                                <td data-label="Status"><?= e($task['status']) ?></td>
                                <td data-label="Priority"><?= e($task['priority']) ?></td>
                                <td data-label="Due" class="<?= $late ? 'text-danger fw-semibold' : '' ?>">
                                    <?= !empty($task['due_date']) ? e(FormatHelper::date((string) $task['due_date'], 'M j, Y')) . ($late ? ' (overdue)' : '') : '<span class="tm-muted">No date</span>' ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>
<?php else: ?>
    <p class="tm-muted small">Hours and tasks are only visible for your own profile and to managers and admins.</p>
<?php endif; ?>
