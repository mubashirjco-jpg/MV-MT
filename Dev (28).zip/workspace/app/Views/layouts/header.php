<?php
/**
 * Document head and opening of <body>. Shared by the "app" and "auth" layouts.
 *
 * Reads from the page data:  $pageTitle (string, optional)
 * Assets are self-hosted under public/assets. The CSP in config/config.php forbids CDNs
 * and inline scripts. Behaviour lives in assets/js/*.js.
 *
 * @var string|null $pageTitle
 */

$appName   = SettingsService::appName();
$workspaceBrand = class_exists('Workspace') ? Workspace::current() : null;
$displayName = $workspaceBrand ? (string) $workspaceBrand['name'] : $appName;
$fullTitle = isset($pageTitle) && $pageTitle !== '' ? $pageTitle . ' | ' . $appName : $appName;
$isShell   = AuthHelper::check(); // signed-in screens get the sidebar shell, guests get a bare page
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="color-scheme" content="light">
    <?= csrf_meta() ?>
    <title><?= e($fullTitle) ?></title>

    <link rel="stylesheet" href="<?= e(asset('vendor/bootstrap/bootstrap.min.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('vendor/fontawesome/css/all.min.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/fonts.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/app.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/style.css')) ?>">
    <link rel="stylesheet" href="<?= e(asset('css/dark.css')) ?>">
<?php if (!empty($reportAssets)): ?>
    <link rel="stylesheet" href="<?= e(asset('css/reports.css')) ?>">
<?php endif; ?>
    <script src="<?= e(asset('js/theme-init.js')) ?>"></script>
</head>
<body class="<?= $isShell ? 'app-body' : 'auth-body' ?>" data-base-url="<?= e(url('/')) ?>">
<a class="skip-link" href="#main-content">Skip to content</a>
<?php if ($isShell): ?>
<div class="app-shell">
<?php endif; ?>
