<?php
/**
 * Team report > Attendance (Clockify layout).
 *
 * @var list<array<string,mixed>> $lines
 * @var array<string,int> $totals
 */
require APP_PATH . '/Views/reports/_header.php';
$pageUrl = static fn(int $p): string => $tabUrl('attendance') . (str_contains($tabUrl('attendance'), '?') ? '&' : '?') . 'page=' . $p;
$cell = static fn(int $s): string => $s !== 0 ? e($hms($s)) : '<span class="rk-dash">-</span>';
?>
<div class="rk-panel">
    <div class="rk-kpis">
        <div class="rk-kpi"><small>Capacity</small><strong><?= e($hms($totals['capacity'])) ?></strong></div>
        <div class="rk-kpi"><small>Work</small><strong class="is-red"><?= e($hms($totals['work'])) ?></strong></div>
        <div class="rk-kpi"><small>Overtime</small><strong><?= e($hms($totals['overtime'])) ?></strong></div>
        <div class="rk-kpi"><small>Undertime</small><strong><?= e($hms($totals['undertime'])) ?></strong></div>
        <div class="rk-kpi"><small>Balance</small><strong><?= e($hms($totals['balance'])) ?></strong></div>
        <div class="rk-kpi"><small>Break</small><strong><?= e($hms($totals['break'])) ?></strong></div>
        <div class="rk-kpi"><small>Time off</small><strong>00:00:00</strong></div>
    </div>
</div>
<div class="rk-groupby"><span class="rk-gl">Group by:</span><span class="rk-static">(None)</span></div>
<?php if ($clipped): ?><div class="rk-note">Attendance shows the latest 62 days of the range.</div><?php endif; ?>
<div class="rk-box" style="border-top:0">
    <div class="rk-scroll">
    <table class="rk-table">
        <thead><tr>
            <th class="rk-l">Title <i class="fa-solid fa-sort"></i></th><th class="rk-l">Date <i class="fa-solid fa-sort"></i></th><th class="rk-l">Start <i class="fa-solid fa-sort"></i></th><th class="rk-l">End <i class="fa-solid fa-sort"></i></th>
            <th class="rk-c">Capacity <i class="fa-solid fa-sort"></i></th><th class="rk-c">Work <i class="fa-solid fa-sort"></i></th><th class="rk-c">Overtime <i class="fa-solid fa-sort"></i></th><th class="rk-c">Undertime <i class="fa-solid fa-sort"></i></th><th class="rk-c">Balance <i class="fa-solid fa-sort"></i></th><th class="rk-c">Break <i class="fa-solid fa-sort"></i></th>
        </tr></thead>
        <tbody>
        <?php if ($lines === []): ?><tr><td colspan="10" class="rk-empty">No people to show for this range.</td></tr><?php endif; ?>
        <?php foreach ($lines as $l): ?>
            <tr>
                <td><?= e($l['name']) ?></td>
                <td style="white-space:nowrap"><?= e((new DateTimeImmutable($l['date']))->format('d/m/Y')) ?></td>
                <td><?= $l['start'] !== '' ? e($l['start']) : '<span class="rk-dash">-</span>' ?></td>
                <td><?= $l['end'] !== '' ? e($l['end']) : '<span class="rk-dash">-</span>' ?></td>
                <td class="rk-c"><?= $l['capacity'] !== 0 ? e($hms((int) $l['capacity'])) : '<span class="rk-dash">00:00:00</span>' ?></td>
                <td class="rk-c"><?= $l['work'] > 0 ? '<span class="is-red">' . e($hms((int) $l['work'])) . '</span>' : '<span class="is-red">-</span>' ?></td>
                <td class="rk-c"><?= $cell((int) $l['overtime']) ?></td>
                <td class="rk-c"><?= $cell((int) $l['undertime']) ?></td>
                <td class="rk-c"><?= $cell((int) $l['balance']) ?></td>
                <td class="rk-c"><?= $cell((int) $l['break']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    </div>
    <div class="rk-pager"><span><?= (int) $count ?> rows · page <?= (int) $page ?> of <?= (int) $pages ?></span>
        <?php if ($page > 1): ?><a href="<?= e($pageUrl($page - 1)) ?>">Previous</a><?php endif; ?>
        <?php if ($page < $pages): ?><a href="<?= e($pageUrl($page + 1)) ?>">Next</a><?php endif; ?>
    </div>
</div>
</div>
