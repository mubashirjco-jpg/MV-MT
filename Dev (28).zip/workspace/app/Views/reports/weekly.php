<?php
/**
 * Time report > Weekly.
 *
 * @var list<string> $days
 * @var list<array<string,mixed>> $matrix
 */
require APP_PATH . '/Views/reports/_header.php';
$groupBy = ['user' => 'Team', 'project' => 'Project', 'client' => 'Client'];
if (!$canViewAll) { unset($groupBy['user']); }
$short = static fn(int $s): string => $s > 0 ? sprintf('%02d:%02d:%02d', intdiv($s, 3600), intdiv($s % 3600, 60), $s % 60) : '-';
?>
<div class="rk-panel"><div class="rk-total-label">Total:</div><div class="rk-total"><?= e($hms($grand)) ?></div><div class="rk-panel-row"></div></div>
<form method="get" action="<?= e(url('/reports/weekly')) ?>" class="rk-groupby">
    <?php foreach (['from', 'to'] as $k): ?><input type="hidden" name="<?= $k ?>" value="<?= e($filters[$k]) ?>"><?php endforeach; ?>
    <?php foreach (['user_id', 'client_id', 'project_id', 'task_id'] as $k): if ((int) $filters[$k] > 0): ?><input type="hidden" name="<?= $k ?>" value="<?= (int) $filters[$k] ?>"><?php endif; endforeach; ?>
    <?php if ($filters['billable'] !== ''): ?><input type="hidden" name="billable" value="<?= e($filters['billable']) ?>"><?php endif; ?>
    <span class="rk-gl">Group by:</span>
    <select name="group" aria-label="Group by" data-autosubmit><?php foreach ($groupBy as $k => $t): ?><option value="<?= $k ?>"<?= $by === $k ? ' selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?></select>
</form>
<?php if ($clipped): ?><div class="rk-note">Only the first 31 days of this range are shown. Pick a shorter range to see the rest.</div><?php endif; ?>
<div class="rk-box" style="border-top:0">
    <div class="rk-scroll">
    <table class="rk-table">
        <thead><tr><th class="rk-l"><?= e($groupBy[$by]) ?> <i class="fa-solid fa-sort"></i></th><?php foreach ($days as $d): $dt = new DateTimeImmutable($d); ?><th class="rk-r"><?= e($dt->format('D, M j')) ?></th><?php endforeach; ?><th class="rk-r">Total</th></tr></thead>
        <tbody>
        <?php if ($matrix === []): ?><tr><td colspan="<?= count($days) + 2 ?>" class="rk-empty">No time entries match these filters.</td></tr><?php endif; ?>
        <?php foreach ($matrix as $row): ?>
            <tr><td><?= e($row['label']) ?></td><?php foreach ($days as $d): ?><td class="rk-r"><?= e($short((int) $row['days'][$d])) ?></td><?php endforeach; ?><td class="rk-r"><strong><?= e($hms((int) $row['total'])) ?></strong></td></tr>
        <?php endforeach; ?>
        <?php if ($matrix !== []): ?>
            <tr><td><strong>Total</strong></td><?php foreach ($days as $d): ?><td class="rk-r"><strong><?= e($short((int) $dayTotals[$d])) ?></strong></td><?php endforeach; ?><td class="rk-r"><strong><?= e($hms($grand)) ?></strong></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    </div>
</div>
</div>
