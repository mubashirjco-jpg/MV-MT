<?php
/**
 * Choose a new password from a reset link.
 *
 * @var string $token
 * @var bool $valid
 */

$appName = (string) Config::get('app.name', 'TimeTrack');
$flashes = flash_pull();
$passwordError = field_error('password');
?>
<div class="login-page">
    <section class="login-aside" aria-hidden="true">
        <div class="login-aside-inner">
            <div class="brand-link">
                <span class="brand-mark"><i class="fa-solid fa-stopwatch"></i></span>
                <span class="brand-name"><?= e($appName) ?></span>
            </div>
            <p class="login-claim">Choose a new password.</p>
        </div>
    </section>
    <main class="login-main" id="main-content">
        <div class="login-card">
            <h1 class="login-title">Reset password</h1>

            <?php foreach ($flashes as $type => $messages): ?>
                <?php foreach ((array) $messages as $message): ?>
                    <div class="alert alert-<?= e($type) ?>" role="<?= $type === 'danger' ? 'alert' : 'status' ?>"><?= e($message) ?></div>
                <?php endforeach; ?>
            <?php endforeach; ?>

            <?php if (!$valid): ?>
                <div class="alert alert-danger" role="alert">This reset link is not valid or has expired.</div>
                <p class="login-foot"><a href="<?= e(url('/forgot-password')) ?>">Request a new link</a></p>
            <?php else: ?>
                <form method="post" action="<?= e(url('/reset-password')) ?>" novalidate data-single-submit>
                    <?= csrf_field() ?>
                    <input type="hidden" name="token" value="<?= e($token) ?>">
                    <div class="mb-3">
                        <label for="password" class="form-label">New password</label>
                        <input type="password" id="password" name="password" required autocomplete="new-password"
                               class="form-control form-control-lg<?= $passwordError !== null ? ' is-invalid' : '' ?>"
                               data-password-meter="#password-meter">
                        <?php if ($passwordError !== null): ?><div class="invalid-feedback"><?= e($passwordError) ?></div><?php endif; ?>
                        <div class="strength" id="password-meter" aria-live="polite"><span class="strength-bar"></span><span class="strength-text"></span></div>
                        <div class="form-text">10 to 72 characters with upper-case, lower-case and a number.</div>
                    </div>
                    <div class="mb-4">
                        <label for="password_confirmation" class="form-label">Confirm password</label>
                        <input type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password" class="form-control form-control-lg">
                    </div>
                    <button type="submit" class="btn btn-primary btn-lg w-100">Save password</button>
                </form>
            <?php endif; ?>
        </div>
    </main>
</div>
