<?php
/**
 * Blocks every authenticated route except password change, logout and static
 * assets while users.must_change_password is set.
 *
 * Integrity: a newly provisioned admin cannot use the app until they replace
 * the go-live password, so a leaked bootstrap credential cannot linger.
 */

declare(strict_types=1);

final class PasswordChangeMiddleware
{
    private const ALLOWED_PATHS = [
        '/profile',
        '/profile/password',
        '/logout',
        '/health',
    ];

    public function handle(Request $request): void
    {
        $userId = AuthHelper::id();
        if ($userId === null) {
            return;
        }

        if (!SchemaHelper::columnExists('users', 'must_change_password')) {
            return;
        }

        $flag = (int) Database::fetchValue(
            'SELECT must_change_password FROM users WHERE id = :id',
            ['id' => $userId]
        );
        if ($flag !== 1) {
            return;
        }

        $path = $request->path();
        if (in_array($path, self::ALLOWED_PATHS, true)) {
            return;
        }

        if ($request->wantsJson() || $request->isAjax()) {
            throw new HttpException(403, 'You must change your password before continuing.');
        }

        $_SESSION['_flash']['warning'][] = 'You must change your password before continuing.';
        throw new HttpException(302, '', ['Location' => Request::basePath() . '/profile']);
    }
}
