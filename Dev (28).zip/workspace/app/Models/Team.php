<?php
/**
 * Team read-model (Phase 14). Read-only: it never writes to the database.
 *
 * Answers four questions for the Team page:
 *   1. Who is on the team that the viewer is allowed to see?
 *   2. Which open projects is each person on, and in what project role?
 *   3. How much work is planned and tracked for each person in a given week?
 *   4. How many open (and overdue) tasks does each person hold?
 *
 * Visibility rules (same spirit as Schedule::teamWorkload, so numbers agree between pages):
 *   - Roles with projects.view_all (admin) see everybody.
 *   - Everyone else sees themselves plus people who share at least one project with them
 *     (as manager, creator or member).
 *   - Hours and task counts for OTHER people only include projects the viewer manages or
 *     created (or all projects for projects.view_all), so a private project never leaks
 *     workload. A person's own hours and tasks always include all of their projects.
 *
 * Every value is a bound parameter; the only SQL assembled by string is generated
 * placeholders and hard-coded fragments.
 */

declare(strict_types=1);

final class Team
{
    /** Working days used to turn the workspace daily capacity into a weekly capacity. */
    public const WORK_DAYS = 5;

    /** Project statuses that count as "on a project" for the Team page. */
    public const OPEN_PROJECT_STATUSES = ['Planning', 'Active', 'On Hold'];

    /** Task statuses that no longer count as open work. */
    private const CLOSED_TASK_STATUSES = ['Completed', 'Done', 'Cancelled'];

    private const PROJECT_ROLE_RANK = ['manager' => 0, 'member' => 1, 'viewer' => 2];

    /* ------------------------------------------------------------------ people */

    /**
     * @param array{q?: string, role?: string, status?: string, project?: int, id?: int} $filters
     * @return list<array<string, mixed>>
     */
    public function people(array $filters, int $viewerId, bool $viewAll): array
    {
        $params = [];
        $where  = ["r.name IN ('admin','manager','employee')"];

        $status = (string) ($filters['status'] ?? 'active');
        if (in_array($status, ['active', 'inactive', 'suspended'], true)) {
            $where[]          = 'u.status = :f_status';
            $params['f_status'] = $status;
        }

        $role = (string) ($filters['role'] ?? '');
        if (in_array($role, ['admin', 'manager', 'employee'], true)) {
            $where[]        = 'r.name = :f_role';
            $params['f_role'] = $role;
        }

        $q = trim((string) ($filters['q'] ?? ''));
        if ($q !== '') {
            $like = '%' . addcslashes($q, '%_\\') . '%';
            $where[]         = '(u.name LIKE :f_q1 OR u.email LIKE :f_q2 OR u.job_title LIKE :f_q3)';
            $params['f_q1']  = $like;
            $params['f_q2']  = $like;
            $params['f_q3']  = $like;
        }

        $projectId = (int) ($filters['project'] ?? 0);
        if ($projectId > 0) {
            $where[] = '(EXISTS (SELECT 1 FROM project_members fpm
                                 WHERE fpm.project_id = :f_p1 AND fpm.user_id = u.id)
                         OR EXISTS (SELECT 1 FROM projects fp
                                    WHERE fp.id = :f_p2 AND fp.manager_id = u.id))';
            $params['f_p1'] = $projectId;
            $params['f_p2'] = $projectId;
        }

        $onlyId = (int) ($filters['id'] ?? 0);
        if ($onlyId > 0) {
            $where[]         = 'u.id = :f_id';
            $params['f_id']  = $onlyId;
        }

        if (!$viewAll) {
            // Yourself, or someone who shares a project you manage, created or belong to.
            $where[] = '(u.id = :s_me
                OR EXISTS (
                    SELECT 1 FROM projects sp
                    WHERE (sp.manager_id = :s_v1
                           OR sp.created_by = :s_v2
                           OR EXISTS (SELECT 1 FROM project_members spm
                                      WHERE spm.project_id = sp.id AND spm.user_id = :s_v3))
                      AND (sp.manager_id = u.id
                           OR sp.created_by = u.id
                           OR EXISTS (SELECT 1 FROM project_members spm2
                                      WHERE spm2.project_id = sp.id AND spm2.user_id = u.id))
                ))';
            $params['s_me'] = $viewerId;
            $params['s_v1'] = $viewerId;
            $params['s_v2'] = $viewerId;
            $params['s_v3'] = $viewerId;
        }

        return Database::fetchAll(
            'SELECT u.id, u.name, u.email, r.name AS role, u.job_title, u.status, u.timezone,
                    COALESCE(r.display_name, r.name) AS role_name
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE ' . implode(' AND ', $where) . '
             ORDER BY u.name ASC
             LIMIT 300',
            $params
        );
    }

    /** @return array<string, mixed>|null */
    public function person(int $id, int $viewerId, bool $viewAll): ?array
    {
        $rows = $this->people(['id' => $id, 'status' => 'all'], $viewerId, $viewAll);

        return $rows[0] ?? null;
    }

    /* ---------------------------------------------------------------- projects */

    /**
     * Open projects the viewer may see, for the filter drop-down.
     *
     * @return list<array<string, mixed>>
     */
    public function projectOptions(int $viewerId, bool $viewAll): array
    {
        $params = [];
        $vis    = self::visibleProject('p', 'po', $viewAll, $viewerId, true, $params);
        $in     = self::in('po_st', self::OPEN_PROJECT_STATUSES, $params, false);

        return Database::fetchAll(
            "SELECT p.id, p.name, p.project_code
             FROM projects p
             WHERE p.status IN ({$in}) AND {$vis}
             ORDER BY p.name ASC
             LIMIT 300",
            $params
        );
    }

    /**
     * Open projects per person, with the person's role on each.
     *
     * @param list<int> $userIds
     * @return array<int, list<array<string, mixed>>> user_id => projects
     */
    public function projectsByUser(array $userIds, int $viewerId, bool $viewAll): array
    {
        if ($userIds === []) {
            return [];
        }

        $params = [];
        $inA    = self::in('pa', $userIds, $params);
        $inB    = self::in('pb', $userIds, $params);
        $inS    = self::in('pst', self::OPEN_PROJECT_STATUSES, $params, false);
        $vis    = self::visibleProject('p', 'pv', $viewAll, $viewerId, true, $params);
        $color  = Project::extrasReady() ? 'p.color' : 'NULL';

        $rows = Database::fetchAll(
            "SELECT x.user_id, p.id AS project_id, p.name, p.project_code, p.status,
                    {$color} AS color, x.project_role
             FROM (
                 SELECT pm.user_id, pm.project_id, pm.project_role
                 FROM project_members pm
                 WHERE pm.user_id IN ({$inA})
                 UNION ALL
                 SELECT mp.manager_id, mp.id, 'manager'
                 FROM projects mp
                 WHERE mp.manager_id IN ({$inB})
             ) x
             INNER JOIN projects p ON p.id = x.project_id
             WHERE p.status IN ({$inS}) AND {$vis}
             ORDER BY p.name ASC",
            $params
        );

        $byUser = [];
        foreach ($rows as $row) {
            $uid  = (int) $row['user_id'];
            $pid  = (int) $row['project_id'];
            $role = strtolower((string) $row['project_role']);
            $role = isset(self::PROJECT_ROLE_RANK[$role]) ? $role : 'member';

            // A person can be both project manager and member: keep the stronger role.
            if (isset($byUser[$uid][$pid])
                && self::PROJECT_ROLE_RANK[$byUser[$uid][$pid]['project_role']] <= self::PROJECT_ROLE_RANK[$role]) {
                continue;
            }

            $row['project_role']  = $role;
            $byUser[$uid][$pid]   = $row;
        }

        return array_map(static fn (array $projects): array => array_values($projects), $byUser);
    }

    /**
     * Hours and open tasks of ONE person split by project (member detail page).
     *
     * @return array<int, array{tracked: int, planned: int, open_tasks: int}> project_id => figures
     */
    public function perProject(int $userId, string $startUtc, string $endUtc, int $viewerId, bool $viewAll, bool $withPlanned): array
    {
        $out = [];

        try {
            $cols = self::entryColumns();
            if ($cols !== null) {
                [$startCol, $durCol] = $cols;
                $params = ['u' => $userId, 'ws' => $startUtc, 'we' => $endUtc];
                $vis    = self::visibleProject('p', 'tv', $viewAll, $viewerId, false, $params, 'te.user_id');
                foreach (Database::fetchAll(
                    "SELECT te.project_id, SUM(te.{$durCol}) AS secs
                     FROM time_entries te
                     INNER JOIN projects p ON p.id = te.project_id
                     WHERE te.user_id = :u AND te.{$startCol} >= :ws AND te.{$startCol} < :we AND {$vis}
                     GROUP BY te.project_id",
                    $params
                ) as $row) {
                    $out[(int) $row['project_id']]['tracked'] = (int) $row['secs'];
                }
            }
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        if ($withPlanned) {
            try {
                $params = ['u' => $userId, 'ws_a' => $startUtc, 'we_a' => $endUtc, 'ws_b' => $startUtc, 'we_b' => $endUtc];
                $vis    = self::visibleProject('p', 'sv', $viewAll, $viewerId, false, $params, 's.user_id');
                foreach (Database::fetchAll(
                    "SELECT s.project_id,
                            SUM(TIMESTAMPDIFF(SECOND, GREATEST(s.start_datetime, :ws_a), LEAST(s.end_datetime, :we_a))) AS secs
                     FROM schedules s
                     INNER JOIN projects p ON p.id = s.project_id
                     WHERE s.user_id = :u AND s.status NOT IN ('Cancelled')
                       AND s.start_datetime < :we_b AND s.end_datetime > :ws_b AND {$vis}
                     GROUP BY s.project_id",
                    $params
                ) as $row) {
                    $out[(int) $row['project_id']]['planned'] = max(0, (int) $row['secs']);
                }
            } catch (Throwable $e) {
                LoggerHelper::exception($e);
            }
        }

        try {
            foreach ($this->openTaskRows([$userId], $viewerId, $viewAll, null) as $row) {
                $pid = (int) $row['project_id'];
                $out[$pid]['open_tasks'] = ($out[$pid]['open_tasks'] ?? 0) + 1;
            }
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }

        foreach ($out as $pid => $figures) {
            $out[$pid] = [
                'tracked'    => (int) ($figures['tracked'] ?? 0),
                'planned'    => (int) ($figures['planned'] ?? 0),
                'open_tasks' => (int) ($figures['open_tasks'] ?? 0),
            ];
        }

        return $out;
    }

    /* ---------------------------------------------------------------- workload */

    /**
     * Planned seconds and block count per person inside [startUtc, endUtc).
     * Blocks are clipped to the window, exactly like Schedule::teamWorkload.
     *
     * @param list<int> $userIds
     * @return array<int, array{planned_seconds: int, blocks: int}>
     */
    public function planned(array $userIds, string $startUtc, string $endUtc, int $viewerId, bool $viewAll): array
    {
        if ($userIds === []) {
            return [];
        }

        $params = ['ws_a' => $startUtc, 'we_a' => $endUtc, 'ws_b' => $startUtc, 'we_b' => $endUtc];
        $in     = self::in('pl', $userIds, $params);
        $vis    = self::visibleProject('p', 'plv', $viewAll, $viewerId, false, $params, 's.user_id');

        $out = [];
        foreach (Database::fetchAll(
            "SELECT s.user_id,
                    SUM(TIMESTAMPDIFF(SECOND, GREATEST(s.start_datetime, :ws_a), LEAST(s.end_datetime, :we_a))) AS secs,
                    COUNT(s.id) AS blocks
             FROM schedules s
             INNER JOIN projects p ON p.id = s.project_id
             WHERE s.user_id IN ({$in}) AND s.status NOT IN ('Cancelled')
               AND s.start_datetime < :we_b AND s.end_datetime > :ws_b AND {$vis}
             GROUP BY s.user_id",
            $params
        ) as $row) {
            $out[(int) $row['user_id']] = [
                'planned_seconds' => max(0, (int) $row['secs']),
                'blocks'          => (int) $row['blocks'],
            ];
        }

        return $out;
    }

    /**
     * Tracked seconds per person for entries that START inside [startUtc, endUtc).
     *
     * @param list<int> $userIds
     * @return array<int, int> user_id => seconds
     */
    public function tracked(array $userIds, string $startUtc, string $endUtc, int $viewerId, bool $viewAll): array
    {
        $cols = self::entryColumns();
        if ($userIds === [] || $cols === null) {
            return [];
        }

        [$startCol, $durCol] = $cols;
        $params = ['ws' => $startUtc, 'we' => $endUtc];
        $in     = self::in('tr', $userIds, $params);
        $vis    = self::visibleProject('p', 'trv', $viewAll, $viewerId, false, $params, 'te.user_id');

        $out = [];
        foreach (Database::fetchAll(
            "SELECT te.user_id, SUM(te.{$durCol}) AS secs
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             WHERE te.user_id IN ({$in}) AND te.{$startCol} >= :ws AND te.{$startCol} < :we AND {$vis}
             GROUP BY te.user_id",
            $params
        ) as $row) {
            $out[(int) $row['user_id']] = (int) $row['secs'];
        }

        return $out;
    }

    /* ------------------------------------------------------------------- tasks */

    /**
     * Open and overdue task counts per person.
     *
     * @param list<int> $userIds
     * @return array<int, array{open: int, overdue: int}>
     */
    public function taskCounts(array $userIds, string $todayLocal, int $viewerId, bool $viewAll): array
    {
        $out = [];

        foreach ($this->openTaskRows($userIds, $viewerId, $viewAll, null) as $row) {
            $uid = (int) $row['user_id'];
            $out[$uid]['open']    = ($out[$uid]['open'] ?? 0) + 1;
            $out[$uid]['overdue'] = ($out[$uid]['overdue'] ?? 0)
                + ((!empty($row['due_date']) && (string) $row['due_date'] < $todayLocal) ? 1 : 0);
        }

        foreach ($out as $uid => $figures) {
            $out[$uid] = ['open' => (int) $figures['open'], 'overdue' => (int) $figures['overdue']];
        }

        return $out;
    }

    /**
     * The next open tasks of one person, soonest due first.
     *
     * @return list<array<string, mixed>>
     */
    public function openTasks(int $userId, int $viewerId, bool $viewAll, int $limit = 10): array
    {
        $rows = $this->openTaskRows([$userId], $viewerId, $viewAll, null);

        usort($rows, static function (array $a, array $b): int {
            $da = (string) ($a['due_date'] ?? '');
            $db = (string) ($b['due_date'] ?? '');
            if ($da === '' && $db !== '') {
                return 1;
            }
            if ($db === '' && $da !== '') {
                return -1;
            }

            return [$da, (int) $a['task_id']] <=> [$db, (int) $b['task_id']];
        });

        return array_slice($rows, 0, max(1, $limit));
    }

    /**
      * One row per (person, open task). Assignees come only from task_assignees.
     *
     * @param list<int> $userIds
     * @return list<array<string, mixed>>
     */
    private function openTaskRows(array $userIds, int $viewerId, bool $viewAll, ?int $limit): array
    {
        if ($userIds === []) {
            return [];
        }

        try {
            $cols     = self::taskColumns();
            $due      = isset($cols['due_date']) ? 't.due_date' : 'NULL';
            $priority = isset($cols['priority']) ? 't.priority' : "'Medium'";

            $params = [];
            $inA    = self::in('ta', $userIds, $params);
            $closed = self::in('tc', self::CLOSED_TASK_STATUSES, $params, false);
            $visA   = self::visibleProject('p', 'tva', $viewAll, $viewerId, false, $params, 'ta.user_id');

            $select = "t.id AS task_id, t.name AS task_name, t.status, {$priority} AS priority, {$due} AS due_date,
                       p.id AS project_id, p.name AS project_name, p.project_code";

            $sql = "SELECT ta.user_id, {$select}
                    FROM task_assignees ta
                    INNER JOIN tasks t ON t.id = ta.task_id
                    INNER JOIN projects p ON p.id = t.project_id
                    WHERE ta.user_id IN ({$inA}) AND t.status NOT IN ({$closed}) AND {$visA}";

            $rows = Database::fetchAll($sql, $params);

            return $limit === null ? $rows : array_slice($rows, 0, $limit);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return [];
        }
    }

    /** @return array<string, true> column names present on the live tasks table */
    private static function taskColumns(): array
    {
        static $cols = null;

        if ($cols === null) {
            $cols = [];
            foreach (array_keys(SchemaHelper::columns('tasks')) as $name) {
                $cols[strtolower($name)] = true;
            }
        }

        return $cols;
    }

    /* ------------------------------------------------------------------ helpers */

    /**
     * Physical start/duration columns of time_entries. Installs differ (start_time vs started_at),
     * so the names come from TimeEntry's own alias map; both are fixed identifiers, never user input.
     *
     * @return array{0: string, 1: string}|null
     */
    private static function entryColumns(): ?array
    {
        if (!TimeEntry::installed()) {
            return null;
        }

        $start    = TimeEntry::column('start_time');
        $duration = TimeEntry::column('duration_seconds');

        if ($start === null || $duration === null
            || !preg_match('/^[a-z_]+$/', $start) || !preg_match('/^[a-z_]+$/', $duration)) {
            return null;
        }

        return [$start, $duration];
    }

    /** True when the schedules table exists (scheduling phase installed). */
    public static function schedulesReady(): bool
    {
        static $ready = null;

        if ($ready === null) {
            $ready = SchemaHelper::tableExists('schedules');
        }

        return $ready;
    }

    /**
     * Placeholder list for an IN (...) clause; values are bound, never concatenated.
     *
     * @param list<int|string> $values
     * @param array<string, mixed> $params
     */
    private static function in(string $prefix, array $values, array &$params, bool $asInt = true): string
    {
        $placeholders = [];
        foreach (array_values($values) as $i => $value) {
            $key            = $prefix . $i;
            $placeholders[] = ':' . $key;
            $params[$key]   = $asInt ? (int) $value : (string) $value;
        }

        return implode(', ', $placeholders);
    }

    /**
     * SQL fragment limiting a projects alias to what the viewer may see.
     * With $ownerColumn, rows owned by the viewer are always included.
     *
     * @param array<string, mixed> $params
     */
    private static function visibleProject(
        string $alias,
        string $key,
        bool $viewAll,
        int $viewerId,
        bool $includeMembership,
        array &$params,
        ?string $ownerColumn = null
    ): string {
        if ($viewAll) {
            return '1 = 1';
        }

        $params[$key . '_a'] = $viewerId;
        $params[$key . '_b'] = $viewerId;
        $sql = "({$alias}.manager_id = :{$key}_a OR {$alias}.created_by = :{$key}_b";

        // A person's OWN time and tasks always count for them, on any project they work on.
        // $ownerColumn is a hard-coded column reference from this class, never user input.
        if ($ownerColumn !== null) {
            $params[$key . '_o'] = $viewerId;
            $sql .= " OR {$ownerColumn} = :{$key}_o";
        }

        if ($includeMembership) {
            $params[$key . '_c'] = $viewerId;
            $sql .= " OR EXISTS (SELECT 1 FROM project_members {$key}m
                                 WHERE {$key}m.project_id = {$alias}.id AND {$key}m.user_id = :{$key}_c)";
        }

        return $sql . ')';
    }
}
