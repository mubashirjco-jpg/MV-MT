(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    document.addEventListener('click', function (event) {
      var button = event.target.closest ? event.target.closest('[data-time-group-toggle]') : null;
      if (!button) return;
      var panel = document.getElementById(button.getAttribute('data-time-group-toggle') + '-chunks');
      if (!panel) return;
      var open = panel.hidden;
      panel.hidden = !open;
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
      button.classList.toggle('is-open', open);
      var group = button.closest('.time-group');
      if (group) group.classList.toggle('is-open', open);
    });

    var all = function () { return document.querySelector('[data-submit-modal-select-all]'); };
    var boxes = function () { return Array.prototype.slice.call(document.querySelectorAll('[data-submit-modal-work]')); };
    var sync = function () {
      var b = boxes(), n = b.filter(function (x) { return x.checked; }).length;
      var count = document.querySelector('[data-submit-modal-count]');
      var submit = document.querySelector('[data-submit-modal-button]');
      var selectAll = all();
      if (count) count.textContent = n;
      if (submit) submit.disabled = n === 0;
      if (selectAll) selectAll.checked = b.length > 0 && n === b.length;
    };
    document.addEventListener('change', function (e) {
      if (e.target.matches && e.target.matches('[data-submit-modal-select-all]')) {
        boxes().forEach(function (b) { b.checked = e.target.checked; });
        sync();
      } else if (e.target.matches && e.target.matches('[data-submit-modal-work]')) {
        sync();
      }
    });
    window.addEventListener('tt:entries-refreshed', sync);
    sync();
  });
})();
