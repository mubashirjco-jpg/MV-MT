(function () {
  'use strict';

  document.addEventListener('DOMContentLoaded', function () {
    var a = document.querySelector('[data-submit-modal-select-all]');
    var c = document.querySelector('[data-submit-modal-count]');
    var s = document.querySelector('[data-submit-modal-button]');
    var b = function () {
      return Array.prototype.slice.call(document.querySelectorAll('[data-submit-modal-work]'));
    };
    var sync = function () {
      var x = b();
      var n = x.filter(function (i) { return i.checked; }).length;
      if (c) c.textContent = n;
      if (s) s.disabled = n === 0;
      if (a) a.checked = x.length > 0 && n === x.length;
    };
    if (a) {
      a.addEventListener('change', function () {
        b().forEach(function (i) { i.checked = a.checked; });
        sync();
      });
    }
    document.addEventListener('change', function (e) {
      if (e.target.matches && e.target.matches('[data-submit-modal-work]')) sync();
    });
    sync();
  });
})();
