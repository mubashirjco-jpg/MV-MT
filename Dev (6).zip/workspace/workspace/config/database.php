<?php
/**
 * Database configuration (MySQL 8 / MariaDB 10.4+).
 *
 * Shared-hosting setup: put the real values directly in the second argument
 * of each line below. The first argument is only the name of an optional
 * environment variable that would override it.
 */

declare(strict_types=1);

$env = static fn (string $key, mixed $default = null): mixed =>
    getenv($key) !== false ? getenv($key) : $default;

return [
    'host'    => $env('DB_HOST', 'localhost'),
    'port'    => (int) $env('DB_PORT', 3306),
    'name'    => $env('DB_NAME', 'u897128490_timetrack'),
    'user'    => $env('DB_USER', 'u897128490_timetracker'),
    'pass'    => $env('DB_PASS', 'Bilamik@2018'),
    'charset' => 'utf8mb4',
];