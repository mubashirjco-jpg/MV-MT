-- =====================================================================
--  TimeTrack: consolidated schema (Phases 1-10)
--  MySQL 8+ / MariaDB 10.4+, InnoDB, utf8mb4.
--
--  One file creates the FINAL structure, so a fresh install does NOT need
--  phase2.sql ... phase10.sql. (Those files are only for upgrading an
--  existing database.) Safe to re-run: every object uses IF NOT EXISTS.
--
--      mysql -u USER -p DATABASE < database/schema.sql
--      mysql -u USER -p DATABASE < database/seed.sql
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `clients` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(160) NOT NULL,
    `email` varchar(190) DEFAULT NULL,
    `phone` varchar(30) DEFAULT NULL,
    `company` varchar(160) DEFAULT NULL,
    `address` varchar(500) DEFAULT NULL,
    `status` enum('active','inactive') NOT NULL DEFAULT 'active',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_clients_name` (`name`),
    KEY `idx_clients_email` (`email`),
    KEY `idx_clients_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `permissions` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(60) NOT NULL,
    `display_name` varchar(100) NOT NULL,
    `module` varchar(40) NOT NULL,
    `description` varchar(255) DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_permissions_name` (`name`),
    KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `roles` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(30) NOT NULL,
    `display_name` varchar(60) NOT NULL,
    `description` varchar(255) DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `role_permissions` (
    `role_id` int UNSIGNED NOT NULL,
    `permission_id` int UNSIGNED NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`role_id`,`permission_id`),
    KEY `idx_role_permissions_permission` (`permission_id`),
    CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `role_id` int UNSIGNED NOT NULL,
    `role` enum('admin','manager','employee','client') NOT NULL DEFAULT 'employee',
    `name` varchar(120) NOT NULL,
    `email` varchar(190) NOT NULL,
    `password` varchar(255) NOT NULL,
    `phone` varchar(30) DEFAULT NULL,
    `job_title` varchar(100) DEFAULT NULL,
    `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
    `timezone` varchar(64) NOT NULL DEFAULT 'UTC',
    `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
    `failed_login_attempts` tinyint UNSIGNED NOT NULL DEFAULT 0,
    `locked_until` datetime DEFAULT NULL,
    `last_login_at` datetime DEFAULT NULL,
    `last_login_ip` varchar(45) DEFAULT NULL,
    `password_changed_at` datetime DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_users_email` (`email`),
    KEY `idx_users_status` (`status`),
    KEY `idx_users_role_id` (`role_id`),
    KEY `idx_users_role_status` (`role`,`status`),
    CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `workspaces` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(160) NOT NULL,
    `logo_path` varchar(500) DEFAULT NULL,
    `created_by` int UNSIGNED DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_workspaces_created_by` (`created_by`),
    CONSTRAINT `fk_workspaces_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `workspace_settings` (
    `workspace_id` int UNSIGNED NOT NULL,
    `setting_key` varchar(80) NOT NULL,
    `setting_value` varchar(1000) DEFAULT NULL,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`workspace_id`,`setting_key`),
    CONSTRAINT `fk_workspace_settings_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `activity_logs` (
    `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` int UNSIGNED DEFAULT NULL,
    `action` varchar(100) NOT NULL,
    `module` varchar(60) DEFAULT NULL,
    `entity_type` varchar(60) DEFAULT NULL,
    `entity_id` int UNSIGNED DEFAULT NULL,
    `record_id` int UNSIGNED DEFAULT NULL,
    `ip_address` varchar(45) DEFAULT NULL,
    `user_agent` varchar(255) DEFAULT NULL,
    `old_value` longtext DEFAULT NULL,
    `new_value` longtext DEFAULT NULL,
    `meta` longtext DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_activity_user` (`user_id`),
    KEY `idx_activity_action` (`action`),
    KEY `idx_activity_entity` (`entity_type`,`entity_id`),
    KEY `idx_activity_created` (`created_at`),
    CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
    `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` int UNSIGNED NOT NULL,
    `type` varchar(40) NOT NULL DEFAULT 'info',
    `title` varchar(160) NOT NULL,
    `message` varchar(500) DEFAULT NULL,
    `link` varchar(255) DEFAULT NULL,
    `is_read` tinyint(1) NOT NULL DEFAULT 0,
    `read_at` datetime DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`),
    CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `projects` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `client_id` int UNSIGNED NOT NULL,
    `project_code` varchar(50) NOT NULL,
    `name` varchar(180) NOT NULL,
    `description` text DEFAULT NULL,
    `start_date` date DEFAULT NULL,
    `due_date` date DEFAULT NULL,
    `status` enum('Planning','Active','On Hold','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Planning',
    `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
    `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
    `budget` decimal(14,2) NOT NULL DEFAULT 0.00,
    `hourly_rate` decimal(12,2) NOT NULL DEFAULT 0.00,
    `is_billable` tinyint(1) NOT NULL DEFAULT 1,
    `is_public` tinyint(1) NOT NULL DEFAULT 0,
    `color` varchar(7) NOT NULL DEFAULT '#03A9F4',
    `estimate_type` enum('none','time','budget') NOT NULL DEFAULT 'none',
    `manager_id` int UNSIGNED DEFAULT NULL,
    `created_by` int UNSIGNED DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_projects_code` (`project_code`),
    KEY `idx_projects_client` (`client_id`),
    KEY `idx_projects_status` (`status`),
    KEY `idx_projects_manager` (`manager_id`),
    KEY `idx_projects_due` (`due_date`),
    KEY `fk_projects_created_by` (`created_by`),
    CONSTRAINT `fk_projects_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON UPDATE CASCADE,
    CONSTRAINT `fk_projects_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_projects_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project_favorites` (
    `user_id` int UNSIGNED NOT NULL,
    `project_id` int UNSIGNED NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`,`project_id`),
    KEY `idx_project_favorites_project` (`project_id`),
    CONSTRAINT `fk_project_favorites_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_project_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project_members` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id` int UNSIGNED NOT NULL,
    `user_id` int UNSIGNED NOT NULL,
    `project_role` varchar(60) NOT NULL DEFAULT 'Member',
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_project_members_project_user` (`project_id`,`user_id`),
    KEY `idx_project_members_user` (`user_id`),
    CONSTRAINT `fk_project_members_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_project_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `schedules` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id` int UNSIGNED NOT NULL,
    `task_id` int UNSIGNED DEFAULT NULL,
    `user_id` int UNSIGNED NOT NULL,
    `start_datetime` datetime NOT NULL,
    `end_datetime` datetime NOT NULL,
    `estimated_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
    `status` enum('Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
    `notes` text DEFAULT NULL,
    `created_by` int UNSIGNED DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_schedules_user_time` (`user_id`,`start_datetime`,`end_datetime`),
    KEY `idx_schedules_project` (`project_id`),
    KEY `idx_schedules_task` (`task_id`),
    KEY `idx_schedules_status` (`status`),
    KEY `idx_schedules_created_by` (`created_by`),
    CONSTRAINT `fk_schedules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_schedules_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_schedules_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `schedule_recurrences` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `schedule_id` int UNSIGNED NOT NULL,
    `recurrence_type` enum('daily','weekly','weekdays','custom') NOT NULL DEFAULT 'weekly',
    `repeat_until` date DEFAULT NULL,
    `days_of_week` varchar(20) DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_recurrence_schedule` (`schedule_id`),
    CONSTRAINT `fk_recurrence_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tasks` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id` int UNSIGNED NOT NULL,
    `parent_task_id` int UNSIGNED DEFAULT NULL,
    `name` varchar(180) NOT NULL,
    `description` text DEFAULT NULL,
    `status` enum('Open','In Progress','Done') NOT NULL DEFAULT 'Open',
    `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
    `assigned_to` int UNSIGNED DEFAULT NULL,
    `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
    `completion_percent` tinyint UNSIGNED NOT NULL DEFAULT 0,
    `start_date` date DEFAULT NULL,
    `due_date` date DEFAULT NULL,
    `is_billable` tinyint(1) NOT NULL DEFAULT 0,
    `created_by` int UNSIGNED DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_tasks_project` (`project_id`),
    KEY `idx_tasks_parent` (`parent_task_id`),
    KEY `idx_tasks_assigned` (`assigned_to`),
    KEY `idx_tasks_status` (`status`),
    KEY `idx_tasks_priority` (`priority`),
    KEY `idx_tasks_due` (`due_date`),
    KEY `fk_tasks_created_by` (`created_by`),
    CONSTRAINT `fk_tasks_assigned` FOREIGN KEY (`assigned_to`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_tasks_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_tasks_parent` FOREIGN KEY (`parent_task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_tasks_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `active_timers` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` int UNSIGNED NOT NULL,
    `project_id` int UNSIGNED NOT NULL,
    `task_id` int UNSIGNED DEFAULT NULL,
    `started_at` datetime NOT NULL,
    `last_activity_at` datetime NOT NULL,
    `paused_at` datetime DEFAULT NULL,
    `accumulated_seconds` int UNSIGNED NOT NULL DEFAULT 0,
    `description` varchar(255) DEFAULT NULL,
    `is_billable` tinyint(1) NOT NULL DEFAULT 1,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_active_timers_user` (`user_id`),
    KEY `idx_active_timers_project` (`project_id`),
    KEY `idx_active_timers_task` (`task_id`),
    CONSTRAINT `fk_active_timers_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_active_timers_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_active_timers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `task_assignees` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `task_id` int UNSIGNED NOT NULL,
    `user_id` int UNSIGNED NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_task_assignees` (`task_id`,`user_id`),
    KEY `idx_task_assignees_user` (`user_id`),
    CONSTRAINT `fk_task_assignees_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_task_assignees_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `time_entries` (
    `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id` int UNSIGNED NOT NULL,
    `task_id` int UNSIGNED DEFAULT NULL,
    `user_id` int UNSIGNED NOT NULL,
    `started_at` datetime NOT NULL,
    `ended_at` datetime DEFAULT NULL,
    `duration_seconds` int UNSIGNED NOT NULL DEFAULT 0,
    `is_billable` tinyint(1) NOT NULL DEFAULT 0,
    `description` varchar(500) DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_time_entries_project` (`project_id`),
    KEY `idx_time_entries_task` (`task_id`),
    KEY `idx_time_entries_user` (`user_id`),
    KEY `idx_time_entries_running` (`user_id`,`ended_at`),
    CONSTRAINT `fk_time_entries_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_time_entries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `timesheets` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_id` int UNSIGNED NOT NULL,
    `start_date` date NOT NULL,
    `end_date` date NOT NULL,
    `total_seconds` int UNSIGNED NOT NULL DEFAULT 0,
    `billable_seconds` int UNSIGNED NOT NULL DEFAULT 0,
    `status` enum('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
    `submitted_at` datetime DEFAULT NULL,
    `approved_by` int UNSIGNED DEFAULT NULL,
    `approved_at` datetime DEFAULT NULL,
    `rejection_reason` varchar(500) DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_timesheets_user_period` (`user_id`,`start_date`,`end_date`),
    KEY `idx_timesheets_status` (`status`),
    KEY `idx_timesheets_submitted` (`submitted_at`),
    KEY `idx_timesheets_approved_by` (`approved_by`),
    CONSTRAINT `fk_timesheets_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT `fk_timesheets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `setting_key` varchar(80) NOT NULL,
    `setting_value` text DEFAULT NULL,
    `setting_type` enum('string','int','bool','json') NOT NULL DEFAULT 'string',
    `setting_group` varchar(40) NOT NULL DEFAULT 'general',
    `description` varchar(255) DEFAULT NULL,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_settings_key` (`setting_key`),
    KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `timesheet_entries` (
    `timesheet_id` int UNSIGNED NOT NULL,
    `time_entry_id` int UNSIGNED NOT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`timesheet_id`,`time_entry_id`),
    UNIQUE KEY `uq_timesheet_entries_entry` (`time_entry_id`),
    KEY `idx_timesheet_entries_timesheet` (`timesheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Read-only alias of activity_logs used by Settings > Audit logs.
-- SQL SECURITY INVOKER: no hard-coded DEFINER, so it imports on any host.
CREATE OR REPLACE SQL SECURITY INVOKER VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`, `record_id`,
           `ip_address`, `user_agent`, `meta`, `old_value`, `new_value`, `created_at`
    FROM `activity_logs`;

SET FOREIGN_KEY_CHECKS = 1;