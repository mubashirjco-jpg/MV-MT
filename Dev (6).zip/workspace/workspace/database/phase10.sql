-- =====================================================================
--  TimeTrack: Phase 10, Clockify-style project page
--  (Access visibility, project colour, estimate type, favourites)
--  Run AFTER Phase 1..9 on an existing database:
--
--      mysql -u USER -p DATABASE < database/phase10.sql
--
--  Safe to re-run on MariaDB (XAMPP). On MySQL 8 run the ALTER once.
-- =====================================================================

SET NAMES utf8mb4;

-- is_public : 0 = private (only members), 1 = public (everyone can see / track time)
-- color     : swatch used on the Settings tab
-- estimate_type : none | time | budget  (Settings > Project estimate)
ALTER TABLE `projects`
    ADD COLUMN IF NOT EXISTS `is_public`     TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_billable`,
    ADD COLUMN IF NOT EXISTS `color`         VARCHAR(7) NOT NULL DEFAULT '#03A9F4' AFTER `is_public`,
    ADD COLUMN IF NOT EXISTS `estimate_type` ENUM('none','time','budget') NOT NULL DEFAULT 'none' AFTER `color`;

-- Existing projects keep their current estimate: derive the type once.
UPDATE `projects`
   SET `estimate_type` = CASE
        WHEN `estimated_hours` > 0 THEN 'time'
        WHEN `budget` > 0 THEN 'budget'
        ELSE 'none' END
 WHERE `estimate_type` = 'none';

-- Star button next to the project title.
CREATE TABLE IF NOT EXISTS `project_favorites` (
    `user_id`    INT UNSIGNED NOT NULL,
    `project_id` INT UNSIGNED NOT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`user_id`, `project_id`),
    KEY `idx_project_favorites_project` (`project_id`),
    CONSTRAINT `fk_project_favorites_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_project_favorites_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
