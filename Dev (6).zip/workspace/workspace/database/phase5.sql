-- =====================================================================
--  TimeTrack: Phase 5 schema, tasks inside projects
--  Run AFTER Phase 1, 2 and 4 on an existing database.
--  Safe to re-run: tables use IF NOT EXISTS.
--
--      mysql -u USER -p DATABASE < database/phase5.sql
--
--  Once this table exists the Schedule screens pick it up automatically
--  (the "Task" dropdown in the planner is filled from it).
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ---------------------------------------------------------------------
-- tasks: units of work inside a project
-- Statuses: Open, In Progress, Done
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `tasks` (
    `id`              INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `project_id`      INT UNSIGNED NOT NULL,
    `name`            VARCHAR(160) NOT NULL,
    `description`     TEXT         NULL,
    `status`          ENUM('Open','In Progress','Done') NOT NULL DEFAULT 'Open',
    `estimated_hours` DECIMAL(8,2) NOT NULL DEFAULT 0.00,
    `due_date`        DATE         NULL,
    `created_by`      INT UNSIGNED NULL,
    `created_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`      DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_tasks_project_name` (`project_id`, `name`),
    KEY `idx_tasks_status` (`project_id`, `status`),
    KEY `idx_tasks_created_by` (`created_by`),
    CONSTRAINT `fk_tasks_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_tasks_created_by`
        FOREIGN KEY (`created_by`) REFERENCES `users` (`id`)
        ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- task_assignees: who a task is assigned to.
-- A task with no rows here is open to "Anyone" on the project.
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `task_assignees` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `task_id`    INT UNSIGNED NOT NULL,
    `user_id`    INT UNSIGNED NOT NULL,
    `created_at` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_task_assignees` (`task_id`, `user_id`),
    KEY `idx_task_assignees_user` (`user_id`),
    CONSTRAINT `fk_task_assignees_task`
        FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `fk_task_assignees_user`
        FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- Make sure the task permissions exist and are mapped (no-ops if seed.sql
-- was already run with them). Admin gets everything; manager and employee
-- get the same task abilities as in seed.sql.
-- ---------------------------------------------------------------------
INSERT INTO `permissions` (`name`, `display_name`, `module`, `description`) VALUES
    ('tasks.view',   'View tasks',   'tasks', 'See tasks on assigned projects.'),
    ('tasks.create', 'Create tasks', 'tasks', 'Add tasks to projects.'),
    ('tasks.edit',   'Edit tasks',   'tasks', 'Change tasks.'),
    ('tasks.delete', 'Delete tasks', 'tasks', 'Remove tasks.'),
    ('tasks.assign', 'Assign tasks', 'tasks', 'Assign tasks to people.')
ON DUPLICATE KEY UPDATE `display_name` = VALUES(`display_name`);

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 1, `id` FROM `permissions` WHERE `module` = 'tasks';

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 2, `id` FROM `permissions`
WHERE `name` IN ('tasks.view', 'tasks.create', 'tasks.edit', 'tasks.delete', 'tasks.assign');

INSERT IGNORE INTO `role_permissions` (`role_id`, `permission_id`)
SELECT 3, `id` FROM `permissions` WHERE `name` IN ('tasks.view', 'tasks.edit');
