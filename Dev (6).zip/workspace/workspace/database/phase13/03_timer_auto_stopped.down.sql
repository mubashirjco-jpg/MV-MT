-- Phase 13 / Step 9 rollback.
-- Safe to run repeatedly on MariaDB 11.8.

ALTER TABLE `time_entries`
    DROP COLUMN IF EXISTS `auto_stopped`;
