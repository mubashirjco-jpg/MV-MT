-- TimeTrack Phase 13 / Step 13
-- SAFE CLEANUP of the known bad recurrence rows 3-16.
--
-- IMPORTANT: run 05_schedule_bad_rows.preview.sql first and inspect it.
-- This script will ROLLBACK unless all 14 IDs (3..16) are still owned by
-- user name "Test" and each spans at least 12 days.

DELIMITER //

DROP PROCEDURE IF EXISTS `tt_step13_cleanup_bad_schedule_rows`//

CREATE PROCEDURE `tt_step13_cleanup_bad_schedule_rows`()
BEGIN
    DECLARE id_count INT DEFAULT 0;
    DECLARE safe_count INT DEFAULT 0;
    DECLARE deleted_count INT DEFAULT 0;

    START TRANSACTION;

    SELECT
        s.id,
        s.user_id,
        u.name AS user_name,
        s.start_datetime,
        s.end_datetime,
        TIMESTAMPDIFF(DAY, s.start_datetime, s.end_datetime) AS span_days,
        s.status,
        s.recurrence_parent_id
    FROM schedules s
    JOIN users u ON u.id = s.user_id
    WHERE s.id BETWEEN 3 AND 16
    ORDER BY s.id;

    SELECT COUNT(*) INTO id_count
    FROM schedules
    WHERE id BETWEEN 3 AND 16;

    SELECT COUNT(*) INTO safe_count
    FROM schedules s
    JOIN users u ON u.id = s.user_id
    WHERE s.id BETWEEN 3 AND 16
      AND u.name = 'Test'
      AND TIMESTAMPDIFF(HOUR, s.start_datetime, s.end_datetime) >= (12 * 24);

    IF id_count <> 14 OR safe_count <> 14 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cleanup aborted: rows 3-16 did not all match the expected Test / >=12-day corruption pattern.';
    END IF;

    DELETE FROM schedules
    WHERE id BETWEEN 3 AND 16;

    SET deleted_count = ROW_COUNT();

    IF deleted_count <> 14 THEN
        ROLLBACK;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'Cleanup aborted: expected to delete exactly 14 rows.';
    END IF;

    COMMIT;

    SELECT deleted_count AS deleted_rows;
END//

DELIMITER ;

CALL `tt_step13_cleanup_bad_schedule_rows`();
DROP PROCEDURE IF EXISTS `tt_step13_cleanup_bad_schedule_rows`;
