-- =====================================================================
-- Phase 11: Workspace foundation
-- Adds a first-class workspace with branding, workspace policies and
-- role-permission management. Safe for an existing Phase 1-10 database.
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

CREATE TABLE IF NOT EXISTS `workspaces` (
    `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
    `name` varchar(160) NOT NULL,
    `logo_path` varchar(500) DEFAULT NULL,
    `created_by` int UNSIGNED DEFAULT NULL,
    `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    KEY `idx_workspaces_created_by` (`created_by`),
    CONSTRAINT `fk_workspaces_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `workspace_settings` (
    `workspace_id` int UNSIGNED NOT NULL,
    `setting_key` varchar(80) NOT NULL,
    `setting_value` varchar(1000) DEFAULT NULL,
    `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`workspace_id`,`setting_key`),
    CONSTRAINT `fk_workspace_settings_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `workspaces` (`id`, `name`, `created_by`)
SELECT 1,
       COALESCE((SELECT setting_value FROM settings WHERE setting_key = 'company_name' LIMIT 1), 'TimeTrack'),
       (SELECT id FROM users WHERE role = 'admin' ORDER BY id ASC LIMIT 1)
WHERE NOT EXISTS (SELECT 1 FROM workspaces);

INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`)
SELECT 1, 'timesheet_enabled', '0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id = 1 AND setting_key = 'timesheet_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'hide_tracker','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='hide_tracker');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'kiosk_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='kiosk_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'default_project_visibility','private' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='default_project_visibility');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'organize_time_by','project_task' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='organize_time_by');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'duration_format','clock_seconds' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='duration_format');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'week_start','monday' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='week_start');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'working_days','Mon,Tue,Wed,Thu,Fri' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='working_days');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'daily_capacity','8' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='daily_capacity');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'favorites_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='favorites_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'favorite_entries_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='favorite_entries_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'required_fields','' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='required_fields');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'breaks_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='breaks_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'time_rounding_minutes','1' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='time_rounding_minutes');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'time_approval_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='time_approval_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'approval_period','weekly' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='approval_period');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'expense_approval_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='expense_approval_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'time_off_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='time_off_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'invoicing_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='invoicing_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'expenses_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='expenses_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'scheduling_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='scheduling_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'activity_monitoring_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='activity_monitoring_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'gps_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='gps_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'screenshots_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='screenshots_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'audit_log_enabled','1' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='audit_log_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'billable_hours_enabled','1' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='billable_hours_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'project_creation_policy','admins' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='project_creation_policy');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'task_creation_policy','admins_project_managers' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='task_creation_policy');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'tag_creation_policy','admins' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='tag_creation_policy');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'regular_user_time_visibility','own' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='regular_user_time_visibility');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'project_status_visibility','admins' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='project_status_visibility');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'hide_projects','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='hide_projects');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'hide_team','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='hide_team');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'hide_reports','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='hide_reports');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'timesheet_approver_policy','admins_team_managers' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='timesheet_approver_policy');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'edit_time_others_policy','admins' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='edit_time_others_policy');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'invoice_manager_policy','admins' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='invoice_manager_policy');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'lock_time_enabled','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='lock_time_enabled');
INSERT INTO `workspace_settings` (`workspace_id`,`setting_key`,`setting_value`) SELECT 1,'force_timer','0' WHERE NOT EXISTS (SELECT 1 FROM workspace_settings WHERE workspace_id=1 AND setting_key='force_timer');

INSERT INTO `permissions` (`name`,`display_name`,`module`,`description`)
VALUES ('workspace.manage','Manage workspace','workspace','Change workspace identity, policies and workspace permissions.')
ON DUPLICATE KEY UPDATE display_name=VALUES(display_name), module=VALUES(module), description=VALUES(description);
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
SELECT r.id, p.id FROM roles r CROSS JOIN permissions p WHERE r.name='admin' AND p.name='workspace.manage';

SET FOREIGN_KEY_CHECKS = 1;
