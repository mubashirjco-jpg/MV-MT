<?php

declare(strict_types=1);

final class WorkspaceController extends Controller
{
    private Workspace $workspace;

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN]);
        $this->workspace = new Workspace();
    }

    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('workspace.manage');

        $workspace = Workspace::current();
        if ($workspace === null) {
            throw new HttpException(500, 'Workspace has not been initialized.');
        }

        $tab = (string) $request->input('tab', 'general');
        if (!in_array($tab, ['general', 'permissions', 'features'], true)) {
            $tab = 'general';
        }

        $this->render('workspace/index', [
            'pageTitle' => 'Workspace settings',
            'workspace' => $workspace,
            'settings' => Workspace::settings((int) $workspace['id']),
            'tab' => $tab,
            'roles' => Workspace::rolesWithPermissions(),
            'permissions' => Workspace::permissions(),
            'rolePermissionMap' => Workspace::rolePermissionMap(),
        ]);
    }

    public function updateGeneral(Request $request, array $params): void
    {
        PermissionHelper::require('workspace.manage');
        $workspace = Workspace::current();
        if ($workspace === null) throw new HttpException(500, 'Workspace has not been initialized.');

        $data = $this->validate([
            'name' => 'required|string|max:160',
        ], '/workspace?tab=general', ['name' => 'Workspace name']);

        $logoPath = (string) ($workspace['logo_path'] ?? '');

        // If PHP rejected the upload before populating $_FILES (for example because
        // post_max_size is smaller than the selected file), report that explicitly
        // instead of leaving the user staring at a processing state.
        $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
        $postMax = (string) ini_get('post_max_size');
        $postMaxBytes = self::iniBytes($postMax);
        if ($contentLength > 0 && $postMaxBytes > 0 && $contentLength > $postMaxBytes && empty($_FILES)) {
            $this->backWithErrors('/workspace?tab=general', ['logo' => 'The upload is larger than the server POST limit (' . $postMax . '). Please use a smaller image.']);
        }

        if (isset($_FILES['logo']) && is_array($_FILES['logo']) && (int) ($_FILES['logo']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
            $file = $_FILES['logo'];
            if ((int) $file['error'] !== UPLOAD_ERR_OK) {
                $this->backWithErrors('/workspace?tab=general', ['logo' => 'The logo upload failed.']);
            }
            if ((int) $file['size'] > 5 * 1024 * 1024) {
                $this->backWithErrors('/workspace?tab=general', ['logo' => 'Logo must be 5 MB or smaller.']);
            }
            $imageInfo = @getimagesize((string) $file['tmp_name']);
            $mime = is_array($imageInfo) ? (string) ($imageInfo['mime'] ?? '') : '';
            $allowed = ['image/png' => 'png', 'image/jpeg' => 'jpg'];
            if (!isset($allowed[$mime])) {
                $this->backWithErrors('/workspace?tab=general', ['logo' => 'Logo must be a PNG or JPG image.']);
            }
            $dir = PUBLIC_PATH . '/uploads/workspace';
            if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
                throw new RuntimeException('Could not create workspace upload directory.');
            }
            $filename = 'logo-' . bin2hex(random_bytes(10)) . '.' . $allowed[$mime];
            if (!move_uploaded_file((string) $file['tmp_name'], $dir . '/' . $filename)) {
                $this->backWithErrors('/workspace?tab=general', ['logo' => 'The logo could not be saved.']);
            }
            $logoPath = '/uploads/workspace/' . $filename;
        }

        Database::execute(
            'UPDATE workspaces SET name = :name, logo_path = :logo, updated_at = UTC_TIMESTAMP() WHERE id = :id',
            ['name' => $data['name'], 'logo' => $logoPath !== '' ? $logoPath : null, 'id' => (int) $workspace['id']]
        );

        $this->flash('success', 'Workspace details were saved.');
        $this->redirect('/workspace?tab=general');
    }

    private static function iniBytes(string $value): int
    {
        $value = trim($value);
        if ($value === '') return 0;
        $unit = strtolower(substr($value, -1));
        $number = (float) $value;
        if ($unit === 'g') $number *= 1024 * 1024 * 1024;
        elseif ($unit === 'm') $number *= 1024 * 1024;
        elseif ($unit === 'k') $number *= 1024;
        return (int) round($number);
    }

    public function updateFeatures(Request $request, array $params): void
    {
        PermissionHelper::require('workspace.manage');
        $workspace = Workspace::current();
        if ($workspace === null) throw new HttpException(500, 'Workspace has not been initialized.');
        $id = (int) $workspace['id'];

        $bools = [
            'timesheet_enabled','hide_tracker','kiosk_enabled','favorites_enabled','favorite_entries_enabled',
            'breaks_enabled','time_approval_enabled','expense_approval_enabled','time_off_enabled','invoicing_enabled',
            'expenses_enabled','scheduling_enabled','activity_monitoring_enabled','gps_enabled','screenshots_enabled',
            'audit_log_enabled','billable_hours_enabled','hide_projects','hide_team','hide_reports','lock_time_enabled','force_timer',
        ];
        // Only DEFAULT_SETTINGS keys are writable here, so a crafted POST cannot create system or arbitrary rows.
        foreach ($bools as $key) {
            SettingsService::setWorkspace($id, $key, $request->input($key) ? '1' : '0');
        }

        $allowed = [
            'default_project_visibility' => ['public','private'],
            'organize_time_by' => ['project_task','project','task'],
            'duration_format' => ['clock','clock_seconds'],
            'week_start' => ['monday','sunday'],
            'approval_period' => ['weekly','semi-monthly','monthly'],
            'project_creation_policy' => ['admins','admins_project_managers','anyone'],
            'task_creation_policy' => ['admins','admins_project_managers','anyone'],
            'tag_creation_policy' => ['admins','anyone'],
            'regular_user_time_visibility' => ['all','public','own'],
            'project_status_visibility' => ['admins','anyone'],
            'timesheet_approver_policy' => ['admins_team_managers','admins_project_managers'],
            'edit_time_others_policy' => ['admins','admins_team_managers'],
            'invoice_manager_policy' => ['admins','specific_members'],
        ];
        foreach ($allowed as $key => $values) {
            $value = (string) $request->input($key, Workspace::DEFAULT_SETTINGS[$key]);
            if (in_array($value, $values, true)) SettingsService::setWorkspace($id, $key, $value);
        }

        $workingDays = $request->input('working_days', []);
        if (!is_array($workingDays)) $workingDays = [];
        $workingDays = array_values(array_intersect(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'], array_map('strval', $workingDays)));
        SettingsService::setWorkspace($id, 'working_days', implode(',', $workingDays));

        $capacity = max(1, min(24, (float) $request->input('daily_capacity', 8)));
        SettingsService::setWorkspace($id, 'daily_capacity', (string) $capacity);
        SettingsService::setWorkspace($id, 'time_rounding_minutes', (string) max(1, min(60, (int) $request->input('time_rounding_minutes', 1))));

        $required = $request->input('required_fields', []);
        if (!is_array($required)) $required = [];
        $required = array_values(array_intersect(['Project','Task','Tag','Description'], array_map('strval', $required)));
        SettingsService::setWorkspace($id, 'required_fields', implode(',', $required));

        $this->flash('success', 'Workspace feature settings were saved.');
        $this->redirect('/workspace?tab=features');
    }

    public function updatePermissions(Request $request, array $params): void
    {
        PermissionHelper::require('workspace.manage');
        $workspace = Workspace::current();
        if ($workspace === null) throw new HttpException(500, 'Workspace has not been initialized.');

        $roles = Workspace::rolesWithPermissions();
        $permissions = Workspace::permissions();
        $posted = $request->input('permissions', []);
        if (!is_array($posted)) $posted = [];

        Database::transaction(function () use ($roles, $permissions, $posted): void {
            $validPermissions = [];
            foreach ($permissions as $permission) $validPermissions[(int) $permission['id']] = true;

            foreach ($roles as $role) {
                $roleId = (int) $role['id'];
                Database::execute('DELETE FROM role_permissions WHERE role_id = :role', ['role' => $roleId]);
                $selected = $posted[(string) $roleId] ?? [];
                if (!is_array($selected)) $selected = [];
                foreach ($selected as $permissionId) {
                    $permissionId = (int) $permissionId;
                    if (!isset($validPermissions[$permissionId])) continue;
                    Database::execute(
                        'INSERT IGNORE INTO role_permissions (role_id, permission_id) VALUES (:role, :permission)',
                        ['role' => $roleId, 'permission' => $permissionId]
                    );
                }
            }
        });

        $this->flash('success', 'Workspace permissions were saved.');
        $this->redirect('/workspace?tab=permissions');
    }
}
