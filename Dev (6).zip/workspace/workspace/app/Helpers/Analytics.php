<?php
/**
 * Planned vs actual calculations for projects, tasks, people, and date ranges.
 *
 * Planned hours come from task/project estimates or from schedule blocks.
 * Actual hours come from time_entries.duration_seconds. Health uses budget when
 * a project has one, otherwise actual / planned hours (At Risk >85%, Over Budget >100%).
 */

declare(strict_types=1);

final class AnalyticsHelper
{
    public const HEALTH_ON_TRACK    = 'On Track';
    public const HEALTH_AT_RISK     = 'At Risk';
    public const HEALTH_OVER_BUDGET = 'Over Budget';

    public const RISK_RATIO = 0.85;

    /**
     * @param array{
     *     project_id?: int,
     *     task_id?: int,
     *     user_id?: int,
     *     from?: string,
     *     to?: string,
     *     start_utc?: string,
     *     end_utc?: string,
     *     planned_source?: string
     * } $filters
     * @return array{
     *     planned_hours: float,
     *     actual_hours: float,
     *     actual_seconds: int,
     *     variance_hours: float,
     *     variance_formatted: string,
     *     billable_hours: float,
     *     billable_amount: float,
     *     budget: float,
     *     budget_used: float,
     *     budget_percent: int,
     *     usage_percent: int,
     *     health: string,
     *     health_class: string
     * }
     */
    public static function summarize(array $filters = []): array
    {
        $range  = self::resolveRange($filters);
        $source = (string) ($filters['planned_source'] ?? 'auto');
        if (!in_array($source, ['auto', 'estimate', 'schedule'], true)) {
            $source = 'auto';
        }
        if ($source === 'auto') {
            $source = $range !== null ? 'schedule' : 'estimate';
        }

        $planned = $source === 'schedule'
            ? self::scheduledHours($filters, $range)
            : self::estimatedHours($filters);

        $actual = self::trackedTotals($filters, $range);

        $budget = 0.0;
        $projectId = (int) ($filters['project_id'] ?? 0);
        if ($projectId > 0) {
            $project = self::projectRow($projectId);
            if ($project !== null) {
                $budget = (float) $project['budget'];
                if ($source === 'estimate' && $planned <= 0) {
                    $planned = (float) $project['estimated_hours'];
                }
            }
        }

        $variance = $actual['hours'] - $planned;
        $health   = self::healthStatus($actual['hours'], $planned, $actual['amount'], $budget);

        return [
            'planned_hours'      => round($planned, 2),
            'actual_hours'       => round($actual['hours'], 2),
            'actual_seconds'     => $actual['seconds'],
            'variance_hours'     => round($variance, 2),
            'variance_formatted' => self::formatVariance($variance),
            'billable_hours'     => round($actual['billable_hours'], 2),
            'billable_amount'    => round($actual['amount'], 2),
            'budget'             => round($budget, 2),
            'budget_used'        => round($actual['amount'], 2),
            'budget_percent'     => self::percent($actual['amount'], $budget),
            'usage_percent'      => self::percent($actual['hours'], $planned),
            'health'             => $health['label'],
            'health_class'       => $health['class'],
        ];
    }

    /**
     * Local calendar day (viewer timezone) as an inclusive UTC window.
     *
     * @return array{local_date: string, start_utc: string, end_utc: string}
     */
    public static function localDayBounds(?string $date = null): array
    {
        $tz = new DateTimeZone(FormatHelper::displayTimezone());
        $start = null;

        if ($date !== null && preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) === 1) {
            $start = DateTimeImmutable::createFromFormat('!Y-m-d', $date, $tz) ?: null;
        }

        if ($start === null) {
            $start = (new DateTimeImmutable('now', $tz))->setTime(0, 0, 0);
        }

        $end = $start->setTime(23, 59, 59);
        $utc = new DateTimeZone('UTC');

        return [
            'local_date' => $start->format('Y-m-d'),
            'start_utc'  => $start->setTimezone($utc)->format('Y-m-d H:i:s'),
            'end_utc'    => $end->setTimezone($utc)->format('Y-m-d H:i:s'),
        ];
    }

    /** +1h 30m / -45m / 0h 00m */
    public static function formatVariance(float $hours): string
    {
        $seconds = (int) round($hours * 3600);
        $sign    = $seconds > 0 ? '+' : ($seconds < 0 ? '-' : '');
        $abs     = abs($seconds);
        $h       = intdiv($abs, 3600);
        $m       = intdiv($abs % 3600, 60);

        if ($h === 0) {
            return $sign . $m . 'm';
        }

        return $sign . $h . 'h ' . sprintf('%02dm', $m);
    }

    public static function formatHours(float $hours, int $decimals = 1): string
    {
        return number_format($hours, $decimals, '.', '');
    }

    public static function currency(): string
    {
        try {
            return strtoupper(SettingsService::systemString('currency', 'USD'));
        } catch (Throwable) {
            return 'USD';
        }
    }

    /**
     * @return array{label: string, class: string}
     */
    public static function healthStatus(float $actualHours, float $plannedHours, float $spent = 0.0, float $budget = 0.0): array
    {
        if ($budget > 0) {
            $ratio = $spent / $budget;
        } elseif ($plannedHours > 0) {
            $ratio = $actualHours / $plannedHours;
        } else {
            $ratio = 0.0;
        }

        if ($ratio > 1) {
            return ['label' => self::HEALTH_OVER_BUDGET, 'class' => 'over'];
        }
        if ($ratio > self::RISK_RATIO) {
            return ['label' => self::HEALTH_AT_RISK, 'class' => 'risk'];
        }

        return ['label' => self::HEALTH_ON_TRACK, 'class' => 'track'];
    }

    /**
     * Admin/manager home KPIs for "today" in the viewer's timezone.
     *
     * @return array{
     *     tracked_seconds: int,
     *     tracked_hours: float,
     *     scheduled_hours: float,
     *     variance_hours: float,
     *     variance_formatted: string,
     *     active_projects: int,
     *     pending_approvals: int,
     *     local_date: string
     * }
     */
    public static function teamTodayKpis(int $userId, bool $viewAll): array
    {
        $day = self::localDayBounds();
        $scope = self::projectAccess($userId, $viewAll);

        $tracked = 0;
        if (self::tableExists('time_entries')) {
            $duration = self::entryColumn('duration_seconds', '0');
            $startCol = self::entryColumn('start_time');
            if ($startCol !== null) {
                $sql = "SELECT COALESCE(SUM({$duration}), 0)
                        FROM time_entries te
                        INNER JOIN projects p ON p.id = te.project_id
                        WHERE {$startCol} >= :start_utc AND {$startCol} <= :end_utc
                          AND {$scope['sql']}";
                $tracked = (int) Database::fetchValue($sql, array_merge($scope['params'], [
                    'start_utc' => $day['start_utc'],
                    'end_utc'   => $day['end_utc'],
                ]));
            }
        }

        $scheduled = 0.0;
        if (self::tableExists('schedules')) {
            $sql = "SELECT COALESCE(SUM(
                            GREATEST(0, TIMESTAMPDIFF(SECOND,
                                GREATEST(s.start_datetime, :start_a),
                                LEAST(s.end_datetime, :end_a)
                            ))
                        ), 0)
                    FROM schedules s
                    INNER JOIN projects p ON p.id = s.project_id
                    WHERE s.status <> 'Cancelled'
                      AND s.start_datetime < :end_b
                      AND s.end_datetime > :start_b
                      AND {$scope['sql']}";
            $seconds = (int) Database::fetchValue($sql, array_merge($scope['params'], [
                'start_a' => $day['start_utc'],
                'end_a'   => $day['end_utc'],
                'end_b'   => $day['end_utc'],
                'start_b' => $day['start_utc'],
            ]));
            $scheduled = $seconds / 3600;
        }

        $trackedHours = $tracked / 3600;
        $variance     = $trackedHours - $scheduled;

        return [
            'tracked_seconds'    => $tracked,
            'tracked_hours'      => round($trackedHours, 2),
            'scheduled_hours'    => round($scheduled, 2),
            'variance_hours'     => round($variance, 2),
            'variance_formatted' => self::formatVariance($variance),
            'active_projects'    => self::activeProjectCount($userId, $viewAll),
            'pending_approvals'  => self::pendingApprovalCount(),
            'local_date'         => $day['local_date'],
        ];
    }

    /**
     * Today's planned vs tracked hours per teammate.
     *
     * @return list<array<string, mixed>>
     */
    public static function teamWorkloadToday(int $userId, bool $viewAll): array
    {
        $day = self::localDayBounds();
        $people = [];

        if (self::tableExists('schedules') && class_exists('Schedule')) {
            $people = (new Schedule())->teamWorkload($day['start_utc'], $day['end_utc']);
        } else {
            $people = Database::fetchAll(
                "SELECT id AS user_id, name, email, role, job_title, 0 AS planned_seconds, 0 AS block_count
                 FROM users
                 WHERE status = 'active' AND role IN ('admin','manager','employee')
                 ORDER BY name ASC"
            );
        }

        $actual = [];
        if (self::tableExists('time_entries')) {
            $duration = self::entryColumn('duration_seconds', '0');
            $startCol = self::entryColumn('start_time');
            if ($startCol !== null) {
                $rows = Database::fetchAll(
                    "SELECT te.user_id, COALESCE(SUM({$duration}), 0) AS seconds
                     FROM time_entries te
                     WHERE {$startCol} >= :start_utc AND {$startCol} <= :end_utc
                     GROUP BY te.user_id",
                    [
                        'start_utc' => $day['start_utc'],
                        'end_utc'   => $day['end_utc'],
                    ]
                );
                foreach ($rows as $row) {
                    $actual[(int) $row['user_id']] = (int) $row['seconds'];
                }
            }
        }

        $out = [];
        foreach ($people as $row) {
            $uid      = (int) $row['user_id'];
            $plannedS = (int) ($row['planned_seconds'] ?? 0);
            $actualS  = $actual[$uid] ?? 0;
            $plannedH = $plannedS / 3600;
            $actualH  = $actualS / 3600;
            $capacity = max(8.0, $plannedH, $actualH);
            $variance = $actualH - $plannedH;

            $out[] = [
                'user_id'            => $uid,
                'name'               => (string) $row['name'],
                'role'               => (string) ($row['role'] ?? ''),
                'job_title'          => (string) ($row['job_title'] ?? ''),
                'planned_hours'      => round($plannedH, 2),
                'actual_hours'       => round($actualH, 2),
                'variance_formatted' => self::formatVariance($variance),
                'variance_hours'     => round($variance, 2),
                'planned_percent'    => self::percent($plannedH, $capacity),
                'actual_percent'     => self::percent($actualH, max($plannedH, 0.01)),
                'capacity_percent'   => self::percent($actualH, $capacity),
            ];
        }

        return $out;
    }

    /**
     * Estimated vs tracked vs variance for open projects the viewer can see.
     *
     * @return list<array<string, mixed>>
     */
    public static function projectHealthMatrix(int $userId, bool $viewAll, int $limit = 12): array
    {
        $scope = self::projectAccess($userId, $viewAll);
        $limit = max(1, min(50, $limit));

        $projects = Database::fetchAll(
            "SELECT p.id, p.name, p.project_code, p.status, p.priority,
                    p.estimated_hours, p.budget, p.hourly_rate, p.is_billable,
                    c.name AS client_name
             FROM projects p
             INNER JOIN clients c ON c.id = p.client_id
             WHERE p.status IN ('Planning','Active','On Hold')
               AND {$scope['sql']}
             ORDER BY FIELD(p.priority, 'Urgent','High','Medium','Low'), p.due_date IS NULL, p.due_date ASC, p.name ASC
             LIMIT {$limit}",
            $scope['params']
        );

        if ($projects === []) {
            return [];
        }

        $ids = array_map(static fn (array $row): int => (int) $row['id'], $projects);
        $tracked = self::trackedByProjectIds($ids);
        $taskEstimates = self::taskEstimatesByProjectIds($ids);

        $out = [];
        foreach ($projects as $project) {
            $id       = (int) $project['id'];
            $planned  = (float) $project['estimated_hours'];
            if ($planned <= 0 && isset($taskEstimates[$id])) {
                $planned = $taskEstimates[$id];
            }
            $actual   = $tracked[$id]['hours'] ?? 0.0;
            $spent    = $tracked[$id]['amount'] ?? 0.0;
            $budget   = (float) $project['budget'];
            $variance = $actual - $planned;
            $health   = self::healthStatus($actual, $planned, $spent, $budget);

            $out[] = [
                'id'                 => $id,
                'name'               => (string) $project['name'],
                'project_code'       => (string) $project['project_code'],
                'client_name'        => (string) $project['client_name'],
                'status'             => (string) $project['status'],
                'priority'           => (string) $project['priority'],
                'planned_hours'      => round($planned, 2),
                'actual_hours'       => round($actual, 2),
                'variance_hours'     => round($variance, 2),
                'variance_formatted' => self::formatVariance($variance),
                'billable_amount'    => round($spent, 2),
                'budget'             => round($budget, 2),
                'usage_percent'      => self::percent($actual, $planned),
                'budget_percent'     => self::percent($spent, $budget),
                'health'             => $health['label'],
                'health_class'       => $health['class'],
            ];
        }

        return $out;
    }

    /**
     * Employee "today" cards and supporting lists.
     *
     * @return array{
     *     tracked_seconds: int,
     *     tracked_hours: float,
     *     scheduled_hours: float,
     *     variance_hours: float,
     *     variance_formatted: string,
     *     active_tasks: list<array<string, mixed>>,
     *     active_task_count: int,
     *     schedule: list<array<string, mixed>>,
     *     entries: list<array<string, mixed>>,
     *     local_date: string
     * }
     */
    public static function employeeToday(int $userId): array
    {
        $day = self::localDayBounds();
        $summary = self::summarize([
            'user_id'        => $userId,
            'planned_source' => 'schedule',
            'start_utc'      => $day['start_utc'],
            'end_utc'        => $day['end_utc'],
        ]);

        $schedule = [];
        if (self::tableExists('schedules') && class_exists('Schedule')) {
            $schedule = (new Schedule())->inRange($day['start_utc'], $day['end_utc'], $userId, false, $userId);
        }

        $entries = [];
        if (class_exists('TimeEntry') && TimeEntry::installed()) {
            $result = (new TimeEntry())->listFiltered([
                'user_id' => $userId,
            ], 1, 8);
            $entries = $result['items'];
        }

        $tasks = self::activeTasksForUser($userId);

        return [
            'tracked_seconds'    => $summary['actual_seconds'],
            'tracked_hours'      => $summary['actual_hours'],
            'scheduled_hours'    => $summary['planned_hours'],
            'variance_hours'     => $summary['variance_hours'],
            'variance_formatted' => $summary['variance_formatted'],
            'active_tasks'       => $tasks,
            'active_task_count'  => count($tasks),
            'schedule'           => $schedule,
            'entries'            => $entries,
            'local_date'         => $day['local_date'],
        ];
    }

    /**
     * Full project dashboard payload: totals, task comparison, people, gantt.
     *
     * @return array{
     *     totals: array<string, mixed>,
     *     tasks: list<array<string, mixed>>,
     *     people: list<array<string, mixed>>,
     *     gantt: array{items: list<array<string, mixed>>, start: string, end: string}
     * }
     */
    public static function projectDashboard(int $projectId): array
    {
        $totals = self::summarize([
            'project_id'     => $projectId,
            'planned_source' => 'estimate',
        ]);

        return [
            'totals' => $totals,
            'tasks'  => self::taskComparison($projectId),
            'people' => self::timeByEmployee($projectId),
            'gantt'  => self::projectGantt($projectId),
        ];
    }

    /**
     * Schedule vs actual for every task in a project.
     *
     * @return list<array<string, mixed>>
     */
    public static function taskComparison(int $projectId): array
    {
        if (!self::tableExists('tasks')) {
            return [];
        }

        $tasks = Database::fetchAll(
            'SELECT t.id, t.name, t.status, t.estimated_hours, t.due_date, t.created_at
             FROM tasks t
             WHERE t.project_id = :id
             ORDER BY (t.status = \'Done\') ASC, t.name ASC',
            ['id' => $projectId]
        );

        $tracked = [];
        if (self::tableExists('time_entries') && TimeEntry::column('task_id') !== null) {
            $duration = self::entryColumn('duration_seconds', '0');
            $rateExpr = self::billableAmountExpr();
            $rows = Database::fetchAll(
                "SELECT te.task_id,
                        COALESCE(SUM({$duration}), 0) AS seconds,
                        COALESCE(SUM({$rateExpr}), 0) AS amount
                 FROM time_entries te
                 INNER JOIN projects p ON p.id = te.project_id
                 WHERE te.project_id = :id AND te.task_id IS NOT NULL
                 GROUP BY te.task_id",
                ['id' => $projectId]
            );
            foreach ($rows as $row) {
                $tracked[(int) $row['task_id']] = [
                    'seconds' => (int) $row['seconds'],
                    'amount'  => (float) $row['amount'],
                ];
            }
        }

        $scheduled = [];
        if (self::tableExists('schedules')) {
            $rows = Database::fetchAll(
                "SELECT task_id, COALESCE(SUM(estimated_hours), 0) AS hours
                 FROM schedules
                 WHERE project_id = :id AND task_id IS NOT NULL AND status <> 'Cancelled'
                 GROUP BY task_id",
                ['id' => $projectId]
            );
            foreach ($rows as $row) {
                $scheduled[(int) $row['task_id']] = (float) $row['hours'];
            }
        }

        $out = [];
        foreach ($tasks as $task) {
            $id       = (int) $task['id'];
            $estimate = (float) $task['estimated_hours'];
            $planned  = $estimate > 0 ? $estimate : ($scheduled[$id] ?? 0.0);
            $actualH  = (($tracked[$id]['seconds'] ?? 0) / 3600);
            $variance = $actualH - $planned;
            $health   = self::healthStatus($actualH, $planned);

            $out[] = [
                'id'                 => $id,
                'name'               => (string) $task['name'],
                'status'             => (string) $task['status'],
                'due_date'           => $task['due_date'],
                'planned_hours'      => round($planned, 2),
                'actual_hours'       => round($actualH, 2),
                'variance_hours'     => round($variance, 2),
                'variance_formatted' => self::formatVariance($variance),
                'billable_amount'    => round((float) ($tracked[$id]['amount'] ?? 0), 2),
                'usage_percent'      => self::percent($actualH, $planned),
                'health'             => $health['label'],
                'health_class'       => $health['class'],
            ];
        }

        return $out;
    }

    /**
     * Hours, rate, and billable totals grouped by person on a project.
     *
     * @return list<array<string, mixed>>
     */
    public static function timeByEmployee(int $projectId): array
    {
        if (!self::tableExists('time_entries')) {
            return [];
        }

        $duration = self::entryColumn('duration_seconds', '0');
        $rateExpr = self::billableAmountExpr();
        $rateCol  = TimeEntry::column('billable_rate');
        $avgRate  = $rateCol !== null
            ? "COALESCE(AVG(NULLIF(te.`{$rateCol}`, 0)), MAX(p.hourly_rate), 0)"
            : 'COALESCE(MAX(p.hourly_rate), 0)';

        return Database::fetchAll(
            "SELECT u.id AS user_id, u.name, u.role,
                    COALESCE(SUM({$duration}), 0) AS seconds,
                    {$avgRate} AS hourly_rate,
                    COALESCE(SUM({$rateExpr}), 0) AS billable_amount
             FROM time_entries te
             INNER JOIN users u ON u.id = te.user_id
             INNER JOIN projects p ON p.id = te.project_id
             WHERE te.project_id = :id
             GROUP BY u.id, u.name, u.role
             ORDER BY seconds DESC, u.name ASC",
            ['id' => $projectId]
        );
    }

    /**
     * Simple timeline bars for tasks (start, due, completion).
     *
     * @return array{items: list<array<string, mixed>>, start: string, end: string}
     */
    public static function projectGantt(int $projectId): array
    {
        $project = self::projectRow($projectId);
        $tasks   = self::tableExists('tasks')
            ? Database::fetchAll(
                'SELECT id, name, status, due_date, created_at, estimated_hours
                 FROM tasks WHERE project_id = :id ORDER BY due_date IS NULL, due_date ASC, name ASC',
                ['id' => $projectId]
            )
            : [];

        $dates = [];
        if ($project !== null) {
            if (!empty($project['start_date'])) {
                $dates[] = (string) $project['start_date'];
            }
            if (!empty($project['due_date'])) {
                $dates[] = (string) $project['due_date'];
            }
        }

        foreach ($tasks as $task) {
            $created = substr((string) $task['created_at'], 0, 10);
            if ($created !== '') {
                $dates[] = $created;
            }
            if (!empty($task['due_date'])) {
                $dates[] = (string) $task['due_date'];
            }
        }

        if ($dates === []) {
            $today = gmdate('Y-m-d');

            return ['items' => [], 'start' => $today, 'end' => $today];
        }

        sort($dates);
        $start = $dates[0];
        $end   = $dates[array_key_last($dates)];
        if ($start === $end) {
            $end = gmdate('Y-m-d', strtotime($end . ' +7 days') ?: time());
        }

        $span = max(1, (int) round((strtotime($end . ' UTC') - strtotime($start . ' UTC')) / 86400));

        $items = [];
        foreach ($tasks as $task) {
            $barStart = !empty($project['start_date']) ? (string) $project['start_date'] : substr((string) $task['created_at'], 0, 10);
            $created  = substr((string) $task['created_at'], 0, 10);
            if ($created !== '' && $created > $barStart) {
                $barStart = $created;
            }
            $barEnd = !empty($task['due_date']) ? (string) $task['due_date'] : $end;
            if ($barEnd < $barStart) {
                $barEnd = $barStart;
            }

            $offsetDays = max(0, (int) round((strtotime($barStart . ' UTC') - strtotime($start . ' UTC')) / 86400));
            $lengthDays = max(1, (int) round((strtotime($barEnd . ' UTC') - strtotime($barStart . ' UTC')) / 86400));

            $items[] = [
                'id'      => (int) $task['id'],
                'name'    => (string) $task['name'],
                'status'  => (string) $task['status'],
                'start'   => $barStart,
                'end'     => $barEnd,
                'left'    => round(($offsetDays / $span) * 100, 2),
                'width'   => round(min(100, ($lengthDays / $span) * 100), 2),
                'done'    => (string) $task['status'] === 'Done',
            ];
        }

        return [
            'items' => $items,
            'start' => $start,
            'end'   => $end,
        ];
    }

    public static function percent(float $part, float $whole): int
    {
        if ($whole <= 0) {
            return 0;
        }

        return (int) min(100, max(0, round(($part / $whole) * 100)));
    }

    /**
     * @param array<string, mixed> $filters
     * @param array{start_utc: string, end_utc: string}|null $range
     */
    private static function estimatedHours(array $filters, ?array $range = null): float
    {
        $taskId    = (int) ($filters['task_id'] ?? 0);
        $projectId = (int) ($filters['project_id'] ?? 0);
        $userId    = (int) ($filters['user_id'] ?? 0);

        if ($taskId > 0 && self::tableExists('tasks')) {
            return (float) Database::fetchValue(
                'SELECT estimated_hours FROM tasks WHERE id = :id LIMIT 1',
                ['id' => $taskId]
            );
        }

        if ($projectId > 0) {
            $fromTasks = 0.0;
            if (self::tableExists('tasks')) {
                $fromTasks = (float) Database::fetchValue(
                    'SELECT COALESCE(SUM(estimated_hours), 0) FROM tasks WHERE project_id = :id',
                    ['id' => $projectId]
                );
            }
            $fromProject = 0.0;
            $project = self::projectRow($projectId);
            if ($project !== null) {
                $fromProject = (float) $project['estimated_hours'];
            }

            return $fromProject > 0 ? $fromProject : $fromTasks;
        }

        if ($userId > 0 && self::tableExists('schedules')) {
            return self::scheduledHours($filters, $range);
        }

        return 0.0;
    }

    /**
     * @param array<string, mixed> $filters
     * @param array{start_utc: string, end_utc: string}|null $range
     */
    private static function scheduledHours(array $filters, ?array $range): float
    {
        if (!self::tableExists('schedules')) {
            return 0.0;
        }

        $where  = ["s.status <> 'Cancelled'"];
        $params = [];

        $projectId = (int) ($filters['project_id'] ?? 0);
        if ($projectId > 0) {
            $where[]              = 's.project_id = :project_id';
            $params['project_id'] = $projectId;
        }

        $taskId = (int) ($filters['task_id'] ?? 0);
        if ($taskId > 0) {
            $where[]           = 's.task_id = :task_id';
            $params['task_id'] = $taskId;
        }

        $userId = (int) ($filters['user_id'] ?? 0);
        if ($userId > 0) {
            $where[]           = 's.user_id = :user_id';
            $params['user_id'] = $userId;
        }

        if ($range !== null) {
            $where[] = 's.start_datetime < :end_utc AND s.end_datetime > :start_utc';
            $params['end_utc']   = $range['end_utc'];
            $params['start_utc'] = $range['start_utc'];
            $params['start_a']   = $range['start_utc'];
            $params['end_a']     = $range['end_utc'];

            $sql = 'SELECT COALESCE(SUM(GREATEST(0, TIMESTAMPDIFF(SECOND, GREATEST(s.start_datetime, :start_a), LEAST(s.end_datetime, :end_a)))), 0)
                    FROM schedules s WHERE ' . implode(' AND ', $where);

            return ((int) Database::fetchValue($sql, $params)) / 3600;
        }

        $sql = 'SELECT COALESCE(SUM(s.estimated_hours), 0) FROM schedules s WHERE ' . implode(' AND ', $where);

        return (float) Database::fetchValue($sql, $params);
    }

    /**
     * @param array<string, mixed> $filters
     * @param array{start_utc: string, end_utc: string}|null $range
     * @return array{seconds: int, hours: float, billable_hours: float, amount: float}
     */
    private static function trackedTotals(array $filters, ?array $range): array
    {
        $empty = ['seconds' => 0, 'hours' => 0.0, 'billable_hours' => 0.0, 'amount' => 0.0];
        if (!self::tableExists('time_entries')) {
            return $empty;
        }

        $duration = self::entryColumn('duration_seconds', '0');
        $startCol = self::entryColumn('start_time');
        $billable = TimeEntry::column('is_billable');
        $billableHours = $billable !== null
            ? "COALESCE(SUM(CASE WHEN te.`{$billable}` = 1 THEN {$duration} ELSE 0 END), 0)"
            : '0';
        $amountExpr = self::billableAmountExpr();

        $where  = ['1 = 1'];
        $params = [];

        $projectId = (int) ($filters['project_id'] ?? 0);
        if ($projectId > 0) {
            $where[]              = 'te.project_id = :project_id';
            $params['project_id'] = $projectId;
        }

        $taskId = (int) ($filters['task_id'] ?? 0);
        if ($taskId > 0) {
            $where[]           = 'te.task_id = :task_id';
            $params['task_id'] = $taskId;
        }

        $userId = (int) ($filters['user_id'] ?? 0);
        if ($userId > 0) {
            $where[]           = 'te.user_id = :user_id';
            $params['user_id'] = $userId;
        }

        if ($range !== null && $startCol !== null) {
            $where[]             = "{$startCol} >= :start_utc AND {$startCol} <= :end_utc";
            $params['start_utc'] = $range['start_utc'];
            $params['end_utc']   = $range['end_utc'];
        }

        $row = Database::fetchOne(
            "SELECT COALESCE(SUM({$duration}), 0) AS seconds,
                    {$billableHours} AS billable_seconds,
                    COALESCE(SUM({$amountExpr}), 0) AS amount
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             WHERE " . implode(' AND ', $where),
            $params
        );

        if ($row === null) {
            return $empty;
        }

        $seconds = (int) $row['seconds'];
        $billableSeconds = (int) ($row['billable_seconds'] ?? 0);

        return [
            'seconds'        => $seconds,
            'hours'          => $seconds / 3600,
            'billable_hours' => $billableSeconds / 3600,
            'amount'         => (float) $row['amount'],
        ];
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{start_utc: string, end_utc: string}|null
     */
    private static function resolveRange(array $filters): ?array
    {
        if (!empty($filters['start_utc']) && !empty($filters['end_utc'])) {
            return [
                'start_utc' => (string) $filters['start_utc'],
                'end_utc'   => (string) $filters['end_utc'],
            ];
        }

        $from = (string) ($filters['from'] ?? '');
        $to   = (string) ($filters['to'] ?? '');
        if ($from === '' && $to === '') {
            return null;
        }

        if ($from === '') {
            $from = $to;
        }
        if ($to === '') {
            $to = $from;
        }

        $start = FormatHelper::toUtc($from . ' 00:00:00');
        $end   = FormatHelper::toUtc($to . ' 23:59:59');
        if ($start === null || $end === null) {
            return null;
        }

        return ['start_utc' => $start, 'end_utc' => $end];
    }

    /** @return array<string, mixed>|null */
    private static function projectRow(int $projectId): ?array
    {
        if ($projectId < 1) {
            return null;
        }

        return Database::fetchOne('SELECT * FROM projects WHERE id = :id LIMIT 1', ['id' => $projectId]);
    }

    /**
     * @return array{sql: string, params: array<string, int>}
     */
    private static function projectAccess(int $userId, bool $viewAll): array
    {
        if ($viewAll) {
            return ['sql' => '1 = 1', 'params' => []];
        }

        return [
            'sql' => '(p.manager_id = :uid_manager OR p.created_by = :uid_creator OR EXISTS (
                SELECT 1 FROM project_members pm
                WHERE pm.project_id = p.id AND pm.user_id = :uid_member
            ))',
            'params' => [
                'uid_manager' => $userId,
                'uid_creator' => $userId,
                'uid_member'  => $userId,
            ],
        ];
    }

    private static function activeProjectCount(int $userId, bool $viewAll): int
    {
        $scope = self::projectAccess($userId, $viewAll);

        return (int) Database::fetchValue(
            "SELECT COUNT(*) FROM projects p
             WHERE p.status IN ('Planning','Active','On Hold') AND {$scope['sql']}",
            $scope['params']
        );
    }

    private static function pendingApprovalCount(): int
    {
        if (!self::tableExists('timesheets') || !PermissionHelper::has('time.approve')) {
            return 0;
        }

        try {
            return (int) Database::fetchValue(
                "SELECT COUNT(*) FROM timesheets WHERE status = 'Submitted'"
            );
        } catch (Throwable) {
            return 0;
        }
    }

    /**
     * @param list<int> $projectIds
     * @return array<int, array{hours: float, amount: float}>
     */
    private static function trackedByProjectIds(array $projectIds): array
    {
        if ($projectIds === [] || !self::tableExists('time_entries')) {
            return [];
        }

        $placeholders = [];
        $params = [];
        foreach ($projectIds as $i => $id) {
            $key = 'p' . $i;
            $placeholders[] = ':' . $key;
            $params[$key] = $id;
        }

        $duration = self::entryColumn('duration_seconds', '0');
        $amountExpr = self::billableAmountExpr();
        $rows = Database::fetchAll(
            'SELECT te.project_id,
                    COALESCE(SUM(' . $duration . '), 0) AS seconds,
                    COALESCE(SUM(' . $amountExpr . '), 0) AS amount
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             WHERE te.project_id IN (' . implode(',', $placeholders) . ')
             GROUP BY te.project_id',
            $params
        );

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['project_id']] = [
                'hours'  => ((int) $row['seconds']) / 3600,
                'amount' => (float) $row['amount'],
            ];
        }

        return $out;
    }

    /**
     * @param list<int> $projectIds
     * @return array<int, float>
     */
    private static function taskEstimatesByProjectIds(array $projectIds): array
    {
        if ($projectIds === [] || !self::tableExists('tasks')) {
            return [];
        }

        $placeholders = [];
        $params = [];
        foreach ($projectIds as $i => $id) {
            $key = 'p' . $i;
            $placeholders[] = ':' . $key;
            $params[$key] = $id;
        }

        $rows = Database::fetchAll(
            'SELECT project_id, COALESCE(SUM(estimated_hours), 0) AS hours
             FROM tasks
             WHERE project_id IN (' . implode(',', $placeholders) . ')
             GROUP BY project_id',
            $params
        );

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['project_id']] = (float) $row['hours'];
        }

        return $out;
    }

    /** @return list<array<string, mixed>> */
    private static function activeTasksForUser(int $userId): array
    {
        if (!self::tableExists('tasks')) {
            return [];
        }

        $rows = Database::fetchAll(
            "SELECT DISTINCT t.id, t.name, t.status, t.estimated_hours, t.due_date,
                    p.id AS project_id, p.name AS project_name, p.is_billable
             FROM tasks t
             INNER JOIN projects p ON p.id = t.project_id
             WHERE t.status <> 'Done'
               AND p.status IN ('Planning','Active','On Hold')
               AND (
                    EXISTS (
                        SELECT 1 FROM task_assignees ta
                        WHERE ta.task_id = t.id AND ta.user_id = :uid_a
                    )
                    OR (
                        NOT EXISTS (SELECT 1 FROM task_assignees ta WHERE ta.task_id = t.id)
                        AND EXISTS (
                            SELECT 1 FROM project_members pm
                            WHERE pm.project_id = t.project_id AND pm.user_id = :uid_m
                        )
                    )
               )
             ORDER BY t.due_date IS NULL, t.due_date ASC, t.name ASC
             LIMIT 12",
            ['uid_a' => $userId, 'uid_m' => $userId]
        );

        // Defensive de-duplication in case legacy assignment data contains duplicate rows.
        $seen = [];
        $unique = [];
        foreach ($rows as $row) {
            $id = (int) ($row['id'] ?? 0);
            if ($id < 1 || isset($seen[$id])) {
                continue;
            }
            $seen[$id] = true;
            $unique[] = $row;
        }

        return $unique;
    }

    private static function billableAmountExpr(): string
    {
        $duration = self::entryColumn('duration_seconds', '0');
        $billable = TimeEntry::column('is_billable');
        $rateCol  = TimeEntry::column('billable_rate');
        $rate     = $rateCol !== null
            ? "COALESCE(NULLIF(te.`{$rateCol}`, 0), p.hourly_rate, 0)"
            : 'COALESCE(p.hourly_rate, 0)';

        $amount = "(({$duration}) / 3600.0) * ({$rate})";
        if ($billable !== null) {
            return "CASE WHEN te.`{$billable}` = 1 THEN {$amount} ELSE 0 END";
        }

        return $amount;
    }

    private static function entryColumn(string $logical, ?string $fallbackSql = null): ?string
    {
        if (class_exists('TimeEntry')) {
            $physical = TimeEntry::column($logical);
            if ($physical !== null) {
                return "te.`{$physical}`";
            }
        }

        return $fallbackSql;
    }

    private static function tableExists(string $table): bool
    {
        static $cache = [];

        if (!preg_match('/^[a-z_][a-z0-9_]*$/', $table)) {
            return false;
        }

        if (!array_key_exists($table, $cache)) {
            try {
                $cache[$table] = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = :name",
                    ['name' => $table]
                ) > 0;
            } catch (Throwable) {
                $cache[$table] = false;
            }
        }

        return $cache[$table];
    }
}
