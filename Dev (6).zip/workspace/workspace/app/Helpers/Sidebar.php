<?php
/**
 * Sidebar navigation and badge queries.
 *
 * Feature flags hide items here; controllers still 403/404 the same URLs.
 * Badge queries are scoped and logged on failure so a missing table cannot
 * break the layout or leak a global pending count.
 */

declare(strict_types=1);

final class SidebarHelper
{
    /**
     * @return array<string, list<array<string, mixed>>>
     */
    public static function groups(): array
    {
        return [
            'TRACK' => [
                ['label' => 'Dashboard', 'icon' => 'fa-gauge-high', 'path' => '/dashboard', 'permission' => 'dashboard.view'],
                ['label' => 'Time Tracker', 'icon' => 'fa-clock', 'path' => '/time', 'permission' => 'time.view_own', 'controller' => 'TimerController', 'flag' => 'tracker'],
                ['label' => 'Timesheet', 'icon' => 'fa-file-lines', 'path' => '/timesheets', 'permission' => 'time.view_own', 'controller' => 'TimesheetController', 'flag' => 'timesheet'],
                ['label' => 'Calendar', 'icon' => 'fa-calendar-days', 'path' => '/schedule/my', 'permission' => 'schedule.view', 'controller' => 'ScheduleController', 'flag' => 'scheduling'],
            ],
            'MANAGE' => [
                ['label' => 'Approvals', 'icon' => 'fa-circle-check', 'path' => '/timesheets/team', 'permission' => 'time.approve', 'controller' => 'TimesheetController', 'flag' => 'approval', 'badge' => true],
                ['label' => 'Projects', 'icon' => 'fa-diagram-project', 'path' => '/projects', 'permission' => 'projects.view', 'controller' => 'ProjectController', 'flag' => 'projects'],
                ['label' => 'Team', 'icon' => 'fa-users', 'path' => '/projects', 'permission' => 'projects.view', 'controller' => 'ProjectController', 'flag' => 'team'],
                ['label' => 'Clients', 'icon' => 'fa-building', 'path' => '/clients', 'permission' => 'clients.view', 'controller' => 'ClientController'],
                ['label' => 'Schedule', 'icon' => 'fa-calendar-week', 'path' => '/schedule', 'permission' => 'schedule.view', 'controller' => 'ScheduleController', 'flag' => 'scheduling'],
            ],
            'SYSTEM' => [
                ['label' => 'Users', 'icon' => 'fa-user-gear', 'path' => '/users', 'permission' => 'users.view', 'controller' => 'UserController'],
                ['label' => 'Activity log', 'icon' => 'fa-clipboard-list', 'path' => '/settings/audit-logs', 'permission' => 'activity.view', 'controller' => 'SettingsController'],
                ['label' => 'System settings', 'icon' => 'fa-sliders', 'path' => '/settings', 'permission' => 'settings.manage', 'controller' => 'SettingsController'],
            ],
        ];
    }

    /** @param array<string, mixed> $item */
    public static function visible(array $item): bool
    {
        if (isset($item['controller']) && !is_file(APP_PATH . '/Controllers/' . $item['controller'] . '.php')) {
            return false;
        }

        if (!PermissionHelper::has((string) $item['permission'])) {
            return false;
        }

        return match ((string) ($item['flag'] ?? '')) {
            'tracker' => FeatureFlagsHelper::trackerVisible(),
            'timesheet' => FeatureFlagsHelper::timesheetEnabled(),
            'scheduling' => FeatureFlagsHelper::schedulingEnabled(),
            'approval' => FeatureFlagsHelper::timeApprovalEnabled(),
            'projects' => FeatureFlagsHelper::projectsVisible(),
            'team' => FeatureFlagsHelper::teamVisible(),
            'reports' => FeatureFlagsHelper::reportsVisible(),
            default => true,
        };
    }

    public static function unreadCount(): int
    {
        try {
            if (!class_exists('Notification') || !Notification::installed()) {
                return 0;
            }

            return (new Notification())->unreadCount((int) AuthHelper::id());
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return 0;
        }
    }

    /** @return list<array<string, mixed>> */
    public static function recentNotifications(int $limit = 6): array
    {
        try {
            if (!class_exists('Notification') || !Notification::installed()) {
                return [];
            }

            return (new Notification())->recent((int) AuthHelper::id(), $limit);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return [];
        }
    }

    public static function pendingApprovalCount(): int
    {
        if (!FeatureFlagsHelper::timeApprovalEnabled() || !PermissionHelper::has('time.approve')) {
            return 0;
        }

        try {
            if (!class_exists('Timesheet') || !Timesheet::installed()) {
                return 0;
            }

            $userId = (int) AuthHelper::id();
            $isAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);

            return (int) ((new Timesheet())->queueCounts($userId, $isAdmin)['Submitted'] ?? 0);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);

            return 0;
        }
    }
}
