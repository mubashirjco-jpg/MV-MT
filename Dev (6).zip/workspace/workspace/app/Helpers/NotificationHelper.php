<?php
/**
 * Notification engine (Phase 9).
 *
 * Central place that turns a business event into one or more notifications. All
 * writes respect the `notifications_enabled` system setting and never throw, so a
 * failure to notify cannot roll back the action that triggered it.
 *
 *   NotificationHelper::taskAssigned($userId, $taskName, $taskId, $projectId, $projectName);
 */

declare(strict_types=1);

final class NotificationHelper
{
    private static ?bool $enabledCache = null;

    /** True when in-app notifications are switched on in system settings. */
    public static function enabled(): bool
    {
        if (self::$enabledCache !== null) {
            return self::$enabledCache;
        }

        try {
            self::$enabledCache = SettingsService::systemBool('notifications_enabled', true);
        } catch (Throwable) {
            self::$enabledCache = true;
        }

        return self::$enabledCache;
    }

    /** Low-level send. Silently ignored when notifications are disabled or the user is unknown. */
    public static function push(int $userId, string $type, string $title, string $message, string $link = ''): void
    {
        if ($userId < 1 || !self::enabled()) {
            return;
        }

        try {
            (new Notification())->createFor($userId, $type, $title, $message, $link);
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
        }
    }

    /* ---------------------------------------------------------- triggers */

    public static function taskAssigned(int $assigneeId, string $taskName, int $taskId, int $projectId, string $projectName = ''): void
    {
        $where = $projectName !== '' ? ' on ' . $projectName : '';
        self::push(
            $assigneeId,
            Notification::TYPE_INFO,
            'New task assigned',
            'You were assigned "' . $taskName . '"' . $where . '.',
            '/projects/' . $projectId . '?tab=tasks'
        );
    }

    public static function scheduleChanged(int $userId, string $projectName, string $startLocal, string $link = '/schedule/my'): void
    {
        self::push(
            $userId,
            Notification::TYPE_INFO,
            'Schedule changed',
            'Your planned work for ' . ($projectName !== '' ? $projectName : 'a project') . ' moved to ' . $startLocal . '.',
            $link
        );
    }

    /** @param list<array<string, mixed>> $conflicts */
    public static function scheduleConflict(int $userId, array $conflicts, string $link = '/schedule/my'): void
    {
        $count = count($conflicts);

        self::push(
            $userId,
            Notification::TYPE_WARNING,
            'Schedule conflict',
            $count === 1
                ? 'A new block overlaps an existing planned block.'
                : $count . ' new blocks overlap existing planned work.',
            $link
        );
    }

    public static function timesheetApproved(int $userId, string $period, int $timesheetId): void
    {
        self::push(
            $userId,
            Notification::TYPE_SUCCESS,
            'Timesheet approved',
            'Your timesheet for ' . $period . ' was approved.',
            '/timesheets/' . $timesheetId
        );
    }

    public static function timesheetRejected(int $userId, string $period, int $timesheetId, string $reason): void
    {
        self::push(
            $userId,
            Notification::TYPE_WARNING,
            'Timesheet needs changes',
            'Your timesheet for ' . $period . ' was rejected. ' . $reason,
            '/timesheets/' . $timesheetId
        );
    }

    /**
     * Remind a user about a planned block that starts within $withinHours.
     * Call from a cron/task scheduler; safe to call repeatedly because a matching
     * unread "approaching" notification is not created twice within the window.
     */
    public static function scheduleApproaching(int $userId, string $projectName, string $startLocal, int $blockId, int $withinHours = 2): void
    {
        if (!self::enabled() || $userId < 1) {
            return;
        }

        try {
            $existing = (int) Database::fetchValue(
                "SELECT COUNT(*) FROM notifications
                 WHERE user_id = :user_id AND title = 'Upcoming scheduled work'
                   AND created_at > DATE_SUB(UTC_TIMESTAMP(), INTERVAL :hours HOUR)",
                ['user_id' => $userId, 'hours' => max(1, $withinHours)]
            );
        } catch (Throwable) {
            return;
        }

        if ($existing > 0) {
            return;
        }

        self::push(
            $userId,
            Notification::TYPE_INFO,
            'Upcoming scheduled work',
            'You have planned work on ' . ($projectName !== '' ? $projectName : 'a project') . ' starting at ' . $startLocal . '.',
            '/schedule/my#block-' . $blockId
        );
    }
}
