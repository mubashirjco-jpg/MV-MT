<?php
/**
 * Data for the Clockify-style weekly team dashboard (workspace week start, viewer timezone).
 *
 * Returns: per-day totals stacked by project, per-project totals, top project/client,
 * and a "team activities" list (latest entry, running timer, week total per person).
 *
 * SECURITY: every value is bound as a parameter; column names come only from
 * TimeEntry::column() (a whitelist built from the live table), never from the request.
 * The only request value used here is the week date, which is validated as Y-m-d.
 * Project visibility follows the same rule as the rest of the app (view_all, or
 * manager / creator / member of the project).
 */

declare(strict_types=1);

final class WeekDashboardHelper
{
    /** Clockify-like palette, assigned to projects by rank (largest first). */
    private const PALETTE = [
        '#8d6e63', '#039be5', '#689f38', '#009688', '#f9a825',
        '#ab47bc', '#ef5350', '#5c6bc0', '#26a69a', '#ff7043',
    ];

    /**
     * @return array<string, mixed>
     */
    public static function build(int $userId, bool $viewAll, ?string $weekDate = null, bool $onlyMe = false): array
    {
        $tz  = new DateTimeZone(FormatHelper::displayTimezone());
        $utc = new DateTimeZone('UTC');

        $weekMod = WorkspacePolicy::weekModifier();
        $anchor = null;
        if ($weekDate !== null && preg_match('/^\d{4}-\d{2}-\d{2}$/', $weekDate) === 1) {
            $anchor = DateTimeImmutable::createFromFormat('!Y-m-d', $weekDate, $tz) ?: null;
        }
        $anchor ??= new DateTimeImmutable('today', $tz);
        $weekStart = $anchor->modify($weekMod)->setTime(0, 0, 0);
        $weekEnd   = $weekStart->modify('+7 days');

        $startUtc = $weekStart->setTimezone($utc)->format('Y-m-d H:i:s');
        $endUtc   = $weekEnd->setTimezone($utc)->format('Y-m-d H:i:s');

        $days = [];
        for ($i = 0; $i < 7; $i++) {
            $d = $weekStart->modify("+{$i} days");
            $days[$i] = [
                'date'     => $d->format('Y-m-d'),
                'label'    => $d->format('D, M j'),
                'seconds'  => 0,
                'projects' => [],
            ];
        }

        $result = [
            'week_start'  => $weekStart->format('Y-m-d'),
            'week_end'    => $weekEnd->modify('-1 day')->format('Y-m-d'),
            'prev_week'   => $weekStart->modify('-7 days')->format('Y-m-d'),
            'next_week'   => $weekStart->modify('+7 days')->format('Y-m-d'),
            'is_current'  => (new DateTimeImmutable('today', $tz))->modify($weekMod)->format('Y-m-d') === $weekStart->format('Y-m-d'),
            'range_label' => $weekStart->format('M j') . ' - ' . $weekEnd->modify('-1 day')->format('M j, Y'),
            'only_me'     => $onlyMe,
            'total'       => 0,
            'days'        => $days,
            'projects'    => [],
            'top_project' => null,
            'top_client'  => null,
            'people'      => [],
            'ready'       => false,
        ];

        $startCol = self::column('start_time');
        $durCol   = self::column('duration_seconds');
        if ($startCol === null || $durCol === null || !self::tableExists('time_entries')) {
            return $result;
        }
        $result['ready'] = true;

        // Project visibility (alias p) shared by every query below.
        if ($viewAll) {
            $scopeSql = '1 = 1';
            $scopeParams = [];
        } else {
            $scopeSql = '(p.manager_id = :sc_manager OR p.created_by = :sc_creator OR EXISTS (
                SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :sc_member
            ))';
            $scopeParams = ['sc_manager' => $userId, 'sc_creator' => $userId, 'sc_member' => $userId];
        }

        $meSql = $onlyMe ? ' AND te.user_id = :only_me' : '';
        $meParams = $onlyMe ? ['only_me' => $userId] : [];

        // 1) Every entry of the week; bucketed into local days in PHP so no tz tables are needed.
        $rows = Database::fetchAll(
            "SELECT te.user_id, te.project_id, te.`{$startCol}` AS started, te.`{$durCol}` AS seconds
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             WHERE te.`{$startCol}` >= :s AND te.`{$startCol}` < :e AND {$scopeSql}{$meSql}",
            array_merge($scopeParams, $meParams, ['s' => $startUtc, 'e' => $endUtc])
        );

        $byProject = [];
        $byUser    = [];
        $total     = 0;

        foreach ($rows as $row) {
            $seconds = (int) $row['seconds'];
            $pid     = (int) $row['project_id'];
            $uid     = (int) $row['user_id'];

            try {
                $local = (new DateTimeImmutable((string) $row['started'], $utc))->setTimezone($tz);
            } catch (Exception) {
                continue;
            }
            $dayIndex = (int) $weekStart->diff($local->setTime(0, 0, 0))->format('%r%a');
            if ($dayIndex < 0 || $dayIndex > 6) {
                continue;
            }

            $days[$dayIndex]['seconds'] += $seconds;
            $days[$dayIndex]['projects'][$pid] = ($days[$dayIndex]['projects'][$pid] ?? 0) + $seconds;
            $byProject[$pid] = ($byProject[$pid] ?? 0) + $seconds;
            $byUser[$uid][$pid] = ($byUser[$uid][$pid] ?? 0) + $seconds;
            $total += $seconds;
        }

        // 2) Project names + clients, ranked by tracked time, colours by rank.
        arsort($byProject, SORT_NUMERIC);
        $projects = [];
        $colors   = [];
        if ($byProject !== []) {
            $ids = array_keys($byProject);
            $ph  = [];
            $pp  = [];
            foreach ($ids as $i => $id) {
                $ph[] = ':p' . $i;
                $pp['p' . $i] = $id;
            }
            $meta = [];
            foreach (Database::fetchAll(
                'SELECT p.id, p.name, c.name AS client_name
                 FROM projects p LEFT JOIN clients c ON c.id = p.client_id
                 WHERE p.id IN (' . implode(',', $ph) . ')',
                $pp
            ) as $m) {
                $meta[(int) $m['id']] = $m;
            }

            $rank = 0;
            foreach ($byProject as $pid => $seconds) {
                $color = self::PALETTE[$rank % count(self::PALETTE)];
                $colors[$pid] = $color;
                $projects[] = [
                    'id'      => $pid,
                    'name'    => (string) ($meta[$pid]['name'] ?? 'Project #' . $pid),
                    'client'  => (string) ($meta[$pid]['client_name'] ?? ''),
                    'seconds' => $seconds,
                    'percent' => $total > 0 ? round($seconds / $total * 100, 2) : 0.0,
                    'color'   => $color,
                ];
                $rank++;
            }
        }

        // 3) Top project / top client.
        $clientTotals = [];
        foreach ($projects as $p) {
            $name = $p['client'] !== '' ? $p['client'] : 'No client';
            $clientTotals[$name] = ($clientTotals[$name] ?? 0) + $p['seconds'];
        }
        arsort($clientTotals, SORT_NUMERIC);

        // 4) Team activities: latest entry + running timer + week total per person.
        $people = self::people($userId, $onlyMe, $viewAll, $scopeSql, $scopeParams, $startCol, $durCol, $byUser, $colors, $tz, $utc);

        $result['days']        = $days;
        $result['total']       = $total;
        $result['projects']    = $projects;
        $result['top_project'] = $projects[0] ?? null;
        $result['top_client']  = $clientTotals === [] ? null : [
            'name'    => (string) array_key_first($clientTotals),
            'seconds' => (int) reset($clientTotals),
        ];
        $result['people']      = $people;

        return $result;
    }

    /**
     * @param array<int, array<int, int>> $byUser user => project => seconds
     * @param array<int, string> $colors project => colour
     * @return list<array<string, mixed>>
     */
    private static function people(
        int $userId,
        bool $onlyMe,
        bool $viewAll,
        string $scopeSql,
        array $scopeParams,
        string $startCol,
        string $durCol,
        array $byUser,
        array $colors,
        DateTimeZone $tz,
        DateTimeZone $utc
    ): array {
        $userSql = "SELECT id, name FROM users WHERE status = 'active' AND role IN ('admin','manager','employee')";
        $userParams = [];
        if ($onlyMe) {
            $userSql .= ' AND id = :me';
            $userParams['me'] = $userId;
        }
        $users = Database::fetchAll($userSql . ' ORDER BY name ASC', $userParams);

        // Latest entry per user (any week). Duplicate start times are collapsed in PHP.
        $latest = [];
        $latestRows = Database::fetchAll(
            "SELECT te.user_id, te.description, te.`{$startCol}` AS started, te.`{$durCol}` AS seconds,
                    p.name AS project_name, t.name AS task_name
             FROM time_entries te
             INNER JOIN projects p ON p.id = te.project_id
             LEFT JOIN tasks t ON t.id = te.task_id
             INNER JOIN (
                 SELECT user_id, MAX(`{$startCol}`) AS mx FROM time_entries GROUP BY user_id
             ) m ON m.user_id = te.user_id AND m.mx = te.`{$startCol}`
             WHERE {$scopeSql}",
            $scopeParams
        );
        foreach ($latestRows as $r) {
            $latest[(int) $r['user_id']] ??= $r;
        }

        // Running timers.
        $running = [];
        if (self::tableExists('active_timers')) {
            foreach (Database::fetchAll(
                'SELECT a.user_id, a.started_at, a.description, p.name AS project_name, t.name AS task_name
                 FROM active_timers a
                 INNER JOIN projects p ON p.id = a.project_id
                 LEFT JOIN tasks t ON t.id = a.task_id
                 WHERE ' . $scopeSql,
                $scopeParams
            ) as $r) {
                $running[(int) $r['user_id']] = $r;
            }
        }

        $now = new DateTimeImmutable('now', $utc);
        $out = [];

        foreach ($users as $u) {
            $uid  = (int) $u['id'];
            $segs = $byUser[$uid] ?? [];
            arsort($segs, SORT_NUMERIC);
            $weekTotal = array_sum($segs);

            $activity = null;
            if (isset($running[$uid])) {
                $r = $running[$uid];
                $startedAt = new DateTimeImmutable((string) $r['started_at'], $utc);
                $activity = [
                    'description' => (string) ($r['description'] ?? ''),
                    'project'     => (string) $r['project_name'],
                    'task'        => (string) ($r['task_name'] ?? ''),
                    'seconds'     => max(0, $now->getTimestamp() - $startedAt->getTimestamp()),
                    'ago'         => 'In progress',
                    'running'     => true,
                ];
            } elseif (isset($latest[$uid])) {
                $r = $latest[$uid];
                $activity = [
                    'description' => (string) ($r['description'] ?? ''),
                    'project'     => (string) $r['project_name'],
                    'task'        => (string) ($r['task_name'] ?? ''),
                    'seconds'     => (int) $r['seconds'],
                    'ago'         => self::ago(new DateTimeImmutable((string) $r['started'], $utc), $now),
                    'running'     => false,
                ];
            }

            $firstProject = array_key_first($segs);
            $out[] = [
                'user_id'  => $uid,
                'name'     => (string) $u['name'],
                'initials' => self::initials((string) $u['name']),
                'color'    => $firstProject !== null ? ($colors[$firstProject] ?? self::PALETTE[$uid % count(self::PALETTE)]) : self::PALETTE[$uid % count(self::PALETTE)],
                'activity' => $activity,
                'total'    => $weekTotal,
                'segments' => array_map(
                    static fn (int $pid, int $sec): array => ['seconds' => $sec, 'color' => $colors[$pid] ?? '#b0bec5'],
                    array_keys($segs),
                    array_values($segs)
                ),
            ];
        }

        // Running first, then most recent activity, then name.
        usort($out, static function (array $a, array $b): int {
            $ra = (int) ($a['activity']['running'] ?? 0);
            $rb = (int) ($b['activity']['running'] ?? 0);
            if ($ra !== $rb) {
                return $rb <=> $ra;
            }
            $ha = $a['activity'] !== null ? 1 : 0;
            $hb = $b['activity'] !== null ? 1 : 0;
            if ($ha !== $hb) {
                return $hb <=> $ha;
            }

            return $b['total'] <=> $a['total'] ?: strcasecmp($a['name'], $b['name']);
        });

        return $out;
    }

    private static function ago(DateTimeImmutable $then, DateTimeImmutable $now): string
    {
        $diff = max(0, $now->getTimestamp() - $then->getTimestamp());

        return match (true) {
            $diff < 90         => 'just now',
            $diff < 3600       => intdiv($diff, 60) . ' minutes ago',
            $diff < 5400       => 'an hour ago',
            $diff < 86400      => intdiv($diff, 3600) . ' hours ago',
            $diff < 172800     => 'yesterday',
            default            => intdiv($diff, 86400) . ' days ago',
        };
    }

    private static function initials(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        $first = mb_strtoupper(mb_substr((string) ($parts[0] ?? '?'), 0, 1, 'UTF-8'), 'UTF-8');
        $last  = count($parts) > 1 ? mb_strtoupper(mb_substr((string) end($parts), 0, 1, 'UTF-8'), 'UTF-8') : '';

        return $first . $last;
    }

    /** Physical time_entries column for a logical field (null when the live table lacks it). */
    private static function column(string $logical): ?string
    {
        if (!class_exists('TimeEntry')) {
            return null;
        }

        try {
            return TimeEntry::column($logical);
        } catch (Throwable) {
            return null;
        }
    }

    private static function tableExists(string $table): bool
    {
        static $cache = [];

        if (!preg_match('/^[a-z_][a-z0-9_]*$/', $table)) {
            return false;
        }
        if (!array_key_exists($table, $cache)) {
            try {
                $cache[$table] = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :name',
                    ['name' => $table]
                ) > 0;
            } catch (Throwable) {
                $cache[$table] = false;
            }
        }

        return $cache[$table];
    }
}