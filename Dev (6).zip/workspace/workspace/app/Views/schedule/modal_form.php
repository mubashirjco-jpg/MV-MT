<?php
/**
 * Create / edit planned-work modal plus conflict override dialog.
 *
 * @var list<array<string, mixed>> $projects
 * @var list<array<string, mixed>> $people
 * @var list<string>               $statuses
 * @var bool                       $canCreate
 * @var bool                       $canAssign
 * @var int                        $defaultUser
 * @var bool                       $hasTasks
 */

$canCreate  = $canCreate ?? false;
$canEdit    = $canEdit ?? false;
$canAssign  = $canAssign ?? false;
$defaultUser = (int) ($defaultUser ?? 0);
$hasTasks   = $hasTasks ?? false;
$statuses   = $statuses ?? ['Scheduled'];
$projects   = $projects ?? [];
$people     = $people ?? [];
$weekdays   = [1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat', 7 => 'Sun'];
?>
<div class="modal fade" id="scheduleModal" tabindex="-1" aria-labelledby="scheduleModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <form method="post" action="<?= e(url('/schedule')) ?>" id="scheduleForm" class="modal-content" novalidate>
            <?= csrf_field() ?>
            <input type="hidden" name="override_conflict" id="scheduleOverride" value="0">
            <input type="hidden" name="id" id="scheduleId" value="">
            <div class="modal-header">
                <h2 class="modal-title h5" id="scheduleModalTitle">Plan work</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="schedule_project_id" class="form-label">Project</label>
                        <select id="schedule_project_id" name="project_id" required class="form-select">
                            <option value="">Select a project</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= (int) $project['id'] ?>"><?= e($project['name']) ?> · <?= e($project['project_code']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6"<?= $hasTasks ? '' : ' hidden' ?>>
                        <label for="schedule_task_id" class="form-label">Task</label>
                        <select id="schedule_task_id" name="task_id" class="form-select" <?= $hasTasks ? '' : 'disabled' ?>>
                            <option value="">No task</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="schedule_user_id" class="form-label">Person</label>
                        <select id="schedule_user_id" name="user_id" required class="form-select" data-default-user="<?= $defaultUser ?>">
                            <?php if (!$canAssign): ?>
                                <option value="<?= $defaultUser ?>">Me</option>
                            <?php else: ?>
                                <option value="">Select a person</option>
                                <?php foreach ($people as $person): ?>
                                    <option value="<?= (int) $person['id'] ?>"><?= e($person['name']) ?></option>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="schedule_status" class="form-label">Status</label>
                        <select id="schedule_status" name="status" required class="form-select">
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?= e($status) ?>"<?= $status === 'Scheduled' ? ' selected' : '' ?>><?= e($status) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="schedule_start" class="form-label">Start</label>
                        <input type="datetime-local" id="schedule_start" name="start_datetime" required class="form-control">
                    </div>
                    <div class="col-md-6">
                        <label for="schedule_end" class="form-label">End</label>
                        <input type="datetime-local" id="schedule_end" name="end_datetime" required class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="schedule_hours" class="form-label">Estimated hours</label>
                        <input type="number" id="schedule_hours" name="estimated_hours" min="0" max="24" step="0.25" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="schedule_recurrence" class="form-label">Repeat</label>
                        <select id="schedule_recurrence" name="recurrence_type" class="form-select">
                            <option value="none">Does not repeat</option>
                            <option value="daily">Daily</option>
                            <option value="weekdays">Weekdays</option>
                            <option value="weekly">Weekly</option>
                            <option value="custom">Custom days</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="schedule_until" class="form-label">Repeat until</label>
                        <input type="date" id="schedule_until" name="repeat_until" class="form-control">
                    </div>
                    <div class="col-12" id="scheduleDaysWrap" hidden>
                        <span class="form-label d-block">Days of week</span>
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($weekdays as $n => $label): ?>
                                <label class="form-check form-check-inline">
                                    <input class="form-check-input" type="checkbox" name="days_of_week[]" value="<?= $n ?>">
                                    <span class="form-check-label"><?= e($label) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="col-12">
                        <label for="schedule_notes" class="form-label">Notes</label>
                        <textarea id="schedule_notes" name="notes" rows="2" maxlength="2000" class="form-control"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-outline-danger" id="scheduleDeleteBtn" hidden>Cancel block</button>
                <div class="d-flex gap-2 ms-auto">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
                    <?php if ($canCreate || $canEdit): ?>
                        <button type="submit" class="btn btn-primary" id="scheduleSubmit">Save</button>
                    <?php endif; ?>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="conflictModal" tabindex="-1" aria-labelledby="conflictModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title h5" id="conflictModalTitle">Schedule conflict</h2>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p class="mb-3">This overlaps existing planned work.</p>
                <ul class="conflict-list" id="conflictList"></ul>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Keep existing</button>
                <button type="button" class="btn btn-primary" id="conflictOverrideBtn">Save anyway</button>
            </div>
        </div>
    </div>
</div>
