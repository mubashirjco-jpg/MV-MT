<?php
/**
 * Create project.
 *
 * @var array<string, mixed> $project
 * @var string               $formAction
 * @var string               $submitLabel
 */
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">New project</h2>
        <p class="page-lead">Set the client, schedule, budget and team.</p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= e(url('/projects')) ?>">Back to projects</a>
</div>
<?php require APP_PATH . '/Views/projects/form.php'; ?>
