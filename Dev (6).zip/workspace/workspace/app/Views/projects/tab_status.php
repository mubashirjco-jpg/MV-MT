<?php
/**
 * STATUS tab: tracked card, donut chart, tasks table with tracked time.
 *
 * @var array<string, mixed> $project
 * @var list<array<string, mixed>> $statusRows
 * @var int $trackedSeconds
 * @var array<string, mixed> $totals
 * @var string $statusFilter all|active|done
 * @var string $statusSort   name|tracked
 * @var string $statusDir    asc|desc
 * @var string $currency
 */

$projectId = (int) $project['id'];
$base      = url('/projects/' . $projectId);
$hours     = $trackedSeconds / 3600;
$fmtH      = static fn (float $h): string => number_format($h, 2, '.', '');

$type = (string) ($project['estimate_type'] ?? '');
if ($type === '') {
    $type = (float) $project['estimated_hours'] > 0 ? 'time' : ((float) $project['budget'] > 0 ? 'budget' : 'none');
}

// Cards + donut proportions
$cards = [['Tracked', $fmtH($hours) . ' h']];
$ratio = null;   // 0..1 of the estimate that is used
$over  = false;

if ($type === 'time' && (float) $project['estimated_hours'] > 0) {
    $estimate  = (float) $project['estimated_hours'];
    $remaining = $estimate - $hours;
    $ratio     = $hours / $estimate;
    $over      = $hours > $estimate;
    $cards[]   = ['Estimate', $fmtH($estimate) . ' h'];
    $cards[]   = [$over ? 'Over estimate' : 'Remaining', $fmtH(abs($remaining)) . ' h'];
} elseif ($type === 'budget' && (float) $project['budget'] > 0) {
    $budget    = (float) $project['budget'];
    $used      = (float) $totals['budget_used'];
    $ratio     = $used / $budget;
    $over      = $used > $budget;
    $cards[]   = ['Budget', FormatHelper::money($budget, $currency)];
    $cards[]   = ['Amount used', FormatHelper::money($used, $currency)];
    $cards[]   = [$over ? 'Over budget' : 'Remaining', FormatHelper::money(abs($budget - $used), $currency)];
}

$circ  = 2 * M_PI * 75;
$green = $ratio === null ? $circ : min(1.0, max(0.0, $ratio)) * $circ;

$filterLabels = ['all' => 'Show all', 'active' => 'Show active', 'done' => 'Show done'];
$sortLink = static function (string $sort) use ($base, $statusFilter, $statusSort, $statusDir): string {
    $dir = ($statusSort === $sort && $statusDir === 'asc') ? 'desc' : 'asc';

    return $base . '?' . http_build_query(['tab' => 'status', 'task_status' => $statusFilter, 's' => $sort, 'd' => $dir]);
};
$sortIcon = static function (string $sort) use ($statusSort, $statusDir): string {
    if ($statusSort !== $sort) {
        return 'fa-sort';
    }

    return $statusDir === 'desc' ? 'fa-sort-down' : 'fa-sort-up';
};
?>
<div class="cf-status-top">
    <div class="cf-stat-col">
        <?php foreach ($cards as [$label, $value]): ?>
            <div class="cf-stat">
                <span class="cf-stat-label"><?= e($label) ?></span>
                <span class="cf-stat-value"><?= e($value) ?></span>
            </div>
        <?php endforeach; ?>
    </div>

    <div class="cf-card cf-donut-card">
        <div class="cf-donut">
            <svg viewBox="0 0 200 200" role="img" aria-label="Tracked <?= e($fmtH($hours)) ?> hours">
                <?php if ($ratio !== null): ?>
                    <circle cx="100" cy="100" r="75" fill="none" stroke="#e3e9ed" stroke-width="50"></circle>
                <?php endif; ?>
                <circle cx="100" cy="100" r="75" fill="none" stroke="<?= $over ? '#f26b5e' : '#8bc34a' ?>" stroke-width="50"
                        stroke-dasharray="<?= e(number_format($green, 3, '.', '')) ?> <?= e(number_format($circ, 3, '.', '')) ?>"
                        transform="rotate(-90 100 100)"></circle>
                <?php if ($ratio === null || $ratio >= 1): ?>
                    <line x1="100" y1="0" x2="100" y2="50" stroke="#fff" stroke-width="1.4"></line>
                <?php endif; ?>
            </svg>
            <span class="cf-donut-value"><?= e($fmtH($hours)) ?> h</span>
        </div>
        <ul class="cf-legend">
            <li><i style="background:#8bc34a"></i>Tracked</li>
            <?php if ($ratio !== null): ?>
                <li><i style="background:<?= $over ? '#f26b5e' : '#e3e9ed' ?>"></i><?= $over ? 'Over' : 'Remaining' ?></li>
            <?php endif; ?>
        </ul>
    </div>
</div>

<section class="cf-card cf-status-list">
    <div class="cf-band">
        <span>Tasks</span>
        <div class="dropdown">
            <button type="button" class="cf-band-select" data-bs-toggle="dropdown" aria-expanded="false">
                <?= e($filterLabels[$statusFilter]) ?> <i class="fa-solid fa-caret-down" aria-hidden="true"></i>
            </button>
            <ul class="dropdown-menu dropdown-menu-end cf-menu">
                <?php foreach ($filterLabels as $key => $text): ?>
                    <li>
                        <a class="dropdown-item<?= $key === $statusFilter ? ' active' : '' ?>"
                           href="<?= e($base . '?' . http_build_query(['tab' => 'status', 'task_status' => $key, 's' => $statusSort, 'd' => $statusDir])) ?>"><?= e($text) ?></a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>

    <?php if ($statusRows === []): ?>
        <div class="cf-empty">This project has no tasks to show.</div>
    <?php else: ?>
        <div class="cf-table-wrap">
            <table class="cf-table cf-status-table">
                <thead>
                    <tr>
                        <th class="cf-col-name"><a class="cf-sort" href="<?= e($sortLink('name')) ?>">Name <i class="fa-solid <?= e($sortIcon('name')) ?>" aria-hidden="true"></i></a></th>
                        <th class="cf-col-assignees">Assignees</th>
                        <th class="cf-col-tracked"><a class="cf-sort" href="<?= e($sortLink('tracked')) ?>">Tracked <i class="fa-solid <?= e($sortIcon('tracked')) ?>" aria-hidden="true"></i></a></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($statusRows as $row): ?>
                        <?php $names = array_map(static fn (array $a): string => (string) $a['name'], $row['assignees']); ?>
                        <tr>
                            <td class="cf-col-name" data-label="Name"><?= e($row['name']) ?></td>
                            <td class="cf-col-assignees" data-label="Assignees"><?= e($names === [] ? 'Anyone' : implode(', ', $names)) ?></td>
                            <td class="cf-col-tracked" data-label="Tracked"><?= e($fmtH(((int) $row['tracked_seconds']) / 3600)) ?>h</td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>
