<?php
/**
 * FORECAST tab: Day / Week / Month switch, date range with previous / next, planned-hours chart.
 * The chart itself is drawn by assets/js/project.js (Chart.js) from data-forecast.
 *
 * @var array<string, mixed> $project
 * @var array<string, mixed> $forecast
 */

$base = url('/projects/' . (int) $project['id']);
$link = static fn (string $g, string $from, string $to): string => $base . '?' . http_build_query(['tab' => 'forecast', 'g' => $g, 'from' => $from, 'to' => $to]);
$gran = (string) $forecast['gran'];
?>
<section class="cf-card cf-forecast">
    <div class="cf-forecast-bar">
        <div class="cf-seg" role="group" aria-label="Group by">
            <?php foreach (['day' => 'Day', 'week' => 'Week', 'month' => 'Month'] as $key => $text): ?>
                <a class="cf-seg-item<?= $gran === $key ? ' is-active' : '' ?>"
                   href="<?= e($link($key, (string) $forecast['from'], (string) $forecast['to'])) ?>"><?= e($text) ?></a>
            <?php endforeach; ?>
        </div>

        <div class="cf-range dropdown">
            <button type="button" class="cf-range-main" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false">
                <i class="fa-regular fa-calendar" aria-hidden="true"></i>
                <span><?= e((string) $forecast['rangeText']) ?></span>
            </button>
            <form method="get" action="<?= e($base) ?>" class="dropdown-menu dropdown-menu-end cf-range-menu">
                <input type="hidden" name="tab" value="forecast">
                <input type="hidden" name="g" value="<?= e($gran) ?>">
                <label class="cf-label" for="fc-from">From</label>
                <input type="date" id="fc-from" name="from" class="cf-input" value="<?= e((string) $forecast['from']) ?>" required>
                <label class="cf-label mt-2" for="fc-to">To</label>
                <input type="date" id="fc-to" name="to" class="cf-input" value="<?= e((string) $forecast['to']) ?>" required>
                <button type="submit" class="cf-btn cf-btn-primary mt-3 w-100">Apply</button>
            </form>
            <a class="cf-range-nav" href="<?= e($link($gran, (string) $forecast['prevFrom'], (string) $forecast['prevTo'])) ?>" aria-label="Previous period">
                <i class="fa-solid fa-chevron-left" aria-hidden="true"></i>
            </a>
            <a class="cf-range-nav" href="<?= e($link($gran, (string) $forecast['nextFrom'], (string) $forecast['nextTo'])) ?>" aria-label="Next period">
                <i class="fa-solid fa-chevron-right" aria-hidden="true"></i>
            </a>
        </div>
    </div>

    <div class="cf-forecast-chart">
        <canvas id="cf-forecast-canvas"
                data-forecast="<?= e(json_encode($forecast['chart'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT)) ?>"
                role="img" aria-label="Planned hours for this project"></canvas>
    </div>
</section>
