-- TimeTrack: live dump u897128490_timetrack.sql (2026-10-03) with schema synced to database/install.sql
-- Applied: database/phase17_sync_live_schema.sql. No data rows changed except:
--   +3 permissions (reports.view/export/billing) and +8 role_permissions rows.
-- Columns removed: tasks.assigned_to, activity_logs.record_id. Column added: time_entries.auto_stopped.
-- tasks.status keeps the live enum (To Do/In Progress/On Hold/Review/Completed/Cancelled).
-- Import into an EMPTY database (no DROP TABLE statements, same as the original export).


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `active_timers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `started_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `paused_at` datetime DEFAULT NULL,
  `accumulated_seconds` int(10) unsigned NOT NULL DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_active_timers_user` (`user_id`),
  KEY `idx_active_timers_project` (`project_id`),
  KEY `idx_active_timers_task` (`task_id`),
  CONSTRAINT `fk_active_timers_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_active_timers_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_active_timers_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `active_timers` DISABLE KEYS */;
INSERT INTO `active_timers` VALUES
(24,4,1,1,'2026-10-03 06:43:35','2026-10-03 06:45:48',NULL,0,NULL,1,'2026-10-03 06:43:35');
/*!40000 ALTER TABLE `active_timers` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `module` varchar(60) DEFAULT NULL,
  `entity_type` varchar(60) DEFAULT NULL,
  `entity_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `old_value` longtext DEFAULT NULL,
  `new_value` longtext DEFAULT NULL,
  `meta` longtext DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_activity_user` (`user_id`),
  KEY `idx_activity_action` (`action`),
  KEY `idx_activity_entity` (`entity_type`,`entity_id`),
  KEY `idx_activity_created` (`created_at`),
  CONSTRAINT `fk_activity_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES
(1,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 08:57:37'),
(2,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 09:52:54'),
(3,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 10:00:33'),
(4,1,'client.created',NULL,'client',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"AFIC\"}','2026-10-01 10:02:37'),
(5,1,'project.created',NULL,'project',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"AFIC\",\"code\":\"PRJ-0001\"}','2026-10-01 10:03:19'),
(6,1,'auth.logout',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 10:03:58'),
(7,3,'auth.login',NULL,'user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 10:04:44'),
(8,3,'auth.logout',NULL,'user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 10:05:22'),
(9,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 10:05:28'),
(10,1,'schedule.created',NULL,'schedule',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":2,\"project_id\":1,\"overridden\":false}','2026-10-01 10:31:09'),
(11,1,'client.created',NULL,'client',2,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"AFIC-NIHD\"}','2026-10-01 10:48:34'),
(12,1,'task.created',NULL,'task',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"name\":\"CON - Building Envelope\"}','2026-10-01 10:49:55'),
(13,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 11:20:32'),
(14,1,'timer.started',NULL,'timer',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":null}','2026-10-01 11:22:40'),
(15,1,'timer.stopped',NULL,'time_entry',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":1665}','2026-10-01 11:50:25'),
(16,1,'timer.started',NULL,'timer',2,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-01 11:50:37'),
(17,1,'timer.stopped',NULL,'time_entry',2,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":17}','2026-10-01 11:50:54'),
(18,1,'timer.started',NULL,'timer',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-01 11:51:20'),
(19,1,'timer.stopped',NULL,'time_entry',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":356}','2026-10-01 11:57:16'),
(20,1,'timer.started',NULL,'timer',4,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-01 11:57:27'),
(21,1,'timer.stopped',NULL,'time_entry',4,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":232}','2026-10-01 12:01:19'),
(22,1,'timer.started',NULL,'timer',5,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":null}','2026-10-01 12:01:21'),
(23,1,'timer.stopped',NULL,'time_entry',5,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":10}','2026-10-01 12:01:31'),
(24,1,'auth.logout',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 12:04:38'),
(25,3,'auth.login',NULL,'user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 12:04:45'),
(26,3,'auth.logout',NULL,'user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 12:06:24'),
(27,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 12:06:30'),
(28,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 12:41:28'),
(29,1,'timesheet.submitted',NULL,'timesheet',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"start_date\":\"2026-09-28\",\"end_date\":\"2026-10-04\",\"total_seconds\":2280,\"billable_seconds\":2280}','2026-10-01 12:57:26'),
(30,1,'auth.logout',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 12:58:06'),
(31,3,'auth.login',NULL,'user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 12:58:09'),
(32,3,'timer.started',NULL,'timer',6,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-01 12:58:17'),
(33,3,'timer.stopped',NULL,'time_entry',6,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":31}','2026-10-01 12:58:48'),
(34,3,'timesheet.submitted',NULL,'timesheet',2,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"start_date\":\"2026-09-28\",\"end_date\":\"2026-10-04\",\"total_seconds\":31,\"billable_seconds\":31}','2026-10-01 12:58:58'),
(35,3,'auth.logout',NULL,'user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 13:00:02'),
(36,1,'auth.login',NULL,'user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 13:00:09'),
(37,1,'auth.login',NULL,'user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 14:02:21'),
(38,1,'auth.login',NULL,'user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 14:45:05'),
(39,1,'timesheet.approved',NULL,'timesheet',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":3,\"start_date\":\"2026-09-28\",\"total_seconds\":31,\"billable_seconds\":31}','2026-10-01 15:10:48'),
(40,1,'timer.started',NULL,'timer',7,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":null}','2026-10-01 15:24:38'),
(41,1,'timer.paused',NULL,'timer',7,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 15:24:43'),
(42,1,'timer.resumed',NULL,'timer',7,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 15:24:53'),
(43,1,'timer.stopped',NULL,'time_entry',7,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":696}','2026-10-01 15:36:14'),
(44,1,'client.updated',NULL,'client',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"AFIC\"}','2026-10-01 16:14:31'),
(45,1,'client.deleted',NULL,'client',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"AFIC-NIHD\"}','2026-10-01 16:14:38'),
(46,1,'client.created',NULL,'client',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Shifa Eye Hospital\"}','2026-10-01 16:15:42'),
(47,1,'project.created',NULL,'project',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"CON - Building Envelope\",\"code\":\"PRJ-0002\"}','2026-10-01 16:17:21'),
(48,1,'project.updated',NULL,'project',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Al Shifa Trust Eye Hospital\"}','2026-10-01 16:18:55'),
(49,1,'task.created',NULL,'task',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"name\":\"CON - Building Envelope\"}','2026-10-01 16:27:07'),
(50,1,'timer.started',NULL,'timer',8,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-01 16:27:35'),
(51,1,'timer.stopped',NULL,'time_entry',8,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":54}','2026-10-01 16:28:29'),
(52,1,'timer.started',NULL,'timer',9,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-01 16:46:16'),
(53,1,'timer.stopped',NULL,'time_entry',9,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":393}','2026-10-01 16:52:49'),
(54,1,'auth.logout',NULL,'user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 16:55:27'),
(55,3,'auth.login',NULL,'user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 16:55:33'),
(56,3,'timer.started',NULL,'timer',10,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-01 16:55:59'),
(57,3,'auth.logout',NULL,'user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 16:56:43'),
(58,1,'auth.login',NULL,'user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 16:56:49'),
(59,1,'client.created',NULL,'client',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Al Shifa Trust\"}','2026-10-01 17:10:25'),
(60,1,'client.deleted',NULL,'client',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Al Shifa Trust\"}','2026-10-01 17:10:33'),
(61,1,'auth.login',NULL,'user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 18:10:33'),
(62,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 19:05:01'),
(63,1,'task.created','task','task',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"name\":\"Test\"}','2026-10-01 19:31:40'),
(64,1,'task.updated','task','task',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Test\",\"assignees\":1}','2026-10-01 19:31:55'),
(65,1,'task.updated','task','task',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Test\",\"assignees\":2}','2026-10-01 19:31:56'),
(66,1,'task.assigned','task','task',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,'{\"task\":\"Test\",\"assignee\":3,\"project_id\":2}',NULL,'2026-10-01 19:31:56'),
(67,1,'project.visibility_changed','project','project',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"public\":1}','2026-10-01 19:32:36'),
(68,1,'project.visibility_changed','project','project',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"public\":0}','2026-10-01 19:32:39'),
(69,1,'timer.started','timer','timer',11,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":3}','2026-10-01 19:48:00'),
(70,1,'client.updated','client','client',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"AFIC\"}','2026-10-01 19:58:22'),
(71,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 19:59:04'),
(72,3,'auth.login','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 19:59:08'),
(73,3,'timer.stopped','time_entry','time_entry',10,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":10993}','2026-10-01 19:59:12'),
(74,3,'timer.started','timer','timer',12,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":3}','2026-10-01 19:59:47'),
(75,3,'auth.logout','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 20:01:00'),
(76,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-01 20:02:24'),
(77,1,'user.created','user','user',5,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,'{\"name\":\"Ahmer\",\"email\":\"ahmer@gmail.com\",\"role\":\"admin\",\"status\":\"active\"}',NULL,'2026-10-01 20:06:47'),
(78,1,'auth.login','user','user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 05:17:08'),
(79,1,'timer.stopped','time_entry','time_entry',11,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":34151}','2026-10-02 05:17:11'),
(80,1,'auth.login','user','user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 07:06:53'),
(81,1,'auth.login','user','user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 08:12:51'),
(82,1,'task.status_changed','task','task',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"from\":\"To Do\",\"to\":\"Completed\"}','2026-10-02 08:13:51'),
(83,1,'task.status_changed','task','task',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"from\":\"Completed\",\"to\":\"Completed\"}','2026-10-02 08:17:31'),
(84,1,'task.status_changed','task','task',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"from\":\"Completed\",\"to\":\"To Do\"}','2026-10-02 08:22:22'),
(85,1,'user.deleted','user','user',5,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','{\"name\":\"Ahmer\",\"email\":\"ahmer@gmail.com\"}',NULL,NULL,'2026-10-02 08:28:46'),
(86,1,'task.status_changed','task','task',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"from\":\"To Do\",\"to\":\"Completed\"}','2026-10-02 08:31:56'),
(87,1,'task.updated','task','task',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Test 1\"}','2026-10-02 08:32:11'),
(88,1,'task.updated','task','task',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Test\"}','2026-10-02 08:32:15'),
(89,1,'client.updated','client','client',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Al Shifa\"}','2026-10-02 08:35:22'),
(90,1,'client.updated','client','client',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"AFIC-NIHD\"}','2026-10-02 08:36:11'),
(91,1,'client.updated','client','client',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Al Shifa Trust\"}','2026-10-02 08:36:27'),
(92,1,'settings.updated','settings','settings',NULL,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','{\"company_name\":\"Your Company\",\"currency\":\"USD\",\"currency_symbol\":\"$\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"working_hours_per_day\":\"8\"}','{\"company_name\":\"Your Company\",\"currency_symbol\":\"$\",\"currency\":\"USD\",\"default_hourly_rate\":\"0\",\"working_hours_per_day\":\"9\",\"default_timezone\":\"UTC\"}',NULL,'2026-10-02 08:38:09'),
(93,1,'settings.updated','settings','settings',NULL,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','{\"company_name\":\"Your Company\",\"currency\":\"USD\",\"currency_symbol\":\"$\",\"default_hourly_rate\":\"0\",\"default_timezone\":\"UTC\",\"working_hours_per_day\":\"9\"}','{\"company_name\":\"Maven Projects LLP\",\"currency_symbol\":\"$\",\"currency\":\"USD\",\"default_hourly_rate\":\"0\",\"working_hours_per_day\":\"9\",\"default_timezone\":\"UTC\"}',NULL,'2026-10-02 08:52:09'),
(94,1,'project.updated','project','project',2,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36','{\"name\":\"Al Shifa Trust Eye Hospital\",\"status\":\"Active\"}','{\"name\":\"Al Shifa Trust Eye Hospital\",\"status\":\"Active\"}',NULL,'2026-10-02 09:10:48'),
(95,1,'auth.login','user','user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 09:49:38'),
(96,1,'timer.started','timer','timer',13,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 10:07:43'),
(97,1,'timer.stopped','time_entry','time_entry',12,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":6}','2026-10-02 10:07:49'),
(98,1,'timer.started','timer','timer',14,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 10:07:52'),
(99,1,'timer.stopped','time_entry','time_entry',13,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":15}','2026-10-02 10:08:07'),
(100,1,'time_entry.deleted','time_entry','time_entry',12,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1}','2026-10-02 10:11:28'),
(101,1,'auth.logout','user','user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 10:38:10'),
(102,3,'auth.login','user','user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 10:38:14'),
(103,3,'timer.stopped','time_entry','time_entry',14,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":52721}','2026-10-02 10:38:28'),
(104,3,'time_entry.created','time_entry','time_entry',15,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":3600}','2026-10-02 10:44:04'),
(105,3,'timer.started','timer','timer',15,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 10:48:32'),
(106,3,'timer.stopped','time_entry','time_entry',16,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":9}','2026-10-02 10:48:41'),
(107,3,'timer.started','timer','timer',16,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 10:49:00'),
(108,3,'timer.stopped','time_entry','time_entry',17,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":5}','2026-10-02 10:49:05'),
(109,3,'timer.started','timer','timer',17,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 10:52:01'),
(110,3,'timer.stopped','time_entry','time_entry',18,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":4}','2026-10-02 10:52:05'),
(111,3,'auth.login','user','user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 11:26:49'),
(112,3,'auth.login','user','user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 11:39:34'),
(113,3,'auth.logout','user','user',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 11:43:00'),
(114,1,'auth.login','user','user',1,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 11:43:06'),
(115,1,'timesheet.entries_submitted','timesheet','timesheet',3,'103.87.194.250','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"entry_count\":3,\"total_seconds\":1104}','2026-10-02 11:53:58'),
(116,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 14:27:35'),
(117,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 14:46:14'),
(118,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 15:59:35'),
(119,1,'timer.started','timer','timer',18,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-02 15:59:52'),
(120,1,'timer.stopped','time_entry','time_entry',19,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":47}','2026-10-02 16:00:39'),
(121,1,'timer.started','timer','timer',19,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 16:02:06'),
(122,1,'timer.stopped','time_entry','time_entry',20,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":60}','2026-10-02 16:03:06'),
(123,1,'timer.started','timer','timer',20,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 16:23:33'),
(124,1,'timer.stopped','time_entry','time_entry',21,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":154}','2026-10-02 16:26:07'),
(125,1,'schedule.created','schedule','schedule',17,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":1,\"project_id\":2,\"overridden\":false}','2026-10-02 16:34:05'),
(126,1,'timer.started','timer','timer',21,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-02 16:34:52'),
(127,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 16:36:24'),
(128,3,'auth.login','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 16:36:32'),
(129,3,'timer.started','timer','timer',22,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-02 16:37:03'),
(130,3,'auth.logout','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 16:37:18'),
(131,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 16:37:23'),
(132,1,'timer.paused','timer','timer',21,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 16:42:39'),
(133,1,'timer.resumed','timer','timer',21,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-02 16:42:40'),
(134,1,'timer.stopped','time_entry','time_entry',22,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":901}','2026-10-02 16:49:53'),
(135,1,'timesheet.entries_submitted','timesheet','timesheet',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"entry_count\":1,\"total_seconds\":47}','2026-10-02 16:50:07'),
(136,1,'timesheet.entries_submitted','timesheet','timesheet',5,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"entry_count\":1,\"total_seconds\":54}','2026-10-02 16:50:23'),
(137,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 05:10:41'),
(138,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:04:16'),
(139,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:23:48'),
(140,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:41:45'),
(141,3,'auth.login','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:41:59'),
(142,3,'timer.started','timer','timer',23,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-03 06:42:49'),
(143,3,'timer.stopped','time_entry','time_entry',24,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":1}','2026-10-03 06:42:50'),
(144,3,'auth.logout','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:43:03'),
(145,4,'auth.login','user','user',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:43:11'),
(146,4,'timer.started','timer','timer',24,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-03 06:43:35'),
(147,4,'auth.logout','user','user',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:46:00'),
(148,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 06:53:11'),
(149,1,'task.created','task','task',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"name\":\"CON - Furniture\"}','2026-10-03 07:07:33'),
(150,1,'client.created','client','client',5,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"name\":\"Nova Care\"}','2026-10-03 07:09:18'),
(151,1,'project.created','project','project',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,'{\"name\":\"Citadel 7 Novacare Hospital\",\"code\":\"PRJ-0003\"}',NULL,'2026-10-03 07:10:31'),
(152,1,'project.created','project','project',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,'{\"name\":\"Novacare Hospital\",\"code\":\"PRJ-0004\"}',NULL,'2026-10-03 07:11:26'),
(153,1,'timer.started','timer','timer',25,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":3,\"task_id\":null}','2026-10-03 07:12:06'),
(154,1,'timer.stopped','time_entry','time_entry',25,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":3,\"duration_seconds\":4}','2026-10-03 07:12:10'),
(155,1,'timer.started','timer','timer',26,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":4,\"task_id\":null}','2026-10-03 07:12:19'),
(156,1,'timer.stopped','time_entry','time_entry',26,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":4,\"duration_seconds\":5}','2026-10-03 07:12:24'),
(157,1,'timer.started','timer','timer',27,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-03 07:13:25'),
(158,1,'schedule.created','schedule','schedule',18,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":4,\"project_id\":2,\"overridden\":false}','2026-10-03 07:26:21'),
(159,1,'schedule.created','schedule','schedule',19,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":4,\"project_id\":2,\"overridden\":true}','2026-10-03 07:27:33'),
(160,1,'schedule.conflict_overridden','schedule','schedule',19,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,'{\"conflicts\":[{\"id\":18,\"start\":\"2026-10-03 07:00:00\",\"end\":\"2026-10-04 03:30:00\"}]}',NULL,'2026-10-03 07:27:33'),
(161,1,'timer.stopped','time_entry','time_entry',27,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":1580}','2026-10-03 07:39:45'),
(162,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:27:13'),
(163,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:28:46'),
(164,2,'auth.login','user','user',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:28:56'),
(165,2,'timesheet.approved','timesheet','timesheet',5,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":1,\"start_date\":\"2026-09-28\",\"total_seconds\":54,\"billable_seconds\":54}','2026-10-03 10:29:21'),
(166,2,'timesheet.rejected','timesheet','timesheet',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":1,\"start_date\":\"2026-10-01\",\"reason\":\"Need changes\"}','2026-10-03 10:29:35'),
(167,2,'timesheet.approved','timesheet','timesheet',4,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"user_id\":1,\"start_date\":\"2026-09-28\",\"total_seconds\":47,\"billable_seconds\":47}','2026-10-03 10:29:43'),
(168,2,'auth.logout','user','user',2,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:30:32'),
(169,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:30:39'),
(170,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:47:10'),
(171,1,'timer.started','timer','timer',28,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-03 10:49:22'),
(172,1,'timer.paused','timer','timer',28,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:49:40'),
(173,1,'timer.resumed','timer','timer',28,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 10:49:42'),
(174,1,'timer.stopped','time_entry','time_entry',28,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":27}','2026-10-03 10:49:49'),
(175,1,'timesheet.entries_submitted','timesheet','timesheet',6,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"entry_count\":2,\"total_seconds\":1607}','2026-10-03 10:50:13'),
(176,1,'import.completed','import','import',NULL,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"type\":\"users\",\"rows\":10,\"created\":10,\"updated\":0,\"skipped\":0}','2026-10-03 11:16:17'),
(177,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 12:46:41'),
(178,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 12:46:46'),
(179,1,'auth.logout','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 13:09:41'),
(180,3,'auth.login','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 13:09:46'),
(181,3,'auth.logout','user','user',3,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 13:36:10'),
(182,1,'auth.login','user','user',1,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 13:36:17'),
(183,1,'timer.started','timer','timer',29,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-03 13:37:18'),
(184,1,'timer.stopped','time_entry','time_entry',29,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":711}','2026-10-03 14:02:09'),
(185,1,'timer.started','timer','timer',30,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":1}','2026-10-03 14:03:18'),
(186,1,'timer.stopped','time_entry','time_entry',30,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":102}','2026-10-03 14:05:00'),
(187,1,'timer.started','timer','timer',31,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-03 14:08:13'),
(188,1,'timer.stopped','time_entry','time_entry',31,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":394}','2026-10-03 14:14:47'),
(189,1,'timer.started','timer','timer',32,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"task_id\":2}','2026-10-03 14:15:06'),
(190,1,'timer.stopped','time_entry','time_entry',32,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":2,\"duration_seconds\":2058}','2026-10-03 14:49:24'),
(191,1,'timer.started','timer','timer',33,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"task_id\":4}','2026-10-03 14:49:30'),
(192,1,'timer.stopped','time_entry','time_entry',33,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":1,\"duration_seconds\":1242}','2026-10-03 15:10:12'),
(193,1,'timer.started','timer','timer',34,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":3,\"task_id\":null}','2026-10-03 15:11:03'),
(194,1,'timer.stopped','time_entry','time_entry',34,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":3,\"duration_seconds\":158}','2026-10-03 15:20:41'),
(195,1,'timer.started','timer','timer',35,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":4,\"task_id\":null}','2026-10-03 15:20:52'),
(196,1,'timer.stopped','time_entry','time_entry',35,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":4,\"duration_seconds\":143}','2026-10-03 15:23:15'),
(197,1,'timer.started','timer','timer',36,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":4,\"task_id\":null}','2026-10-03 15:23:27'),
(198,1,'timer.resumed','timer','timer',36,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 15:27:29'),
(199,1,'timer.resumed','timer','timer',36,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,NULL,'2026-10-03 15:32:35'),
(200,1,'timer.stopped','time_entry','time_entry',36,'58.65.217.235','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/154.0.0.0 Safari/537.36',NULL,NULL,'{\"project_id\":4,\"duration_seconds\":372}','2026-10-03 15:32:39');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `email` varchar(190) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `company` varchar(160) DEFAULT NULL,
  `address` varchar(500) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_clients_name` (`name`),
  KEY `idx_clients_email` (`email`),
  KEY `idx_clients_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `clients` DISABLE KEYS */;
INSERT INTO `clients` VALUES
(1,'AFIC-NIHD','test@gmail.com','354564548','AFIC','RWP','active','2026-10-01 10:02:37','2026-10-02 08:36:11'),
(3,'Al Shifa Trust','test1@gmail.com','152132026','Al Shifa','RWP','active','2026-10-01 16:15:42','2026-10-02 08:36:27'),
(5,'Nova Care','test2@gmail.com','546452165','Nova Care','ISB','active','2026-10-03 07:09:18','2026-10-03 07:09:18');
/*!40000 ALTER TABLE `clients` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `desktop_agent_devices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `device_id` varchar(120) NOT NULL,
  `device_name` varchar(160) NOT NULL DEFAULT 'Windows PC',
  `token_hash` char(64) NOT NULL,
  `last_seen_at` datetime NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `agent_version` varchar(40) NOT NULL DEFAULT 'unknown',
  `status` enum('active','revoked') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_desktop_agent_token` (`token_hash`),
  UNIQUE KEY `uq_desktop_agent_user_device` (`user_id`,`device_id`),
  KEY `idx_desktop_agent_user_status` (`user_id`,`status`),
  KEY `idx_desktop_agent_seen` (`last_seen_at`),
  KEY `fk_desktop_agent_workspace` (`workspace_id`),
  CONSTRAINT `fk_desktop_agent_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_desktop_agent_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `desktop_agent_devices` DISABLE KEYS */;
INSERT INTO `desktop_agent_devices` VALUES
(3,1,1,'fe8a171fac224769a03ba906d024d00b','MUBASHIR','c8b5b254303ea2f959e65a941b057ac27fc27bcb821180721e2a92fb9e4e8ed6','2026-10-03 15:43:54','2026-10-03 15:43:53',0,'1.0.0','active','2026-10-03 15:10:41','2026-10-03 15:43:54');
/*!40000 ALTER TABLE `desktop_agent_devices` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `desktop_agent_pairing_codes` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `workspace_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `code_hash` char(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used_at` datetime DEFAULT NULL,
  `attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_agent_pair_expiry` (`expires_at`,`used_at`),
  KEY `idx_agent_pair_user` (`user_id`,`created_at`),
  KEY `fk_agent_pair_workspace` (`workspace_id`),
  CONSTRAINT `fk_agent_pair_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_agent_pair_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `desktop_agent_pairing_codes` DISABLE KEYS */;
INSERT INTO `desktop_agent_pairing_codes` VALUES
(4,1,1,'476c07697633043a9ed3ed5a506c5cea2e65a864a68672003a69ee5bea68ba08','2026-10-03 13:06:23','2026-10-03 12:56:30',0,'2026-10-03 12:56:23'),
(5,1,1,'7f5fe5dd48b6117a8d564107d1dbc36f847095fdf4c3d7e7ae343b43eda768a2','2026-10-03 13:46:40','2026-10-03 13:36:54',0,'2026-10-03 13:36:40'),
(6,1,1,'77de3d4a247897c62919cd84b1182814da5cac847b95e51e1f66faf358ee54f7','2026-10-03 15:20:28','2026-10-03 15:10:41',0,'2026-10-03 15:10:28');
/*!40000 ALTER TABLE `desktop_agent_pairing_codes` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `notifications` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `type` varchar(40) NOT NULL DEFAULT 'info',
  `title` varchar(160) NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_notifications_user_read` (`user_id`,`is_read`,`created_at`),
  CONSTRAINT `fk_notifications_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES
(1,1,'info','Welcome to TimeTrack','Your account is ready. Change the default password from your profile before you start.','/profile',0,NULL,'2026-10-01 08:55:54'),
(2,3,'info','Welcome to TimeTrack','Your account is ready. Change the default password from your profile before you start.','/profile',0,NULL,'2026-10-01 08:55:54'),
(3,2,'info','Welcome to TimeTrack','Your account is ready. Change the default password from your profile before you start.','/profile',0,NULL,'2026-10-01 08:55:54'),
(4,4,'info','Welcome to TimeTrack','Your account is ready. Change the default password from your profile before you start.','/profile',0,NULL,'2026-10-01 08:55:54'),
(8,2,'info','Timesheet submitted','System Admin submitted a timesheet for Sep 28 – Oct 4, 2026.','/timesheets/1',0,NULL,'2026-10-01 12:57:26'),
(9,1,'info','Timesheet submitted','John Carter submitted a timesheet for Sep 28 – Oct 4, 2026.','/timesheets/2',0,NULL,'2026-10-01 12:58:58'),
(10,2,'info','Timesheet submitted','John Carter submitted a timesheet for Sep 28 – Oct 4, 2026.','/timesheets/2',0,NULL,'2026-10-01 12:58:58'),
(11,3,'success','Timesheet approved','Your timesheet for Sep 28 – Oct 4, 2026 was approved.','/timesheets/2',0,NULL,'2026-10-01 15:10:48'),
(12,3,'info','New task assigned','You were assigned \"Test\" on Al Shifa Trust Eye Hospital.','/projects/2?tab=tasks',0,NULL,'2026-10-01 19:31:56'),
(14,2,'info','Work submitted for approval','System Admin submitted selected work for Oct 1 – Oct 2, 2026.','/timesheets/3',0,NULL,'2026-10-02 11:53:58'),
(15,2,'info','Work submitted for approval','System Admin submitted selected work for Sep 28 – Oct 4, 2026.','/timesheets/4',0,NULL,'2026-10-02 16:50:07'),
(16,2,'info','Work submitted for approval','System Admin submitted selected work for Sep 28 – Oct 4, 2026.','/timesheets/5',0,NULL,'2026-10-02 16:50:23'),
(17,4,'info','Schedule changed','Your planned work for Al Shifa Trust Eye Hospital moved to Oct 3, 12:00.','/schedule/my',0,NULL,'2026-10-03 07:26:21'),
(18,4,'info','Schedule changed','Your planned work for Al Shifa Trust Eye Hospital moved to Oct 3, 12:00.','/schedule/my',0,NULL,'2026-10-03 07:27:33'),
(19,4,'warning','Schedule conflict','A new block overlaps an existing planned block.','/schedule/my',0,NULL,'2026-10-03 07:27:33'),
(20,1,'success','Timesheet approved','Your timesheet for Sep 28 – Oct 4, 2026 was approved.','/timesheets/5',0,NULL,'2026-10-03 10:29:21'),
(21,1,'warning','Timesheet needs changes','Your timesheet for Oct 1 – Oct 2, 2026 was rejected. Need changes','/timesheets/3',0,NULL,'2026-10-03 10:29:35'),
(22,1,'success','Timesheet approved','Your timesheet for Sep 28 – Oct 4, 2026 was approved.','/timesheets/4',0,NULL,'2026-10-03 10:29:43'),
(23,2,'info','Work submitted for approval','System Admin submitted selected work for Sep 28 – Oct 4, 2026.','/timesheets/6',0,NULL,'2026-10-03 10:50:13');
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(60) NOT NULL,
  `display_name` varchar(100) NOT NULL,
  `module` varchar(40) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_name` (`name`),
  KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES
(1,'dashboard.view','View dashboard','dashboard','Open the dashboard.','2026-10-01 08:55:54'),
(2,'notifications.view','View notifications','notifications','See own notifications.','2026-10-01 08:55:54'),
(3,'users.view','View users','users','See the user directory.','2026-10-01 08:55:54'),
(4,'users.create','Create users','users','Add new users.','2026-10-01 08:55:54'),
(5,'users.edit','Edit users','users','Change user details, roles and status.','2026-10-01 08:55:54'),
(6,'users.delete','Delete users','users','Remove users.','2026-10-01 08:55:54'),
(7,'roles.manage','Manage roles','users','Edit roles and their permissions.','2026-10-01 08:55:54'),
(8,'clients.view','View clients','clients','See the client list.','2026-10-01 08:55:54'),
(9,'clients.create','Create clients','clients','Add new clients.','2026-10-01 08:55:54'),
(10,'clients.edit','Edit clients','clients','Change client details.','2026-10-01 08:55:54'),
(11,'clients.delete','Delete clients','clients','Remove clients.','2026-10-01 08:55:54'),
(12,'projects.view','View projects','projects','See projects the user is assigned to.','2026-10-01 08:55:54'),
(13,'projects.view_all','View all projects','projects','See every project, assigned or not.','2026-10-01 08:55:54'),
(14,'projects.create','Create projects','projects','Add new projects.','2026-10-01 08:55:54'),
(15,'projects.edit','Edit projects','projects','Change project details.','2026-10-01 08:55:54'),
(16,'projects.delete','Delete projects','projects','Remove projects.','2026-10-01 08:55:54'),
(17,'projects.archive','Archive projects','projects','Archive and restore projects.','2026-10-01 08:55:54'),
(18,'projects.manage_members','Manage project members','projects','Assign and remove project members.','2026-10-01 08:55:54'),
(19,'tasks.view','View tasks','tasks','See tasks on assigned projects.','2026-10-01 08:55:54'),
(20,'tasks.create','Create tasks','tasks','Add tasks to projects.','2026-10-01 08:55:54'),
(21,'tasks.edit','Edit tasks','tasks','Change tasks.','2026-10-01 08:55:54'),
(22,'tasks.delete','Delete tasks','tasks','Remove tasks.','2026-10-01 08:55:54'),
(23,'tasks.assign','Assign tasks','tasks','Assign tasks to people.','2026-10-01 08:55:54'),
(24,'time.track','Track time','time','Start and stop timers.','2026-10-01 08:55:54'),
(25,'time.view_own','View own time','time','See own time entries.','2026-10-01 08:55:54'),
(26,'time.view_all','View all time','time','See everyone\'s time entries.','2026-10-01 08:55:54'),
(27,'time.edit_own','Edit own time','time','Add and edit own time entries.','2026-10-01 08:55:54'),
(28,'time.edit_all','Edit all time','time','Edit anyone\'s time entries.','2026-10-01 08:55:54'),
(29,'time.approve','Approve timesheets','time','Approve or reject submitted timesheets.','2026-10-01 08:55:54'),
(33,'activity.view','View activity log','system','Read the audit trail.','2026-10-01 08:55:54'),
(34,'settings.manage','Manage settings','system','Change system settings.','2026-10-01 08:55:54'),
(35,'schedule.view','View schedule','schedule','See planned work on assigned projects.','2026-10-01 10:28:52'),
(36,'schedule.create','Create schedule','schedule','Add planned work blocks.','2026-10-01 10:28:52'),
(37,'schedule.edit','Edit schedule','schedule','Change planned work blocks.','2026-10-01 10:28:52'),
(38,'schedule.delete','Delete schedule','schedule','Remove planned work blocks.','2026-10-01 10:28:52'),
(39,'schedule.view_team','View team schedule','schedule','See planned work for the whole team.','2026-10-01 10:28:52'),
(57,'workspace.manage','Manage workspace','workspace','Change workspace identity, policies and workspace permissions.','2026-10-02 08:51:16'),
(61,'imports.manage','Import data','imports','Import CSV data into users, clients, projects, tasks, time and schedules.','2026-10-03 11:06:04'),
(62,'reports.view','View reports','reports','Open reports.','2026-10-04 05:01:24'),
(63,'reports.export','Export reports','reports','Download reports as CSV.','2026-10-04 05:01:24'),
(64,'reports.billing','View billing figures','reports','See rates and billable amounts.','2026-10-04 05:01:24');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_favorites` (
  `user_id` int(10) unsigned NOT NULL,
  `project_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`user_id`,`project_id`),
  KEY `idx_project_favorites_project` (`project_id`),
  CONSTRAINT `fk_project_favorites_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_project_favorites_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `project_favorites` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_favorites` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_members` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `project_role` varchar(60) NOT NULL DEFAULT 'member',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_project_members_project_user` (`project_id`,`user_id`),
  KEY `idx_project_members_user` (`user_id`),
  CONSTRAINT `fk_project_members_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_project_members_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `project_members` DISABLE KEYS */;
INSERT INTO `project_members` VALUES
(1,1,3,'member','2026-10-01 10:03:19'),
(2,1,2,'manager','2026-10-01 10:03:19'),
(3,1,4,'viewer','2026-10-01 10:03:19'),
(4,1,1,'member','2026-10-01 10:03:19'),
(5,2,3,'member','2026-10-01 16:17:21'),
(6,2,4,'member','2026-10-01 16:17:21'),
(7,2,1,'manager','2026-10-01 16:17:21'),
(8,3,3,'member','2026-10-03 07:10:31'),
(9,3,2,'member','2026-10-03 07:10:31'),
(10,3,4,'member','2026-10-03 07:10:31'),
(11,3,1,'manager','2026-10-03 07:10:31'),
(12,4,3,'member','2026-10-03 07:11:26'),
(13,4,4,'member','2026-10-03 07:11:26'),
(14,4,2,'manager','2026-10-03 07:11:26'),
(15,4,1,'member','2026-10-03 07:11:26');
/*!40000 ALTER TABLE `project_members` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` int(10) unsigned NOT NULL,
  `project_code` varchar(50) NOT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `status` enum('Planning','Active','On Hold','Completed','Cancelled','Archived') NOT NULL DEFAULT 'Planning',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `budget` decimal(14,2) NOT NULL DEFAULT 0.00,
  `hourly_rate` decimal(12,2) NOT NULL DEFAULT 0.00,
  `is_billable` tinyint(1) NOT NULL DEFAULT 1,
  `is_public` tinyint(1) NOT NULL DEFAULT 0,
  `color` varchar(7) NOT NULL DEFAULT '#03A9F4',
  `estimate_type` enum('none','time','budget') NOT NULL DEFAULT 'none',
  `manager_id` int(10) unsigned DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_projects_code` (`project_code`),
  KEY `idx_projects_client` (`client_id`),
  KEY `idx_projects_status` (`status`),
  KEY `idx_projects_manager` (`manager_id`),
  KEY `idx_projects_due` (`due_date`),
  KEY `fk_projects_created_by` (`created_by`),
  CONSTRAINT `fk_projects_client` FOREIGN KEY (`client_id`) REFERENCES `clients` (`id`) ON UPDATE CASCADE,
  CONSTRAINT `fk_projects_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_projects_manager` FOREIGN KEY (`manager_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES
(1,1,'PRJ-0001','AFIC',NULL,'2026-10-02','2026-10-15','Planning','High',154.00,0.00,0.00,1,0,'#03A9F4','time',2,1,'2026-10-01 10:03:19','2026-10-01 19:30:53'),
(2,3,'PRJ-0002','Al Shifa Trust Eye Hospital',NULL,NULL,NULL,'Active','Urgent',120.00,0.00,0.00,1,0,'#03A9F4','time',1,1,'2026-10-01 16:17:21','2026-10-02 09:10:48'),
(3,5,'PRJ-0003','Citadel 7 Novacare Hospital',NULL,NULL,NULL,'Active','Urgent',30.00,0.00,0.00,1,0,'#03A9F4','none',1,1,'2026-10-03 07:10:31','2026-10-03 07:10:31'),
(4,5,'PRJ-0004','Novacare Hospital',NULL,NULL,NULL,'Planning','Medium',145.00,0.00,0.00,1,0,'#03A9F4','none',2,1,'2026-10-03 07:11:26','2026-10-03 07:11:26');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permissions` (
  `role_id` int(10) unsigned NOT NULL,
  `permission_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `idx_role_permissions_permission` (`permission_id`),
  CONSTRAINT `fk_role_permissions_permission` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_role_permissions_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `role_permissions` DISABLE KEYS */;
INSERT INTO `role_permissions` VALUES
(1,1,'2026-10-01 08:55:54'),
(1,2,'2026-10-01 08:55:54'),
(1,3,'2026-10-01 08:55:54'),
(1,4,'2026-10-01 08:55:54'),
(1,5,'2026-10-01 08:55:54'),
(1,6,'2026-10-01 08:55:54'),
(1,7,'2026-10-01 08:55:54'),
(1,8,'2026-10-01 08:55:54'),
(1,9,'2026-10-01 08:55:54'),
(1,10,'2026-10-01 08:55:54'),
(1,11,'2026-10-01 08:55:54'),
(1,12,'2026-10-01 08:55:54'),
(1,13,'2026-10-01 08:55:54'),
(1,14,'2026-10-01 08:55:54'),
(1,15,'2026-10-01 08:55:54'),
(1,16,'2026-10-01 08:55:54'),
(1,17,'2026-10-01 08:55:54'),
(1,18,'2026-10-01 08:55:54'),
(1,19,'2026-10-01 08:55:54'),
(1,20,'2026-10-01 08:55:54'),
(1,21,'2026-10-01 08:55:54'),
(1,22,'2026-10-01 08:55:54'),
(1,23,'2026-10-01 08:55:54'),
(1,24,'2026-10-01 08:55:54'),
(1,25,'2026-10-01 08:55:54'),
(1,26,'2026-10-01 08:55:54'),
(1,27,'2026-10-01 08:55:54'),
(1,28,'2026-10-01 08:55:54'),
(1,29,'2026-10-01 08:55:54'),
(1,33,'2026-10-01 08:55:54'),
(1,34,'2026-10-01 08:55:54'),
(1,35,'2026-10-01 10:28:52'),
(1,36,'2026-10-01 10:28:52'),
(1,37,'2026-10-01 10:28:52'),
(1,38,'2026-10-01 10:28:52'),
(1,39,'2026-10-01 10:28:52'),
(1,57,'2026-10-02 08:51:16'),
(1,61,'2026-10-03 11:06:04'),
(1,62,'2026-10-04 05:01:24'),
(1,63,'2026-10-04 05:01:24'),
(1,64,'2026-10-04 05:01:24'),
(2,1,'2026-10-01 08:55:54'),
(2,2,'2026-10-01 08:55:54'),
(2,3,'2026-10-01 08:55:54'),
(2,8,'2026-10-01 08:55:54'),
(2,9,'2026-10-01 08:55:54'),
(2,10,'2026-10-01 08:55:54'),
(2,12,'2026-10-01 08:55:54'),
(2,14,'2026-10-01 08:55:54'),
(2,15,'2026-10-01 08:55:54'),
(2,17,'2026-10-01 08:55:54'),
(2,18,'2026-10-01 08:55:54'),
(2,19,'2026-10-01 08:55:54'),
(2,20,'2026-10-01 08:55:54'),
(2,21,'2026-10-01 08:55:54'),
(2,22,'2026-10-01 08:55:54'),
(2,23,'2026-10-01 08:55:54'),
(2,24,'2026-10-01 08:55:54'),
(2,25,'2026-10-01 08:55:54'),
(2,26,'2026-10-01 08:55:54'),
(2,27,'2026-10-01 08:55:54'),
(2,29,'2026-10-01 08:55:54'),
(2,33,'2026-10-01 08:55:54'),
(2,35,'2026-10-01 10:28:52'),
(2,36,'2026-10-01 10:28:52'),
(2,37,'2026-10-01 10:28:52'),
(2,38,'2026-10-01 10:28:52'),
(2,39,'2026-10-01 10:28:52'),
(2,61,'2026-10-03 11:06:04'),
(2,62,'2026-10-04 05:01:24'),
(2,63,'2026-10-04 05:01:24'),
(2,64,'2026-10-04 05:01:24'),
(3,1,'2026-10-01 08:55:54'),
(3,2,'2026-10-01 08:55:54'),
(3,12,'2026-10-01 08:55:54'),
(3,19,'2026-10-01 08:55:54'),
(3,21,'2026-10-01 08:55:54'),
(3,24,'2026-10-01 08:55:54'),
(3,25,'2026-10-01 08:55:54'),
(3,27,'2026-10-01 08:55:54'),
(3,35,'2026-10-01 10:28:52'),
(3,36,'2026-10-01 10:28:52'),
(3,37,'2026-10-01 10:28:52'),
(3,62,'2026-10-04 05:01:24'),
(4,1,'2026-10-01 08:55:54'),
(4,2,'2026-10-01 08:55:54'),
(4,12,'2026-10-01 08:55:54'),
(4,35,'2026-10-01 10:28:52'),
(4,62,'2026-10-04 05:01:24');
/*!40000 ALTER TABLE `role_permissions` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) NOT NULL,
  `display_name` varchar(60) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES
(1,'admin','Administrator','Full access to every module and setting.','2026-10-01 08:55:54','2026-10-01 08:55:54'),
(2,'manager','Manager','Manages clients, projects, teams and approvals.','2026-10-01 08:55:54','2026-10-01 08:55:54'),
(3,'employee','Employee','Tracks time on the projects they are assigned to.','2026-10-01 08:55:54','2026-10-01 08:55:54'),
(4,'client','Client','Read-only view of their own projects and reports.','2026-10-01 08:55:54','2026-10-01 08:55:54');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedule_recurrences` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `schedule_id` int(10) unsigned NOT NULL,
  `recurrence_type` enum('daily','weekly','weekdays','custom') NOT NULL DEFAULT 'weekly',
  `repeat_until` date DEFAULT NULL,
  `days_of_week` varchar(20) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_recurrence_schedule` (`schedule_id`),
  CONSTRAINT `fk_recurrence_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `schedule_recurrences` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedule_recurrences` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `recurrence_parent_id` int(10) unsigned DEFAULT NULL,
  `start_datetime` datetime NOT NULL,
  `end_datetime` datetime NOT NULL,
  `estimated_hours` decimal(8,2) NOT NULL DEFAULT 0.00,
  `status` enum('Scheduled','In Progress','Completed','Missed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
  `notes` text DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_schedules_user_time` (`user_id`,`start_datetime`,`end_datetime`),
  KEY `idx_schedules_project` (`project_id`),
  KEY `idx_schedules_task` (`task_id`),
  KEY `idx_schedules_status` (`status`),
  KEY `idx_schedules_created_by` (`created_by`),
  KEY `idx_schedules_recurrence_parent` (`recurrence_parent_id`),
  CONSTRAINT `fk_schedules_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_schedules_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_schedules_recurrence_parent` FOREIGN KEY (`recurrence_parent_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_schedules_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
INSERT INTO `schedules` VALUES
(1,1,NULL,3,NULL,'2026-10-01 09:00:00','2026-10-01 12:00:00',3.00,'Scheduled','Homepage layout and CMS mapping.',2,'2026-10-01 10:28:52','2026-10-01 10:28:52'),
(2,1,NULL,4,NULL,'2026-10-01 10:00:00','2026-10-01 14:00:00',4.00,'In Progress','Visual system and template polish.',2,'2026-10-01 10:28:52','2026-10-01 10:28:52'),
(17,2,2,1,NULL,'2026-10-02 16:34:00','2026-10-02 16:36:00',0.03,'Scheduled',NULL,1,'2026-10-02 16:34:05','2026-10-02 16:34:05'),
(18,2,2,4,NULL,'2026-10-03 07:00:00','2026-10-04 03:30:00',20.50,'In Progress',NULL,1,'2026-10-03 07:26:21','2026-10-03 07:26:21'),
(19,2,3,4,NULL,'2026-10-03 07:00:00','2026-10-04 08:00:00',24.00,'In Progress',NULL,1,'2026-10-03 07:27:33','2026-10-03 07:27:33');
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `setting_type` enum('string','int','bool','json') NOT NULL DEFAULT 'string',
  `setting_group` varchar(40) NOT NULL DEFAULT 'general',
  `description` varchar(255) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_settings_key` (`setting_key`),
  KEY `idx_settings_group` (`setting_group`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES
(1,'app_name','TimeTrack','string','general','Name shown in the header and emails.','2026-10-01 08:55:54'),
(3,'company_email','hello@timetrack.local','string','general','Contact address for system emails.','2026-10-01 08:55:54'),
(4,'default_timezone','UTC','string','general','Timezone used when a user has not chosen one.','2026-10-02 08:52:09'),
(5,'date_format','M j, Y','string','general','PHP date() format for dates.','2026-10-01 08:55:54'),
(6,'time_format','H:i','string','general','PHP date() format for times.','2026-10-01 08:55:54'),
(8,'currency','USD','string','billing','ISO currency code for rates and budgets.','2026-10-02 08:52:09'),
(9,'default_hourly_rate','0','string','billing','Rate applied to billable projects without their own rate.','2026-10-02 08:52:09'),
(11,'allow_manual_time_entries','1','bool','time','Let employees add time entries by hand.','2026-10-01 08:55:54'),
(13,'timer_max_hours','12','int','time','Stop a running timer automatically after this many hours.','2026-10-01 08:55:54'),
(14,'notifications_enabled','1','bool','system','Create in-app notifications.','2026-10-01 08:55:54'),
(15,'maintenance_mode','0','bool','system','Block non-admin sign-ins while maintenance is under way.','2026-10-01 08:55:54'),
(16,'currency_symbol','$','string','billing','Symbol shown next to money amounts.','2026-10-02 08:52:09');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `task_assignees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `task_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_task_assignees` (`task_id`,`user_id`),
  KEY `idx_task_assignees_user` (`user_id`),
  CONSTRAINT `fk_task_assignees_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_task_assignees_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `task_assignees` DISABLE KEYS */;
INSERT INTO `task_assignees` VALUES
(1,1,2,'2026-10-01 10:49:55'),
(2,1,3,'2026-10-01 10:49:55'),
(3,1,1,'2026-10-01 10:49:55'),
(4,1,4,'2026-10-01 10:49:55'),
(6,3,1,'2026-10-01 19:31:56'),
(7,3,3,'2026-10-01 19:31:56');
/*!40000 ALTER TABLE `task_assignees` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `parent_task_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(180) NOT NULL,
  `description` text DEFAULT NULL,
  `status` enum('To Do','In Progress','On Hold','Review','Completed','Cancelled') NOT NULL DEFAULT 'To Do',
  `priority` enum('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `estimated_hours` decimal(10,2) NOT NULL DEFAULT 0.00,
  `completion_percent` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `start_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_tasks_project` (`project_id`),
  KEY `idx_tasks_parent` (`parent_task_id`),
  KEY `idx_tasks_status` (`status`),
  KEY `idx_tasks_priority` (`priority`),
  KEY `idx_tasks_due` (`due_date`),
  KEY `fk_tasks_created_by` (`created_by`),
  CONSTRAINT `fk_tasks_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_tasks_parent` FOREIGN KEY (`parent_task_id`) REFERENCES `tasks` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tasks_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
INSERT INTO `tasks` VALUES
(1,1,NULL,'CON - Building Envelope',NULL,'In Progress','Medium',154.00,0,NULL,'2026-10-15',0,1,'2026-10-01 10:49:55','2026-10-03 10:03:04'),
(2,2,NULL,'CON - Building Envelope',NULL,'To Do','Medium',24.00,0,NULL,'2026-10-05',0,1,'2026-10-01 16:27:07','2026-10-02 08:17:19'),
(3,2,NULL,'Test',NULL,'Completed','Medium',0.00,100,NULL,NULL,0,1,'2026-10-01 19:31:40','2026-10-03 10:03:04'),
(4,1,NULL,'CON - Furniture',NULL,'To Do','Medium',0.00,0,NULL,NULL,1,1,'2026-10-03 07:07:33','2026-10-03 07:07:33');
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_entries` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `project_id` int(10) unsigned NOT NULL,
  `task_id` int(10) unsigned DEFAULT NULL,
  `schedule_id` int(10) unsigned DEFAULT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `started_at` datetime NOT NULL,
  `ended_at` datetime DEFAULT NULL,
  `duration_seconds` int(10) unsigned NOT NULL DEFAULT 0,
  `break_minutes` int(10) unsigned NOT NULL DEFAULT 0,
  `is_billable` tinyint(1) NOT NULL DEFAULT 0,
  `billable_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `auto_stopped` tinyint(1) NOT NULL DEFAULT 0,
  `description` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_time_entries_project` (`project_id`),
  KEY `idx_time_entries_task` (`task_id`),
  KEY `idx_time_entries_user` (`user_id`),
  KEY `idx_time_entries_running` (`user_id`,`ended_at`),
  KEY `idx_time_entries_schedule` (`schedule_id`),
  KEY `idx_time_entries_status` (`status`),
  KEY `idx_time_entries_billable` (`is_billable`),
  KEY `idx_time_entries_approved_by` (`approved_by`),
  CONSTRAINT `fk_time_entries_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_time_entries_project` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_time_entries_schedule` FOREIGN KEY (`schedule_id`) REFERENCES `schedules` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_time_entries_task` FOREIGN KEY (`task_id`) REFERENCES `tasks` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_time_entries_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `time_entries` DISABLE KEYS */;
INSERT INTO `time_entries` VALUES
(1,1,NULL,NULL,1,'2026-10-01 11:22:40','2026-10-01 11:50:25',1665,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 11:50:25','2026-10-01 11:50:25'),
(2,1,1,NULL,1,'2026-10-01 11:50:37','2026-10-01 11:50:54',17,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 11:50:54','2026-10-01 11:50:54'),
(3,1,1,NULL,1,'2026-10-01 11:51:20','2026-10-01 11:57:16',356,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 11:57:16','2026-10-01 11:57:16'),
(4,1,1,NULL,1,'2026-10-01 11:57:27','2026-10-01 12:01:19',232,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 12:01:19','2026-10-01 12:01:19'),
(5,1,NULL,NULL,1,'2026-10-01 12:01:21','2026-10-01 12:01:31',10,0,1,0.00,'Pending',NULL,NULL,0,'Working on Master Drawings','2026-10-01 12:01:31','2026-10-01 12:01:31'),
(6,1,1,NULL,3,'2026-10-01 12:58:17','2026-10-01 12:58:48',31,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 12:58:48','2026-10-01 12:58:48'),
(7,1,NULL,NULL,1,'2026-10-01 15:24:38','2026-10-01 15:36:14',696,0,1,0.00,'Pending',NULL,NULL,0,'General','2026-10-01 15:36:14','2026-10-01 15:36:14'),
(8,2,2,NULL,1,'2026-10-01 16:27:35','2026-10-01 16:28:29',54,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 16:28:29','2026-10-01 16:28:29'),
(9,2,2,NULL,1,'2026-10-01 16:46:16','2026-10-01 16:52:49',393,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 16:52:49','2026-10-01 16:52:49'),
(10,2,2,NULL,3,'2026-10-01 16:55:59','2026-10-01 19:59:12',10993,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-01 19:59:12','2026-10-01 19:59:12'),
(11,2,3,NULL,1,'2026-10-01 19:48:00','2026-10-02 05:17:11',34151,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 05:17:11','2026-10-02 05:17:11'),
(13,1,1,NULL,1,'2026-10-02 10:07:52','2026-10-02 10:08:07',15,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 10:08:07','2026-10-02 10:08:07'),
(14,2,3,NULL,3,'2026-10-01 19:59:47','2026-10-02 10:38:28',52721,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 10:38:28','2026-10-02 10:38:28'),
(15,1,1,NULL,3,'2026-10-02 08:43:00','2026-10-02 09:43:00',3600,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 10:44:04','2026-10-02 10:44:04'),
(16,1,1,NULL,3,'2026-10-02 10:48:32','2026-10-02 10:48:41',9,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 10:48:41','2026-10-02 10:48:41'),
(17,1,1,NULL,3,'2026-10-02 10:49:00','2026-10-02 10:49:05',5,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 10:49:05','2026-10-02 10:49:05'),
(18,1,1,NULL,3,'2026-10-02 10:52:01','2026-10-02 10:52:05',4,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 10:52:05','2026-10-02 10:52:05'),
(19,2,2,NULL,1,'2026-10-02 15:59:52','2026-10-02 16:00:39',47,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 16:00:39','2026-10-02 16:00:39'),
(20,1,1,NULL,1,'2026-10-02 16:02:06','2026-10-02 16:03:06',60,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 16:03:06','2026-10-02 16:03:06'),
(21,1,1,NULL,1,'2026-10-02 16:23:33','2026-10-02 16:26:07',154,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 16:26:07','2026-10-02 16:26:07'),
(22,2,2,NULL,1,'2026-10-02 16:34:52','2026-10-02 16:49:53',901,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-02 16:49:53','2026-10-02 16:49:53'),
(23,1,1,NULL,3,'2026-10-02 16:37:03','2026-10-03 04:37:03',43200,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 06:42:00','2026-10-03 06:42:00'),
(24,1,1,NULL,3,'2026-10-03 06:42:49','2026-10-03 06:42:50',1,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 06:42:50','2026-10-03 06:42:50'),
(25,3,NULL,NULL,1,'2026-10-03 07:12:06','2026-10-03 07:12:10',4,0,1,0.00,'Pending',NULL,NULL,0,'test','2026-10-03 07:12:10','2026-10-03 07:12:10'),
(26,4,NULL,NULL,1,'2026-10-03 07:12:19','2026-10-03 07:12:24',5,0,1,0.00,'Pending',NULL,NULL,0,'test 2','2026-10-03 07:12:24','2026-10-03 07:12:24'),
(27,2,2,NULL,1,'2026-10-03 07:13:25','2026-10-03 07:39:45',1580,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 07:39:45','2026-10-03 07:39:45'),
(28,2,2,NULL,1,'2026-10-03 10:49:22','2026-10-03 10:49:49',27,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 10:49:49','2026-10-03 10:49:49'),
(29,2,2,NULL,1,'2026-10-03 13:37:18','2026-10-03 14:02:09',711,13,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 14:02:09','2026-10-03 14:02:09'),
(30,1,1,NULL,1,'2026-10-03 14:03:18','2026-10-03 14:05:00',102,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 14:05:00','2026-10-03 14:05:00'),
(31,2,2,NULL,1,'2026-10-03 14:08:13','2026-10-03 14:14:47',394,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 14:14:47','2026-10-03 14:14:47'),
(32,2,2,NULL,1,'2026-10-03 14:15:06','2026-10-03 14:49:24',2058,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 14:49:24','2026-10-03 14:49:24'),
(33,1,4,NULL,1,'2026-10-03 14:49:30','2026-10-03 15:10:12',1242,0,1,0.00,'Pending',NULL,NULL,0,NULL,'2026-10-03 15:10:12','2026-10-03 15:10:12'),
(34,3,NULL,NULL,1,'2026-10-03 15:11:03','2026-10-03 15:20:41',158,7,1,0.00,'Pending',NULL,NULL,0,'Test','2026-10-03 15:20:41','2026-10-03 15:20:41'),
(35,4,NULL,NULL,1,'2026-10-03 15:20:52','2026-10-03 15:23:15',143,0,1,0.00,'Pending',NULL,NULL,0,'Test','2026-10-03 15:23:15','2026-10-03 15:23:15'),
(36,4,NULL,NULL,1,'2026-10-03 15:23:27','2026-10-03 15:32:39',372,3,1,0.00,'Pending',NULL,NULL,0,'Test','2026-10-03 15:32:39','2026-10-03 15:32:39');
/*!40000 ALTER TABLE `time_entries` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `timer_idle_events` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `timer_id` int(10) unsigned NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `last_activity_at` datetime NOT NULL,
  `warning_at` datetime NOT NULL,
  `response` enum('continued','manual_pause','auto_paused') DEFAULT NULL,
  `responded_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_idle_timer_open` (`timer_id`,`response`,`id`),
  KEY `idx_idle_user_created` (`user_id`,`created_at`),
  CONSTRAINT `fk_idle_timer` FOREIGN KEY (`timer_id`) REFERENCES `active_timers` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_idle_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `timer_idle_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `timer_idle_events` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `timesheet_entries` (
  `timesheet_id` int(10) unsigned NOT NULL,
  `time_entry_id` int(10) unsigned NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`timesheet_id`,`time_entry_id`),
  UNIQUE KEY `uq_timesheet_entries_entry` (`time_entry_id`),
  KEY `idx_timesheet_entries_timesheet` (`timesheet_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `timesheet_entries` DISABLE KEYS */;
INSERT INTO `timesheet_entries` VALUES
(1,1,'2026-10-01 12:57:26'),
(1,2,'2026-10-01 12:57:26'),
(1,3,'2026-10-01 12:57:26'),
(1,4,'2026-10-01 12:57:26'),
(1,5,'2026-10-01 12:57:26'),
(2,6,'2026-10-01 12:58:58'),
(4,19,'2026-10-02 16:50:07'),
(5,8,'2026-10-02 16:50:23'),
(6,27,'2026-10-03 10:50:13'),
(6,28,'2026-10-03 10:50:13');
/*!40000 ALTER TABLE `timesheet_entries` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `timesheets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) unsigned NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `submission_token` varchar(64) DEFAULT NULL,
  `total_seconds` int(10) unsigned NOT NULL DEFAULT 0,
  `billable_seconds` int(10) unsigned NOT NULL DEFAULT 0,
  `status` enum('Draft','Submitted','Approved','Rejected') NOT NULL DEFAULT 'Draft',
  `submitted_at` datetime DEFAULT NULL,
  `approved_by` int(10) unsigned DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `rejection_reason` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_timesheets_submission_token` (`submission_token`),
  KEY `idx_timesheets_status` (`status`),
  KEY `idx_timesheets_submitted` (`submitted_at`),
  KEY `idx_timesheets_approved_by` (`approved_by`),
  KEY `idx_timesheets_user_period` (`user_id`,`start_date`,`end_date`),
  CONSTRAINT `fk_timesheets_approved_by` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_timesheets_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `timesheets` DISABLE KEYS */;
INSERT INTO `timesheets` VALUES
(1,1,'2026-09-28','2026-10-04','legacy-1',2280,2280,'Submitted','2026-10-01 12:57:26',NULL,NULL,NULL,'2026-10-01 12:57:26','2026-10-02 16:49:39'),
(2,3,'2026-09-28','2026-10-04','legacy-2',31,31,'Approved','2026-10-01 12:58:58',1,'2026-10-01 15:10:48',NULL,'2026-10-01 12:58:58','2026-10-02 16:49:39'),
(3,1,'2026-10-01','2026-10-02','legacy-3',1104,1104,'Rejected','2026-10-02 11:53:58',2,'2026-10-03 10:29:35','Need changes','2026-10-02 11:53:58','2026-10-03 10:29:35'),
(4,1,'2026-09-28','2026-10-04','a0e7b8a9480845ba8835d21d51d78537',47,47,'Approved','2026-10-02 16:50:07',2,'2026-10-03 10:29:43',NULL,'2026-10-02 16:50:07','2026-10-03 10:29:43'),
(5,1,'2026-09-28','2026-10-04','66f8954c29d7db5b98071b6eeed16c58',54,54,'Approved','2026-10-02 16:50:23',2,'2026-10-03 10:29:21',NULL,'2026-10-02 16:50:23','2026-10-03 10:29:21'),
(6,1,'2026-09-28','2026-10-04','ed11dec814a9a8ea7aad3b010a7e2481',1607,1607,'Submitted','2026-10-03 10:50:13',NULL,NULL,NULL,'2026-10-03 10:50:13','2026-10-03 10:50:13');
/*!40000 ALTER TABLE `timesheets` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `role_id` int(10) unsigned NOT NULL,
  `role` enum('admin','manager','employee','client') NOT NULL DEFAULT 'employee',
  `name` varchar(120) NOT NULL,
  `email` varchar(190) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `hourly_rate` decimal(10,2) NOT NULL DEFAULT 0.00,
  `timezone` varchar(64) NOT NULL DEFAULT 'UTC',
  `status` enum('active','inactive','suspended') NOT NULL DEFAULT 'active',
  `failed_login_attempts` tinyint(3) unsigned NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `last_login_at` datetime DEFAULT NULL,
  `last_login_ip` varchar(45) DEFAULT NULL,
  `password_changed_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  KEY `idx_users_status` (`status`),
  KEY `idx_users_role_id` (`role_id`),
  KEY `idx_users_role_status` (`role`,`status`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,1,'admin','System Admin','admin@timetrack.local','$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC',NULL,'Administrator',0.00,'Asia/Karachi','active',0,NULL,'2026-10-03 13:36:17','58.65.217.235','2026-10-01 08:55:54','2026-10-01 08:55:54','2026-10-03 13:36:17'),
(2,2,'manager','Morgan Lee','manager@timetrack.local','$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC',NULL,'Project Manager',0.00,'Asia/Karachi','active',0,NULL,'2026-10-03 10:28:56','58.65.217.235','2026-10-01 08:55:54','2026-10-01 08:55:54','2026-10-03 10:28:56'),
(3,3,'employee','John Carter','john@timetrack.local','$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC',NULL,'Developer',0.00,'Asia/Karachi','active',0,NULL,'2026-10-03 13:09:46','58.65.217.235','2026-10-01 08:55:54','2026-10-01 08:55:54','2026-10-03 13:09:46'),
(4,3,'employee','Sarah Khan','sarah@timetrack.local','$2y$12$6qBgkje1aLEeWo28U1gisOzYrvFPrGm.COXbbfYxVRRbrCbCmZMAC',NULL,'Designer',0.00,'Asia/Karachi','active',0,NULL,'2026-10-03 06:43:11','58.65.217.235','2026-10-01 08:55:54','2026-10-01 08:55:54','2026-10-03 06:43:11'),
(6,3,'employee','Ali Khan','ali@example.com','$2y$12$VPqJsRFYS/3msZg087b.I.T8jUXQ/vs.N9Z9Oad3gt.4m5RRy3MlK','3001234567','Designer',1500.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:15','2026-10-03 11:16:15'),
(7,2,'manager','Sara Ahmed','sara@example.com','$2y$12$URzGrAe9PsyqPn0wuhV1KeskHMB78/RwrlwHROm/8NKfRAYMs2n42','3007654321','Project Manager',3000.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:15','2026-10-03 11:16:15'),
(8,3,'employee','Usman Malik','usman@example.com','$2y$12$ZH201jfwFKqjGUKURAJ8seYGikn0qnWoej.NQJD.vsPWYsxh/ZkzK','3001122334','Developer',2200.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:16','2026-10-03 11:16:16'),
(9,3,'employee','Ayesha Noor','ayesha@example.com','$2y$12$nY.D2R1aoqT1tTDqqWwUw.LVUA9eZtTLsMvly4WVJSsN8XED08Wxm','3005566778','UI/UX Designer',1800.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:16','2026-10-03 11:16:16'),
(10,2,'manager','Hamza Raza','hamza@example.com','$2y$12$mCU.WYQJjxq169XJ7/BpRecMZXN/Et6QUCNrL0kV4VQdm6BuIcQea','3009988776','Team Lead',3500.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:16','2026-10-03 11:16:16'),
(11,3,'employee','Fatima Shah','fatima@example.com','$2y$12$KaIi6ERohJxLVeD0rAANQ.kQ4Sl2lQ9Gq8szKaZLAEbmheyNkUf/W','3004455667','Content Writer',1600.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:16','2026-10-03 11:16:16'),
(12,3,'employee','Bilal Ahmed','bilal@example.com','$2y$12$LL5N2QsKap1Y8F6fTZOMPuBiiiE33K8rcmAKCQdCzsDjBN6UB0J2W','3002233445','Backend Developer',2500.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:16','2026-10-03 11:16:16'),
(13,3,'employee','Hira Ali','hira@example.com','$2y$12$VyC1c/D2dl1CGQjTUWK/OOrszz3zJ5VLKVtX2cEr.r3tj253OVSle','3006677889','QA Engineer',2000.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:17','2026-10-03 11:16:17'),
(14,3,'employee','Danish Khan','danish@example.com','$2y$12$lmE1tXnbe2CFywEF1jPnVONRHTvCBAckm9T9nIMymT/lat66Sclya','3003344556','Frontend Developer',2300.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:17','2026-10-03 11:16:17'),
(15,2,'manager','Maham Iqbal','maham@example.com','$2y$12$7hFgZFim3wOSWzMKArLSWeBeZajOKL88yD905Srr66dijaGXum8vG','3007788990','Operations Manager',3200.00,'Asia/Karachi','active',0,NULL,NULL,NULL,NULL,'2026-10-03 11:16:17','2026-10-03 11:16:17');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `workspace_settings` (
  `workspace_id` int(10) unsigned NOT NULL,
  `setting_key` varchar(80) NOT NULL,
  `setting_value` varchar(1000) DEFAULT NULL,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`workspace_id`,`setting_key`),
  CONSTRAINT `fk_workspace_settings_workspace` FOREIGN KEY (`workspace_id`) REFERENCES `workspaces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `workspace_settings` DISABLE KEYS */;
INSERT INTO `workspace_settings` VALUES
(1,'activity_monitoring_enabled','1','2026-10-03 06:29:26'),
(1,'approval_period','weekly','2026-10-03 14:03:03'),
(1,'audit_log_enabled','1','2026-10-03 06:29:26'),
(1,'billable_hours_enabled','1','2026-10-03 06:29:26'),
(1,'breaks_enabled','1','2026-10-03 06:29:26'),
(1,'daily_capacity','8','2026-10-03 14:03:03'),
(1,'default_project_visibility','private','2026-10-03 14:03:03'),
(1,'duration_format','clock_seconds','2026-10-03 06:29:26'),
(1,'edit_time_others_policy','admins_team_managers','2026-10-03 14:03:03'),
(1,'expense_approval_enabled','0','2026-10-03 06:29:26'),
(1,'expenses_enabled','0','2026-10-03 06:29:26'),
(1,'favorite_entries_enabled','1','2026-10-03 06:29:26'),
(1,'favorites_enabled','1','2026-10-03 06:29:26'),
(1,'force_timer','0','2026-10-03 14:03:03'),
(1,'gps_enabled','1','2026-10-03 06:29:26'),
(1,'hide_projects','0','2026-10-03 14:03:03'),
(1,'hide_reports','0','2026-10-03 14:03:03'),
(1,'hide_team','0','2026-10-03 14:03:03'),
(1,'hide_tracker','0','2026-10-03 14:03:03'),
(1,'idle_detection_enabled','1','2026-10-03 14:03:03'),
(1,'idle_threshold_minutes','1','2026-10-03 14:03:03'),
(1,'idle_warning_seconds','60','2026-10-03 14:03:03'),
(1,'invoice_manager_policy','admins','2026-10-03 06:29:26'),
(1,'invoicing_enabled','0','2026-10-03 06:29:26'),
(1,'kiosk_enabled','1','2026-10-03 06:29:26'),
(1,'lock_time_enabled','0','2026-10-03 14:03:03'),
(1,'organize_time_by','project_task','2026-10-03 06:29:26'),
(1,'project_creation_policy','admins_project_managers','2026-10-03 14:03:03'),
(1,'project_status_visibility','anyone','2026-10-03 06:29:26'),
(1,'regular_user_time_visibility','own','2026-10-03 14:03:03'),
(1,'required_fields','','2026-10-03 06:29:26'),
(1,'scheduling_enabled','0','2026-10-03 14:03:03'),
(1,'screenshots_enabled','1','2026-10-03 06:29:26'),
(1,'tag_creation_policy','anyone','2026-10-03 06:29:26'),
(1,'task_creation_policy','admins_project_managers','2026-10-03 14:03:03'),
(1,'time_approval_enabled','1','2026-10-03 14:03:03'),
(1,'time_off_enabled','1','2026-10-03 06:29:26'),
(1,'time_rounding_minutes','1','2026-10-03 14:03:03'),
(1,'timesheet_approver_policy','admins_team_managers','2026-10-03 06:29:26'),
(1,'timesheet_enabled','1','2026-10-03 14:03:03'),
(1,'week_start','monday','2026-10-03 14:03:03'),
(1,'working_days','Mon,Tue,Wed,Thu,Fri','2026-10-03 06:29:26');
/*!40000 ALTER TABLE `workspace_settings` ENABLE KEYS */;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `workspaces` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(160) NOT NULL,
  `logo_path` varchar(500) DEFAULT NULL,
  `created_by` int(10) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_workspaces_created_by` (`created_by`),
  CONSTRAINT `fk_workspaces_created_by` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

/*!40000 ALTER TABLE `workspaces` DISABLE KEYS */;
INSERT INTO `workspaces` VALUES
(1,'Maven Projects LLP.','/uploads/workspace/logo-a14157ace63e7d5fb1f9.png',1,'2026-10-02 08:51:16','2026-10-02 17:39:24');
/*!40000 ALTER TABLE `workspaces` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;


-- Read-only alias of activity_logs used by Settings > Audit logs.
-- SQL SECURITY INVOKER and no DEFINER, so it imports on any host/user.
CREATE OR REPLACE SQL SECURITY INVOKER VIEW `audit_logs` AS
    SELECT `id`, `user_id`, `action`, `module`, `entity_type`, `entity_id`,
           `ip_address`, `user_agent`, `meta`, `old_value`, `new_value`, `created_at`
    FROM `activity_logs`;
