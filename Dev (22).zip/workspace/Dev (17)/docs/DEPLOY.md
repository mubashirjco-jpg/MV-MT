# Shared-hosting deploy and rollback

## Atomic swap (cPanel File Manager)

1. Take a phpMyAdmin backup of the live database.
2. Upload the release zip to a sibling folder, for example `public_html/Dev-new`.
3. Extract so `public_html/Dev-new/public/index.php` exists.
4. Copy `config/database.php` (and any host `.env` / `APP_KEY`) from the live folder into `Dev-new/config/`.
5. Copy `public/uploads/` from live into `Dev-new/public/uploads/`.
6. Confirm `storage/sessions` and `storage/logs` are writable (0750).
7. Rename live `public_html/Dev` to `public_html/Dev-prev`.
8. Rename `public_html/Dev-new` to `public_html/Dev`.
9. Hit `/health` (must return `ok`) then sign in.
10. Keep `Dev-prev` until the next successful deploy. To roll back, rename `Dev` to `Dev-bad` and `Dev-prev` back to `Dev`.

## Maintenance flag (503 + Retry-After)

Create an empty file at `storage/maintenance.flag`. The front controller serves `public/maintenance.html` with HTTP 503 and `Retry-After: 120`. Other 503s (PHP fatals, host limits) are not rewritten to this page. Delete the flag file to restore the app. Workspace `maintenance_mode` still blocks non-admin login independently of the flag.
