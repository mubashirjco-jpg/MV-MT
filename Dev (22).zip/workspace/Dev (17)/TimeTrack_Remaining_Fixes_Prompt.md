# TimeTrack – Remaining Fixes Prompt (re-audit of Dev (17).zip)

How to use: paste the MASTER PROMPT once at the start of a new chat and attach the latest Dev zip plus the live SQL dump. Then paste ONE fix step at a time. After each step, test, then reply "continue".

---

## MASTER PROMPT (paste once)

ROLE
You are a senior PHP architect finishing the hardening of my "TimeTrack" app (native PHP 8.2+ MVC, MariaDB 11.8, Bootstrap 5, vanilla JS, no Composer, shared hosting at public_html/Dev). I attached the current code zip and the live SQL dump. I will give you ONE fix at a time. Do only that fix.

CONTEXT
A re-audit of my latest zip found that many earlier fixes are done and several are not. The facts below were verified against the actual code. Do not re-debate them, but DO re-read the files before editing, because my code may have changed.
Ignore the demo users (@timetrack.local) and the DB password in config/database.php. They are intentionally left in test state for now. Do not print or repeat any real password; use placeholders.

HARD RULES
- Re-read the actual code first. Do not assume.
- Give complete, copy-pasteable files with exact paths. No TODOs, no "rest of code here".
- PDO prepared statements only. CSRF on every POST/AJAX. htmlspecialchars with ENT_QUOTES on output. RBAC enforced in controllers (never only by hiding a menu item). Timer logic is server-authoritative in UTC.
- Never break existing data. Every DB change goes in database/phase13/NN_name.sql (idempotent, safe to run twice on MariaDB 11.8) plus NN_name.down.sql (rollback). Use unique, sequential numbers: do not reuse a number that already exists. Update database/install.sql, database/phase13/ROLLBACK_ALL.sql and docs/STEP20_TEST_MATRIX.md for every change.
- For every fix add one line explaining the security or integrity implication.
- Ask me at most one question, and only if truly ambiguous.

VERIFIED CURRENT STATE (from the latest zip)
- DONE and working, do not redo: stuck-timer fix (TimerController::stop catches InvalidArgumentException, Timer::resolveStop trim/discard), overlap check against the running active_timers row with FOR UPDATE locks, 12-hour auto-stop (Timer, timer_max_hours via SettingsService, cron_auto_stop.php, migration 03), approverScope without the "employee" fallback and self-approval blocked, /timer/* to /time 301 redirects, Team page, notifications.view and projects.delete enforced, audit_logs view uses SQL SECURITY INVOKER, Reports module exists, SettingsService exists.
- Live time_entries now has: schedule_id, break_minutes, billable_rate, status (Pending/Approved/Rejected), approved_by, approved_at, auto_stopped. It has NO indexes on (user_id, started_at) or (project_id, started_at) and NO CHECK ended_at >= started_at.
- TimeEntry::isLocked() still treats status = 'Approved' as a lock AND timesheet_entries membership as a lock (two lock models). assertWeekUnlocked() no longer exists. Lock checks exist on update/delete (lines ~127, 194, 228) but NOT on create/backdate, and not on the description change path.
- TimeEntry list filter still does "te.status = :status" (line ~830) instead of filtering by timesheet state.
- Project::userCanTrack() only checks isMember (viewer role can track). There is no project start_date check. TimeEntry project picker allows Planning, Active and On Hold. Only "completed task" is blocked (TimerController ~line 792), and I have not verified it for manual add and edit.
- Schedule::expandRecurrence() calls checkConflict per occurrence (good) but still uses $start->diff($end) (the whole span) for each copy, never sets recurrence_parent_id on the copies, and does not report skipped conflicts to the caller.
- database/phase13 contains: 03, 05_allow_multiple_submission_batches, 05_schedule_recurrence_parent, 05_schedule_bad_rows.*, 06, 08, 15, ROLLBACK_ALL.sql and a duplicate nested database/phase13/phase13/ folder. Migration numbering collides (three files start with 05_). Missing: 01 (indexes/CHECK), 02 (must_change_password), 04, 07, 09 (client scoping).
- Migration 05_allow_multiple_submission_batches conflicts with the rule "one non-overlapping timesheet period per user".
- config/config.php CSP still allows https://cdn.jsdelivr.net in script-src, style-src and font-src. app/Views/layouts/header.php and footer.php still load Bootstrap 5.3.3, Font Awesome 6.5.2, Chart.js 4.4.4, IBM Plex Sans and Roboto from jsDelivr. public/assets has no vendor/ or fonts/ folder. Inline <script> blocks remain in app/Views/timer/index.php (line ~256) and app/Views/timesheets/my_timesheet.php (line ~347). There are no inline on*= handlers.
- /health is public and prints PHP version and DB details when app.debug is on. There is no /admin/health.
- No users.must_change_password, no tools/golive.php, no client_users / users.client_id. The client role is only handled in Report.php.
- Release hygiene: app/Views/timer/timer/ still exists (its index.php now DIFFERS from app/Views/timer/index.php, and it lacks manual_entry_modal.php). The zip contains u897128490_timetrack_fixed.sql, phase17_sync_live_schema.sql at the root, and database/phase13/phase13/. There is no build-release script, no maintenance.html, no deploy notes.
- docs/LIVE_SCHEMA_DIFF.md says time_entries.auto_stopped is missing live, but the dump already has it. Treat the doc as stale and regenerate it from the real dump.
- users.role, tasks.assigned_to and activity_logs.record_id still exist in the live dump. Migration 08 is written but not applied or verified.

OUTPUT FORMAT FOR EVERY FIX
1) Findings confirmed or rejected against the code (short, with file and line)
2) Full changed/new files with paths
3) Migration + rollback SQL (if any)
4) "How I test it" checklist (5-10 checks, expected result for each)
5) Stop. Wait for my "continue".

Reply "Ready" and wait for FIX 1.

---

## FIX STEPS (paste one at a time, in this order)

### FIX 1 – Tracking business rules (Step 11, highest priority)
Create ONE shared method (for example TimeTrackingRules::assertCanTrack($userId, $projectId, $taskId, $startUtc, $context)) and call it from timer start, manual add, entry edit, and any import that writes time_entries. Rules:
(a) A project member whose project_role is 'viewer' cannot track time and cannot be assigned tasks. Fix Project::userCanTrack() so it checks the member's role, and block viewer assignment in TaskController assignees/store/update.
(b) Time cannot start before the project's start_date (compare in the project/user timezone, store UTC).
(c) Allowed project statuses: Active only. Planning, On Hold, Completed and Archived are blocked. Also update the project picker query in TimeEntry (line ~366, currently Planning/Active/On Hold) and TimerController (line ~937) so blocked projects are not offered.
(d) Completed (and Cancelled) tasks are blocked for start, manual add AND edit, including when an edit changes the task.
Return clear 422 messages (JSON for AJAX, flash for normal posts). Admins are NOT exempt from (b), (c), (d).
Test it: a viewer is blocked on all three paths; an entry before start_date is rejected; entries on completed tasks are rejected on start, manual add and edit; a project set to On Hold or Planning is rejected and not shown in the picker.

### FIX 2 – One lock model (Step 10)
Decision: the ONLY lock is "the entry belongs to a Submitted or Approved timesheet (timesheet_entries membership)". Remove the status/approved_by/approved_at logic from TimeEntry (constants, alias map, isLocked's status check, create/update payloads) and every view or query that reads te.status. Migration 04: make it idempotent, copy any entry still marked 'Approved' into the timesheet model only if it is not already on an approved timesheet (preview with a SELECT first and tell me the count), then drop the three columns and the status enum. Add a single assertWeekUnlocked()/assertNotLocked() guard and call it on create, update, delete, description change and import, so nothing can be backdated into a locked period. Fix the /time?status= filter to filter by timesheet state (unsubmitted / submitted / approved / rejected) using timesheet_entries + timesheets, and update the filter dropdown. Verify billable_rate is frozen at save time and is not recalculated when the project or user rate changes.
Test it: add, edit, delete and description-edit all fail in an Approved week; backdating into an Approved week fails; breaks are stored; changing the project rate later does not change old entries; /time?status=approved lists entries instead of an empty list.

### FIX 3 – Schedule recurrence (Step 13)
Fix Schedule::expandRecurrence: each occurrence must keep the ORIGINAL single-day duration (end - start of the source block, never a multi-day span; if the source spans more than 24h, cap it or reject it with a clear message). Set recurrence_parent_id on every created copy. Keep checkConflict per occurrence, but return structured results (created ids, skipped dates with the conflicting schedule) and show a message to the user in ScheduleController ("5 created, 2 skipped because of conflicts: ..."). Run the SELECT preview in database/phase13/05_schedule_bad_rows.preview.sql first, then the cleanup. Renumber the colliding 05_* migration files so numbers are unique, and keep ROLLBACK_ALL.sql in sync.
Test it: a 5-day weekday recurrence makes 5 one-day rows linked to the parent; conflicts are skipped and reported; cleanup preview matches the bad multi-day rows.

### FIX 4 – Timesheet period integrity (Step 12 leftovers)
Decide and enforce ONE non-overlapping period per user, aligned to the configured approval_period and week start. Re-examine migration 05_allow_multiple_submission_batches: if it allows overlapping sheets, replace it with a design that keeps one sheet per user per period (re-submission after a rejection reuses the same sheet). Add a DB-level guard (unique key on user_id + period start, or an overlap check inside a transaction). Provide the cleanup SQL for the old timesheets 1 and 3 (merge into one weekly sheet, attach entries 8 and 11), with a SELECT preview first. Confirm that unsubmitted entries show an "unsubmitted" warning and that nothing can be backdated into an approved period. Confirm the sidebar pending count uses the same approverScope.
Test it: overlapping sheets cannot be created; self-approval blocked for managers and admins; a manager only sees their own people's sheets; reject, resubmit, approve and lock all work.

### FIX 5 – Self-host assets and strict CSP (Step 6)
Remove every jsDelivr dependency. Download and place: Bootstrap 5.3.3 (css + bundle js), Font Awesome 6.5.2 (all.min.css + only the needed webfonts woff2), Chart.js 4.4.4 (umd min), IBM Plex Sans 400/500/600 and Roboto 400/500 as woff2 only. Tell me exactly which files to download and the exact paths (public/assets/vendor/..., public/assets/fonts/...). Write @font-face rules in a local CSS file. Update header.php and footer.php, and update the CSP in config/config.php to drop cdn.jsdelivr.net and the SRI attributes that no longer apply. Move the inline <script> blocks in app/Views/timer/index.php and app/Views/timesheets/my_timesheet.php into external JS files (pass server values through data-* attributes or a JSON <script type="application/json"> block served as data, not code), and grep every view again for inline scripts and on*= handlers.
Test it: zero CSP errors in the browser console on every page, and the Network tab shows no external hosts.

### FIX 6 – Health endpoints (Step 5)
Keep /health public but make it a tiny ok / not ok response only, with no PHP version, DB details or debug block, even if app.debug is on. Add /admin/health (admin only, enforced in the controller, 403 for others, redirect for logged-out): PHP version vs required 8.2, required extensions (pdo_mysql, mbstring, intl if used, json, etc.), writable storage/sessions and storage/logs and public/uploads, DB connectivity, DB time vs PHP time, and the SchemaHelper::requiredMissing() result. Add a sidebar link for admins.
Test it: admin sees details, employee gets 403, logged-out user is redirected, public /health shows only ok.

### FIX 7 – DB indexes and CHECK (Step 4)
Create database/phase13/01_base.sql (+ .down.sql), idempotent on MariaDB 11.8: (a) add indexes time_entries(user_id, started_at) and (project_id, started_at) only if missing; (b) first provide a SELECT listing rows where ended_at < started_at, then add CHECK (ended_at IS NULL OR ended_at >= started_at) only if it does not exist. Add it to install.sql and ROLLBACK_ALL.sql.
Test it: run twice with no errors; SHOW INDEX shows the new indexes; inserting an entry with ended_at < started_at fails.

### FIX 8 – Forced password change and go-live script (Step 7)
Migration (next free number): users.must_change_password tinyint(1) NOT NULL DEFAULT 0 (idempotent). Block ALL routes except the change-password page, logout and static assets while the flag is set (enforce in the middleware, not in views). Clear the flag on a successful change, and set password_changed_at. Add tools/golive.php (CLI only, refuses to run over HTTP) that creates the real admin with must_change_password = 1, deactivates the @timetrack.local demo users (do not delete rows referenced by data), and prints a go-live checklist. Keep the demo users as they are until I run it.
Test it: a flagged user can only reach the change-password page; after golive.php the demo logins fail and the new admin works.

### FIX 9 – Client role scoping (Step 18)
Migration (next free number): client_users(user_id, client_id) with FKs and a unique key, idempotent. Scope EVERY query and route for role 'client': read-only, only projects, tasks and permitted report data of their own client(s), no time editing, no timer, no schedule edit, no access to other clients' data, no user/workspace/settings pages. Enforce in controllers and models (not only the sidebar). Add a client picker on user create/edit when the role is client. Update tools/route_matrix.php so client results are included.
Test it: a client user sees only their own client's projects; direct URLs to other clients' projects, tasks, reports and /time return 403/404.

### FIX 10 – Apply and verify the schema cleanup (Step 17)
Review migration 08 against the live dump. Confirm it: keeps users.role_id as the source and removes or guards users.role (update EVERY query using it), copies tasks.assigned_to into task_assignees and then drops it (update all code), keeps activity_logs.entity_id and drops record_id (update the audit_logs view), and normalises project_members.project_role to lowercase with a matching default. Fix anything missing and give the safe run order.
Test it: login, role checks, task assignment and the audit log still work and data row counts are unchanged.

### FIX 11 – Release hygiene and deploy (Steps 2 and 3)
Delete app/Views/timer/timer/ (confirm first that app/Views/timer/ has the newer files). Remove database/phase13/phase13/ duplicates. Keep the SQL dumps out of the release zip: move u897128490_timetrack_fixed.sql and phase17_sync_live_schema.sql into a non-deployed folder (for example _dev/) and exclude it. Give me build-release.sh (and a PowerShell version) that builds a clean zip (no sess_*, no *.log, no upload files, no *.sql dumps, no timer/timer, keep the .gitkeep files) plus a checklist to verify the zip contents. Also provide: (a) an atomic deploy method for shared hosting (upload to a temp folder, swap by rename, keep the previous version for rollback) with exact cPanel File Manager steps; (b) a static maintenance.html served with a 503 and Retry-After while a flag file exists. I removed the flag-file gate earlier because it masked real 503s, so make the gate match ONLY the flag file and never other 503s, and keep the app's own maintenance setting working.
Test it: the zip contains none of the excluded items; creating the flag file shows the 503 page; deleting it restores the site.

### FIX 12 – Final consolidation (Step 20)
Renumber and order every phase13 migration with no duplicate numbers. Regenerate database/install.sql and diff it against the live dump (u897128490_timetrack_fixed.sql); rewrite docs/LIVE_SCHEMA_DIFF.md from the real diff. Update ROLLBACK_ALL.sql, give me the ordered upgrade list for the live DB, update docs/STEP20_TEST_MATRIX.md (Admin, Manager, Employee, Client: login, lockout, password change, CRUD, member access, timer start/pause/resume/stop, second tab, manual entry, edit, delete, overlap rejection, 12-hour auto-stop, timesheet submit/approve/reject/resubmit, schedule create/recurrence/conflict, notifications, settings on/off, dark mode, mobile, direct-URL 403 for every route per role), and check clean_test_data.sql.
Test it: a fresh install on an empty database matches production and the full matrix passes.

---

## Tips
- Take a phpMyAdmin backup before every migration, and test on a copy (for example public_html/Dev-test with its own database) first.
- If a step fails your test, paste the failure back and say "fix only this".
- Do FIX 1, 2, 3 and 4 first. They are the real data-integrity holes. FIX 5 and 6 matter for security. The rest can follow in order.
