<?php
/**
 * CLI go-live helper. Creates a real admin (must_change_password = 1) and
 * deactivates @timetrack.local demo users without deleting their rows.
 *
 * Integrity: a leaked bootstrap password cannot linger; the new admin must
 * change it before using the app.
 */

declare(strict_types=1);

if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit("Not found.\n");
}

if (PHP_VERSION_ID < 80200) {
    fwrite(STDERR, "PHP 8.2 or newer is required.\n");
    exit(1);
}

define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');

spl_autoload_register(static function (string $class): void {
    if (!preg_match('/^[A-Za-z][A-Za-z0-9]*$/', $class)) {
        return;
    }
    $names = [$class];
    if (str_ends_with($class, 'Helper')) {
        $names[] = substr($class, 0, -strlen('Helper'));
    }
    foreach (['Core', 'Helpers', 'Middleware', 'Controllers', 'Models'] as $folder) {
        foreach ($names as $name) {
            $file = APP_PATH . '/' . $folder . '/' . $name . '.php';
            if (is_file($file)) {
                require $file;
                return;
            }
        }
    }
});

date_default_timezone_set('UTC');
Config::load(require CONFIG_PATH . '/config.php');
Config::set('database', require CONFIG_PATH . '/database.php');

$options = getopt('', ['name:', 'email:', 'password:', 'timezone:', 'help']);
if (isset($options['help']) || $options === false) {
    fwrite(STDOUT, "Usage: php tools/golive.php --name=\"Full Name\" --email=admin@example.com --password='...' [--timezone=UTC]\n");
    exit(isset($options['help']) ? 0 : 1);
}

$name = trim((string) ($options['name'] ?? ''));
$email = strtolower(trim((string) ($options['email'] ?? '')));
$password = (string) ($options['password'] ?? '');
$timezone = trim((string) ($options['timezone'] ?? 'UTC'));

if ($name === '' || $email === '' || $password === '') {
    fwrite(STDERR, "name, email and password are required.\n");
    exit(1);
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    fwrite(STDERR, "email is not valid.\n");
    exit(1);
}
if (str_ends_with($email, '@timetrack.local')) {
    fwrite(STDERR, "Do not use a @timetrack.local address for the live admin.\n");
    exit(1);
}
if (strlen($password) < 10 || strlen($password) > 72
    || !preg_match('/[A-Z]/', $password)
    || !preg_match('/[a-z]/', $password)
    || !preg_match('/[0-9]/', $password)
) {
    fwrite(STDERR, "password must be 10-72 characters with upper-case, lower-case and a number.\n");
    exit(1);
}
try {
    new DateTimeZone($timezone);
} catch (Exception) {
    fwrite(STDERR, "timezone is not valid.\n");
    exit(1);
}

$roleId = (int) Database::fetchValue("SELECT id FROM roles WHERE name = 'admin' LIMIT 1");
if ($roleId < 1) {
    fwrite(STDERR, "Admin role is missing. Run database/install.sql first.\n");
    exit(1);
}

$existing = Database::fetchOne('SELECT id, email FROM users WHERE email = :email LIMIT 1', ['email' => $email]);
$hash = password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
$mustCol = SchemaHelper::columnExists('users', 'must_change_password');

Database::transaction(function () use ($existing, $roleId, $name, $email, $hash, $timezone, $mustCol): void {
    if ($existing !== null) {
        $sql = 'UPDATE users SET role_id = :role_id, role = :role, name = :name, password = :password,
                       timezone = :timezone, status = :status, password_changed_at = NULL';
        if ($mustCol) {
            $sql .= ', must_change_password = 1';
        }
        $sql .= ' WHERE id = :id';
        Database::execute($sql, [
            'role_id'  => $roleId,
            'role'     => 'admin',
            'name'     => $name,
            'password' => $hash,
            'timezone' => $timezone,
            'status'   => 'active',
            'id'       => (int) $existing['id'],
        ]);
    } else {
        $columns = 'role_id, role, name, email, password, timezone, status, password_changed_at';
        $values = ':role_id, :role, :name, :email, :password, :timezone, :status, NULL';
        $params = [
            'role_id'  => $roleId,
            'role'     => 'admin',
            'name'     => $name,
            'email'    => $email,
            'password' => $hash,
            'timezone' => $timezone,
            'status'   => 'active',
        ];
        if ($mustCol) {
            $columns .= ', must_change_password';
            $values .= ', 1';
        }
        Database::execute('INSERT INTO users (' . $columns . ') VALUES (' . $values . ')', $params);
    }

    Database::execute(
        "UPDATE users SET status = 'inactive'
         WHERE email LIKE :pattern AND email <> :email",
        ['pattern' => '%@timetrack.local', 'email' => $email]
    );
});

fwrite(STDOUT, "Go-live complete.\n");
fwrite(STDOUT, "Admin: {$email} (must change password on first login)\n");
fwrite(STDOUT, "Demo @timetrack.local accounts are now inactive (rows kept).\n");
fwrite(STDOUT, "\nChecklist:\n");
fwrite(STDOUT, "  [ ] phpMyAdmin backup taken\n");
fwrite(STDOUT, "  [ ] APP_ENV=production and APP_DEBUG=0\n");
fwrite(STDOUT, "  [ ] APP_KEY set in the host environment\n");
fwrite(STDOUT, "  [ ] Self-hosted assets present under public/assets/vendor and public/assets/fonts\n");
fwrite(STDOUT, "  [ ] Phase 13 migrations 01-09, 15 applied\n");
fwrite(STDOUT, "  [ ] Sign in as the new admin and change the password\n");
fwrite(STDOUT, "  [ ] Confirm demo logins fail\n");
exit(0);
