<?php
/**
 * Front controller: every request enters here (see public/.htaccess).
 *
 * Boot order matters:
 *   constants -> autoloader -> config -> error handling -> security headers
 *   -> request -> session -> routes -> dispatch
 */

declare(strict_types=1);

if (PHP_VERSION_ID < 80200) {
    http_response_code(500);
    exit('PHP 8.2 or newer is required.');
}

define('PUBLIC_PATH', __DIR__);
define('BASE_PATH', dirname(__DIR__));
define('APP_PATH', BASE_PATH . '/app');
define('CONFIG_PATH', BASE_PATH . '/config');
define('STORAGE_PATH', BASE_PATH . '/storage');

/*
 * Dependency-free autoloader. Classes live in a flat folder per layer, so lookup is
 * a short fixed list. Names are restricted to letters/digits, which makes path
 * traversal through a crafted class name impossible. Helpers carry a "Helper"
 * suffix in code (CsrfHelper) but not in the file name (Helpers/Csrf.php).
 */
spl_autoload_register(static function (string $class): void {
    if (!preg_match('/^[A-Za-z][A-Za-z0-9]*$/', $class)) {
        return;
    }

    $names = [$class];
    if (str_ends_with($class, 'Helper')) {
        $names[] = substr($class, 0, -strlen('Helper'));
    }

    foreach (['Core', 'Helpers', 'Middleware', 'Controllers', 'Models'] as $folder) {
        foreach ($names as $name) {
            $file = APP_PATH . '/' . $folder . '/' . $name . '.php';
            if (is_file($file)) {
                require $file;
                return;
            }
        }
    }
});

// Storage is always UTC; conversion to a user's timezone happens only when displaying.
date_default_timezone_set('UTC');

Config::load(require CONFIG_PATH . '/config.php');
Config::set('database', require CONFIG_PATH . '/database.php');

/* ---------------------------------------------------------------- error handling */

$debug = (bool) Config::get('app.debug', false);

if (!is_dir(STORAGE_PATH . '/logs')) {
    @mkdir(STORAGE_PATH . '/logs', 0750, true);
}

error_reporting(E_ALL);
ini_set('display_errors', $debug ? '1' : '0'); // never show PHP errors to visitors in production
ini_set('log_errors', '1');
ini_set('error_log', STORAGE_PATH . '/logs/php-error.log');
ini_set('expose_php', '0');

// Turn warnings and notices into exceptions so problems cannot pass silently.
set_error_handler(static function (int $severity, string $message, string $file, int $line) use ($debug): bool {
    if ((error_reporting() & $severity) === 0) {
        return false; // suppressed with @ or disabled
    }

    if ($severity === E_DEPRECATED || $severity === E_USER_DEPRECATED) {
        LoggerHelper::warning('Deprecated: ' . $message, ['file' => basename($file) . ':' . $line]);
        return true;
    }

    if (!$debug && ($severity === E_WARNING || $severity === E_NOTICE || $severity === E_USER_WARNING || $severity === E_USER_NOTICE || $severity === E_STRICT)) {
        LoggerHelper::warning($message, ['file' => basename($file) . ':' . $line]);
        return true;
    }

    throw new ErrorException($message, 0, $severity, $file, $line);
});

// Last line of defence for failures outside the Router (config errors, bad bootstrap).
set_exception_handler(static function (Throwable $e) use ($debug): void {
    LoggerHelper::exception($e);

    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: text/plain; charset=utf-8');
    }

    echo $debug ? $e::class . ': ' . $e->getMessage() : 'Server error. Please try again later.';
});

/* ------------------------------------------------------------ security headers */

header_remove('X-Powered-By');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(), microphone=(), camera=()');
header('Cross-Origin-Opener-Policy: same-origin');

$csp = (string) Config::get('security.csp', '');
if ($csp !== '') {
    header('Content-Security-Policy: ' . $csp);
}

/* --------------------------------------------------------------------- request */

try {
    $request = Request::capture();
} catch (HttpException $e) {
    Response::error($e->status(), $e->getMessage(), false);
}

$allowedHosts = array_map('strtolower', (array) Config::get('app.allowed_hosts', []));
if ($allowedHosts !== [] && !in_array(explode(':', $request->host())[0], $allowedHosts, true)) {
    Response::error(400, 'Invalid host.', false);
}

if ($request->isHttps()) {
    // Tell browsers to use HTTPS only. Sent solely over HTTPS, as the spec requires.
    header('Strict-Transport-Security: max-age=31536000');
}

AuthHelper::startSession($request);
FormatHelper::boot(); // also loads the global template helpers (e(), url(), csrf_field() ...)

/* ----------------------------------------------------------------- dispatching */

$router = new Router();
(require BASE_PATH . '/routes/web.php')($router);
$router->run($request);
