-- Rollback of 01_base.sql. Safe to run twice.

SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.table_constraints
        WHERE constraint_schema = @db_name
          AND table_name = 'time_entries'
          AND constraint_name = 'chk_time_entries_ended_after_started'
          AND constraint_type = 'CHECK'
    ),
    'ALTER TABLE `time_entries` DROP CONSTRAINT `chk_time_entries_ended_after_started`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'time_entries'
          AND index_name = 'idx_time_entries_project_started'
    ),
    'ALTER TABLE `time_entries` DROP INDEX `idx_time_entries_project_started`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'time_entries'
          AND index_name = 'idx_time_entries_user_started'
    ),
    'ALTER TABLE `time_entries` DROP INDEX `idx_time_entries_user_started`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
