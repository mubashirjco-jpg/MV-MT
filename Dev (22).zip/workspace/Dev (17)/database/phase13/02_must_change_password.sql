-- TimeTrack Phase 13 / Step 7
-- users.must_change_password tinyint(1) NOT NULL DEFAULT 0.
-- Integrity: a go-live admin cannot use the app until they replace the
-- bootstrap password.

SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'users'
          AND column_name = 'must_change_password'
    ),
    'SELECT 1',
    'ALTER TABLE `users` ADD COLUMN `must_change_password` TINYINT(1) NOT NULL DEFAULT 0 AFTER `password_changed_at`'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
