-- TimeTrack Phase 13 / FIX 4
-- Restore one timesheet per user per period (uq_timesheets_user_period).
-- Preview duplicate periods first. Merge extra Draft/Rejected rows into the
-- keeper (Approved > Submitted > latest id), then restore the unique key.
-- Do NOT run 05_allow_multiple_submission_batches.sql; it dropped this unique key.
-- Integrity: overlapping sheets for the same person and period cannot exist.

SET @db_name := DATABASE();

SELECT user_id, start_date, end_date, COUNT(*) AS sheet_count, GROUP_CONCAT(id ORDER BY id) AS ids
FROM timesheets
GROUP BY user_id, start_date, end_date
HAVING COUNT(*) > 1;

-- Move entries from duplicate sheets onto the keeper, then drop extras.
UPDATE timesheet_entries tse
INNER JOIN timesheets dup ON dup.id = tse.timesheet_id
INNER JOIN (
    SELECT
        t.user_id, t.start_date, t.end_date,
        SUBSTRING_INDEX(
            GROUP_CONCAT(t.id ORDER BY
                CASE t.status WHEN 'Approved' THEN 0 WHEN 'Submitted' THEN 1 WHEN 'Rejected' THEN 2 ELSE 3 END,
                t.id DESC
            ),
            ',', 1
        ) + 0 AS keep_id
    FROM timesheets t
    GROUP BY t.user_id, t.start_date, t.end_date
    HAVING COUNT(*) > 1
) k ON k.user_id = dup.user_id AND k.start_date = dup.start_date AND k.end_date = dup.end_date
SET tse.timesheet_id = k.keep_id
WHERE dup.id <> k.keep_id;

DELETE dup FROM timesheets dup
INNER JOIN (
    SELECT
        t.user_id, t.start_date, t.end_date,
        SUBSTRING_INDEX(
            GROUP_CONCAT(t.id ORDER BY
                CASE t.status WHEN 'Approved' THEN 0 WHEN 'Submitted' THEN 1 WHEN 'Rejected' THEN 2 ELSE 3 END,
                t.id DESC
            ),
            ',', 1
        ) + 0 AS keep_id
    FROM timesheets t
    GROUP BY t.user_id, t.start_date, t.end_date
    HAVING COUNT(*) > 1
) k ON k.user_id = dup.user_id AND k.start_date = dup.start_date AND k.end_date = dup.end_date
WHERE dup.id <> k.keep_id;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.statistics
        WHERE table_schema = @db_name
          AND table_name = 'timesheets'
          AND index_name = 'uq_timesheets_user_period'
    ),
    'SELECT 1',
    'ALTER TABLE `timesheets` ADD UNIQUE KEY `uq_timesheets_user_period` (`user_id`, `start_date`, `end_date`)'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
