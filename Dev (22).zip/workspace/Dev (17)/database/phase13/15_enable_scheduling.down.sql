-- Rollback for 15_enable_scheduling.sql
-- Restores the pre-Step-15 default (module off). Does not delete the row.

START TRANSACTION;

UPDATE workspace_settings
SET setting_value = '0', updated_at = UTC_TIMESTAMP()
WHERE setting_key = 'scheduling_enabled'
  AND setting_value = '1';

COMMIT;
