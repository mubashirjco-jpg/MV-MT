-- Restores time_entries.status / approved_by / approved_at. Does not reverse
-- timesheet rows created by the upgrade.

SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name AND table_name = 'time_entries' AND column_name = 'status'
    ),
    'SELECT 1',
    "ALTER TABLE `time_entries` ADD COLUMN `status` enum('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending'"
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name AND table_name = 'time_entries' AND column_name = 'approved_by'
    ),
    'SELECT 1',
    'ALTER TABLE `time_entries` ADD COLUMN `approved_by` int UNSIGNED DEFAULT NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name AND table_name = 'time_entries' AND column_name = 'approved_at'
    ),
    'SELECT 1',
    'ALTER TABLE `time_entries` ADD COLUMN `approved_at` datetime DEFAULT NULL'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
