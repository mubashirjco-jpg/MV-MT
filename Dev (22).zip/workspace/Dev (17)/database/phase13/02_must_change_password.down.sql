SET @db_name := DATABASE();

SET @sql := IF(
    EXISTS (
        SELECT 1 FROM information_schema.columns
        WHERE table_schema = @db_name
          AND table_name = 'users'
          AND column_name = 'must_change_password'
    ),
    'ALTER TABLE `users` DROP COLUMN `must_change_password`',
    'SELECT 1'
);
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
