<?php
/**
 * Create / edit a user (Phase 9).
 *
 * @var array<string, mixed>|null $user
 * @var list<array<string, mixed>> $roles
 * @var list<string> $timezones
 * @var list<string> $statuses
 * @var string $action
 * @var list<array<string, mixed>> $clients
 * @var list<int> $linkedClientIds
 */

$isEdit = is_array($user);
$val = static fn (string $key, string $default = ''): string => old($key, (string) ($user[$key] ?? $default));
$selectedZone = old('timezone', (string) ($user['timezone'] ?? SettingsService::systemTimezone()));
$selectedRole = old('role', (string) ($user['role'] ?? AuthHelper::ROLE_EMPLOYEE));
$selectedStatus = old('status', (string) ($user['status'] ?? 'active'));
$clients = $clients ?? [];
$linkedClientIds = array_map('intval', $linkedClientIds ?? []);
$postedClients = old('client_ids');
if (is_array($postedClients)) {
    $linkedClientIds = array_map('intval', $postedClients);
}
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading"><?= $isEdit ? 'Edit user' : 'New user' ?></h2>
        <p class="page-lead"><?= $isEdit ? 'Update details, role and account status.' : 'Create an account and choose a starting role.' ?></p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= e(url('/users')) ?>"><i class="fa-solid fa-arrow-left me-1" aria-hidden="true"></i>Back to users</a>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <section class="panel">
            <form method="post" action="<?= e($action) ?>" novalidate data-single-submit class="panel-body">
                <?= csrf_field() ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Full name</label>
                        <input type="text" id="name" name="name" maxlength="120" required autocomplete="name"
                               class="form-control<?= field_error('name') ? ' is-invalid' : '' ?>" value="<?= e($val('name')) ?>">
                        <?php if (field_error('name')): ?><div class="invalid-feedback"><?= e(field_error('name')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" id="email" name="email" maxlength="190" required autocomplete="email"
                               class="form-control<?= field_error('email') ? ' is-invalid' : '' ?>" value="<?= e($val('email')) ?>">
                        <?php if (field_error('email')): ?><div class="invalid-feedback"><?= e(field_error('email')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="password" class="form-label"><?= $isEdit ? 'New password (leave blank to keep)' : 'Temporary password' ?></label>
                        <input type="password" id="password" name="password" autocomplete="new-password"
                               class="form-control<?= field_error('password') ? ' is-invalid' : '' ?>"
                               <?= $isEdit ? '' : 'required' ?> data-password-meter="#password-meter">
                        <?php if (field_error('password')): ?><div class="invalid-feedback"><?= e(field_error('password')) ?></div><?php endif; ?>
                        <div class="strength" id="password-meter" aria-live="polite"><span class="strength-bar"></span><span class="strength-text"></span></div>
                        <div class="form-text">10 to 72 characters with upper-case, lower-case and a number.</div>
                    </div>
                    <div class="col-md-6">
                        <label for="job_title" class="form-label">Job title</label>
                        <input type="text" id="job_title" name="job_title" maxlength="100"
                               class="form-control<?= field_error('job_title') ? ' is-invalid' : '' ?>" value="<?= e($val('job_title')) ?>">
                        <?php if (field_error('job_title')): ?><div class="invalid-feedback"><?= e(field_error('job_title')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="phone" class="form-label">Phone</label>
                        <input type="tel" id="phone" name="phone" maxlength="30" autocomplete="tel"
                               class="form-control<?= field_error('phone') ? ' is-invalid' : '' ?>" value="<?= e($val('phone')) ?>">
                        <?php if (field_error('phone')): ?><div class="invalid-feedback"><?= e(field_error('phone')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="hourly_rate" class="form-label">Hourly rate</label>
                        <input type="number" id="hourly_rate" name="hourly_rate" min="0" step="0.01" inputmode="decimal"
                               class="form-control<?= field_error('hourly_rate') ? ' is-invalid' : '' ?>" value="<?= e($val('hourly_rate', '0')) ?>">
                        <?php if (field_error('hourly_rate')): ?><div class="invalid-feedback"><?= e(field_error('hourly_rate')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="role" class="form-label">Role</label>
                        <select id="role" name="role" class="form-select<?= field_error('role') ? ' is-invalid' : '' ?>" required
                                <?= PermissionHelper::has('roles.manage') ? '' : 'disabled' ?>>
                            <?php foreach ($roles as $role): ?>
                                <option value="<?= e($role['name']) ?>"<?= $selectedRole === (string) $role['name'] ? ' selected' : '' ?>><?= e($role['display_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (!PermissionHelper::has('roles.manage')): ?>
                            <input type="hidden" name="role" value="<?= e($selectedRole) ?>">
                            <div class="form-text">Only administrators can change roles.</div>
                        <?php endif; ?>
                        <?php if (field_error('role')): ?><div class="invalid-feedback"><?= e(field_error('role')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="status" class="form-label">Status</label>
                        <select id="status" name="status" class="form-select<?= field_error('status') ? ' is-invalid' : '' ?>" required
                                <?= PermissionHelper::has('roles.manage') ? '' : 'disabled' ?>>
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?= e($status) ?>"<?= $selectedStatus === $status ? ' selected' : '' ?>><?= e(ucfirst($status)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (!PermissionHelper::has('roles.manage')): ?>
                            <input type="hidden" name="status" value="<?= e($selectedStatus) ?>">
                        <?php endif; ?>
                        <?php if (field_error('status')): ?><div class="invalid-feedback"><?= e(field_error('status')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-12" id="client-picker"<?= $selectedRole === AuthHelper::ROLE_CLIENT ? '' : ' hidden' ?>>
                        <label for="client_ids" class="form-label">Linked clients</label>
                        <select id="client_ids" name="client_ids[]" class="form-select" multiple size="6">
                            <?php foreach ($clients as $client): ?>
                                <option value="<?= (int) $client['id'] ?>"<?= in_array((int) $client['id'], $linkedClientIds, true) ? ' selected' : '' ?>><?= e((string) $client['name']) ?><?= !empty($client['company']) ? ' (' . e((string) $client['company']) . ')' : '' ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="form-text">Required for the client role. The user can only see these clients' projects, tasks and reports.</div>
                    </div>
                    <div class="col-12">
                        <label for="timezone" class="form-label">Timezone</label>
                        <select id="timezone" name="timezone" class="form-select<?= field_error('timezone') ? ' is-invalid' : '' ?>" required>
                            <?php foreach ($timezones as $zone): ?>
                                <option value="<?= e($zone) ?>"<?= $zone === $selectedZone ? ' selected' : '' ?>><?= e(str_replace('_', ' ', $zone)) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('timezone')): ?><div class="invalid-feedback"><?= e(field_error('timezone')) ?></div><?php endif; ?>
                    </div>
                </div>
                <div class="mt-4 d-flex gap-2">
                    <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Save changes' : 'Create user' ?></button>
                    <a class="btn btn-outline-secondary" href="<?= e(url('/users')) ?>">Cancel</a>
                </div>
            </form>
        </section>
    </div>
</div>
<script src="<?= e(asset('js/users-form.js')) ?>"></script>
