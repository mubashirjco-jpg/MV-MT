<?php
/**
 * Detailed timesheet audit: matrix, entries, rejection feedback, approve/reject.
 *
 * @var array<string, mixed> $timesheet
 * @var array<string, mixed> $matrix
 * @var list<array<string, mixed>> $entries
 * @var bool $canDecide
 * @var bool $isOwn
 */

$timesheet = $timesheet ?? [];
$matrix    = $matrix ?? ['days' => [], 'rows' => [], 'column_totals' => [], 'grand_total' => 0, 'billable_total' => 0, 'entry_count' => 0];
$entries   = $entries ?? [];
$canDecide = $canDecide ?? false;
$isOwn     = $isOwn ?? false;
$status    = (string) ($timesheet['status'] ?? Timesheet::STATUS_DRAFT);
$id        = (int) ($timesheet['id'] ?? 0);

$statusClass = static fn (string $s): string => match ($s) {
    Timesheet::STATUS_APPROVED  => 'completed',
    Timesheet::STATUS_REJECTED  => 'cancelled',
    Timesheet::STATUS_SUBMITTED => 'hold',
    default                     => 'planning',
};

$cellHours = static function (int $seconds): string {
    return $seconds > 0 ? FormatHelper::hours($seconds) : '';
};

$startD = DateTimeImmutable::createFromFormat('!Y-m-d', (string) ($timesheet['start_date'] ?? ''));
$endD   = DateTimeImmutable::createFromFormat('!Y-m-d', (string) ($timesheet['end_date'] ?? ''));
$weekLabel = ($startD instanceof DateTimeImmutable && $endD instanceof DateTimeImmutable)
    ? $startD->format('M j') . ' – ' . $endD->format('M j, Y')
    : (string) ($timesheet['start_date'] ?? '');
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading"><?= e((string) ($timesheet['user_name'] ?? 'Timesheet')) ?></h2>
        <p class="page-lead">
            <?= e($weekLabel) ?>
            <span class="status-badge status-<?= e($statusClass($status)) ?> ms-2"><?= e($status) ?></span>
        </p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <?php if ($isOwn): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets?week=' . $timesheet['start_date'])) ?>">My grid</a>
        <?php endif; ?>
        <?php if (PermissionHelper::has('time.approve')): ?>
            <a class="btn btn-outline-secondary" href="<?= e(url('/timesheets/team')) ?>">Approval queue</a>
        <?php endif; ?>
        <?php if ($canDecide): ?>
            <form method="post" action="<?= e(url('/timesheets/' . $id . '/approve')) ?>" class="m-0"
                  data-confirm="Approve this timesheet? Time entries will be locked."
                  data-single-submit>
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-primary">
                    <i class="fa-solid fa-check me-1" aria-hidden="true"></i>Approve
                </button>
            </form>
            <button type="button" class="btn btn-outline-danger"
                    data-bs-toggle="modal"
                    data-bs-target="#rejectTimesheetModal"
                    data-reject-id="<?= $id ?>"
                    data-reject-name="<?= e((string) ($timesheet['user_name'] ?? '')) ?>"
                    data-reject-week="<?= e($weekLabel) ?>">
                Reject
            </button>
        <?php endif; ?>
    </div>
</div>

<?php if ($status === Timesheet::STATUS_REJECTED && !empty($timesheet['rejection_reason'])): ?>
    <div class="alert alert-warning timesheet-reject-alert" role="alert">
        <div class="fw-semibold mb-1"><i class="fa-solid fa-triangle-exclamation me-1" aria-hidden="true"></i>Rejected with feedback</div>
        <p class="mb-1"><?= e((string) $timesheet['rejection_reason']) ?></p>
        <p class="mb-0 small">
            <?php if (!empty($timesheet['approved_by_name'])): ?>
                <?= e((string) $timesheet['approved_by_name']) ?>
                &middot;
            <?php endif; ?>
            <?= e(FormatHelper::datetime((string) ($timesheet['approved_at'] ?? ''), 'M j, Y H:i')) ?>
        </p>
    </div>
<?php endif; ?>

<div class="kpi-grid mb-4">
    <article class="kpi-card">
        <p class="kpi-label">Tracked</p>
        <p class="kpi-value"><?= e(FormatHelper::hours((int) $timesheet['total_seconds'])) ?>h</p>
        <p class="kpi-sub"><?= e(FormatHelper::duration((int) $timesheet['total_seconds'])) ?></p>
    </article>
    <article class="kpi-card">
        <p class="kpi-label">Billable</p>
        <p class="kpi-value"><?= e(FormatHelper::hours((int) $timesheet['billable_seconds'])) ?>h</p>
        <p class="kpi-sub"><?= e(FormatHelper::duration((int) $timesheet['billable_seconds'])) ?></p>
    </article>
    <article class="kpi-card">
        <p class="kpi-label">Submitted</p>
        <p class="kpi-value" style="font-size:1.1rem"><?= e(FormatHelper::datetime((string) ($timesheet['submitted_at'] ?? ''), 'M j, H:i') ?: '—') ?></p>
        <p class="kpi-sub"><?= (int) count($entries) ?> locked entries</p>
    </article>
    <?php if (!empty($timesheet['approved_by_name'])): ?>
        <article class="kpi-card">
            <p class="kpi-label"><?= $status === Timesheet::STATUS_REJECTED ? 'Reviewed by' : 'Approved by' ?></p>
            <p class="kpi-value" style="font-size:1.1rem"><?= e((string) $timesheet['approved_by_name']) ?></p>
            <p class="kpi-sub"><?= e(FormatHelper::datetime((string) ($timesheet['approved_at'] ?? ''), 'M j, Y H:i')) ?></p>
        </article>
    <?php endif; ?>
</div>

<section class="panel timesheet-panel mb-4">
    <div class="panel-head">
        <h2 class="panel-title">Weekly grid</h2>
    </div>
    <?php if (($matrix['rows'] ?? []) === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-clock" aria-hidden="true"></i>
            <p>No time is attached to this timesheet.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table timesheet-matrix mb-0">
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>Task</th>
                        <?php foreach ($matrix['days'] as $day): ?>
                            <th class="text-end<?= !empty($day['is_today']) ? ' is-today' : '' ?>">
                                <?= e($day['label']) ?>
                                <span class="d-block fw-normal"><?= e($day['short']) ?></span>
                            </th>
                        <?php endforeach; ?>
                        <th class="text-end">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($matrix['rows'] as $row): ?>
                        <tr>
                            <td>
                                <a href="<?= e(url('/projects/' . (int) $row['project_id'])) ?>" class="fw-medium"><?= e($row['project_name']) ?></a>
                            </td>
                            <td><?= $row['task_name'] !== '' ? e($row['task_name']) : '—' ?></td>
                            <?php foreach ($matrix['days'] as $day): ?>
                                <?php $secs = (int) ($row['days'][$day['key']] ?? 0); ?>
                                <td class="text-end mono<?= !empty($day['is_today']) ? ' is-today' : '' ?>"><?= e($cellHours($secs)) ?></td>
                            <?php endforeach; ?>
                            <td class="text-end mono fw-semibold"><?= e(FormatHelper::hours((int) $row['total_seconds'])) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
                <tfoot>
                    <tr>
                        <th colspan="2">Daily total</th>
                        <?php foreach ($matrix['days'] as $day): ?>
                            <th class="text-end mono"><?= e($cellHours((int) ($matrix['column_totals'][$day['key']] ?? 0))) ?></th>
                        <?php endforeach; ?>
                        <th class="text-end mono"><?= e(FormatHelper::hours((int) $matrix['grand_total'])) ?></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    <?php endif; ?>
</section>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Entries <span class="count-pill"><?= count($entries) ?></span></h2>
    </div>
    <?php if ($entries === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-rectangle-list" aria-hidden="true"></i>
            <p>No individual entries are linked. If this week was rejected, entries were unlocked for editing.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table mb-0">
                <thead>
                    <tr>
                        <th>When</th>
                        <th>Project</th>
                        <th>Task</th>
                        <th>Duration</th>
                        <th>Billable</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($entries as $entry): ?>
                        <tr>
                            <td>
                                <div><?= e(FormatHelper::datetime((string) $entry['start_time'], 'D M j, H:i')) ?></div>
                                <div class="small text-secondary"><?= e(FormatHelper::datetime((string) $entry['end_time'], 'H:i')) ?></div>
                            </td>
                            <td>
                                <?= e($entry['project_name']) ?>
                                <?php if (!empty($entry['description'])): ?>
                                    <div class="small text-secondary"><?= e($entry['description']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td><?= !empty($entry['task_name']) ? e($entry['task_name']) : '—' ?></td>
                            <td class="mono"><?= e(FormatHelper::duration((int) $entry['duration_seconds'])) ?></td>
                            <td><?= (int) $entry['is_billable'] === 1 ? 'Yes' : 'No' ?></td>
                            <td>
                                <?php
                                $entryStatus = (string) ($timesheet['status'] ?? Timesheet::STATUS_DRAFT);
                                $entryClass  = match ($entryStatus) {
                                    Timesheet::STATUS_APPROVED => 'completed',
                                    Timesheet::STATUS_REJECTED => 'cancelled',
                                    Timesheet::STATUS_SUBMITTED => 'hold',
                                    default                    => 'planning',
                                };
                                ?>
                                <span class="status-badge status-<?= e($entryClass) ?>"><?= e($entryStatus) ?></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php if ($canDecide): ?>
<div class="modal fade" id="rejectTimesheetModal" tabindex="-1" aria-labelledby="rejectTimesheetTitle" aria-hidden="true">
    <div class="modal-dialog">
        <form method="post" action="<?= e(url('/timesheets/' . $id . '/reject')) ?>" id="rejectTimesheetForm" data-single-submit>
            <?= csrf_field() ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title fs-5" id="rejectTimesheetTitle">Reject timesheet</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="text-secondary" id="rejectTimesheetLead">Send this timesheet back with a note so <?= e((string) ($timesheet['user_name'] ?? 'the person')) ?> can edit it.</p>
                    <label for="reject_reason" class="form-label">Reason</label>
                    <textarea id="reject_reason" name="reason" class="form-control<?= field_error('reason') ? ' is-invalid' : '' ?>" rows="4" required maxlength="500"
                              placeholder="What needs to change?"><?= e(old('reason')) ?></textarea>
                    <?php if (field_error('reason')): ?>
                        <div class="invalid-feedback"><?= e(field_error('reason')) ?></div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Reject timesheet</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
