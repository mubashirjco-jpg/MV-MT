<?php
/**
 * Blocks client-role users from timer, timesheets, writes, and admin pages.
 *
 * Integrity: hiding a sidebar item is not enough; a crafted URL must still 403.
 */

declare(strict_types=1);

final class ClientScopeMiddleware
{
    /** @var list<string> prefixes a client may never open */
    private const BLOCKED_PREFIXES = [
        '/time',
        '/timesheets',
        '/users',
        '/workspace',
        '/settings',
        '/import',
        '/agent',
        '/clients',
        '/team',
        '/admin/health',
    ];

    private const WRITE_ALLOWED = [
        '/profile',
        '/profile/password',
        '/logout',
        '/notifications/read',
        '/notifications/read-all',
    ];

    public function handle(Request $request): void
    {
        if (!ClientScope::isClient()) {
            return;
        }

        $path = $request->path();
        $method = $request->method();

        foreach (self::BLOCKED_PREFIXES as $prefix) {
            if ($path === $prefix || str_starts_with($path, $prefix . '/')) {
                throw new HttpException(403, 'Client accounts cannot access this page.');
            }
        }

        if ($method !== 'GET' && $method !== 'HEAD') {
            foreach (self::WRITE_ALLOWED as $allowed) {
                if ($path === $allowed || (str_starts_with($allowed, '/notifications') && str_starts_with($path, '/notifications/'))) {
                    return;
                }
            }
            if (preg_match('#^/notifications/\d+/read$#', $path) === 1) {
                return;
            }
            ClientScope::assertReadOnly();
        }
    }
}
