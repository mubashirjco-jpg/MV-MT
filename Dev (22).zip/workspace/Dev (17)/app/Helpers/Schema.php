<?php
/**
 * Cached table/column existence checks. One information_schema query per table
 * per request (optional APCu cache for 5 minutes).
 */

declare(strict_types=1);

final class SchemaHelper
{
    private const APCU_TTL = 300;

    /** @var array<string, bool> */
    private static array $tables = [];

    /** @var array<string, array<string, true>> */
    private static array $columns = [];

    public static function tableExists(string $table): bool
    {
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $table)) {
            return false;
        }

        if (array_key_exists($table, self::$tables)) {
            return self::$tables[$table];
        }

        $cacheKey = 'tt.schema.table.' . $table;
        $cached = self::apcuGet($cacheKey);
        if (is_bool($cached)) {
            return self::$tables[$table] = $cached;
        }

        try {
            $exists = (int) Database::fetchValue(
                'SELECT COUNT(*) FROM information_schema.tables
                 WHERE table_schema = DATABASE() AND table_name = :t',
                ['t' => $table]
            ) > 0;
        } catch (Throwable $e) {
            LoggerHelper::debug('Schema table check failed', ['table' => $table, 'error' => $e->getMessage()]);
            $exists = false;
        }

        self::apcuSet($cacheKey, $exists);
        return self::$tables[$table] = $exists;
    }

    public static function columnExists(string $table, string $column): bool
    {
        return isset(self::columns($table)[$column]);
    }

    /**
     * @return array<string, true> column name => true
     */
    public static function columns(string $table): array
    {
        if (!preg_match('/^[A-Za-z_][A-Za-z0-9_]*$/', $table)) {
            return [];
        }

        if (isset(self::$columns[$table])) {
            return self::$columns[$table];
        }

        $cacheKey = 'tt.schema.columns.' . $table;
        $cached = self::apcuGet($cacheKey);
        if (is_array($cached)) {
            return self::$columns[$table] = $cached;
        }

        $map = [];
        try {
            $rows = Database::fetchAll(
                'SELECT COLUMN_NAME AS name FROM information_schema.columns
                 WHERE table_schema = DATABASE() AND table_name = :t',
                ['t' => $table]
            );
            foreach ($rows as $row) {
                $map[(string) $row['name']] = true;
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('Schema column check failed', ['table' => $table, 'error' => $e->getMessage()]);
        }

        self::apcuSet($cacheKey, $map);
        return self::$columns[$table] = $map;
    }

    /** @return list<string> */
    public static function requiredMissing(): array
    {
        $required = [
            'time_entries' => ['auto_stopped', 'started_at', 'ended_at', 'billable_rate'],
            'permissions' => ['name'],
            'tasks' => ['status', 'project_id', 'name'],
            'task_assignees' => ['task_id', 'user_id'],
            'activity_logs' => ['action', 'entity_id'],
            'desktop_agent_devices' => ['token_hash', 'status'],
            'desktop_agent_pairing_codes' => ['code_hash', 'attempts'],
            'timer_idle_events' => ['timer_id', 'response'],
            'users' => ['must_change_password'],
            'client_users' => ['user_id', 'client_id'],
        ];

        $missing = [];
        foreach ($required as $table => $cols) {
            if (!self::tableExists($table)) {
                $missing[] = $table;
                continue;
            }
            foreach ($cols as $col) {
                if (!self::columnExists($table, $col)) {
                    $missing[] = $table . '.' . $col;
                }
            }
        }

        return $missing;
    }

    private static function apcuGet(string $key): mixed
    {
        if (!function_exists('apcu_fetch')) {
            return null;
        }
        $ok = false;
        $value = apcu_fetch($key, $ok);
        return $ok ? $value : null;
    }

    private static function apcuSet(string $key, mixed $value): void
    {
        if (function_exists('apcu_store')) {
            apcu_store($key, $value, self::APCU_TTL);
        }
    }
}
