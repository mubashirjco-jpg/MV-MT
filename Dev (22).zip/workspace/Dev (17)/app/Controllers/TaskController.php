<?php
/**
 * Standalone task management: list, create, view, edit, status, delete.
 *
 * Tasks still belong to a project. The project page Tasks tab remains a shortcut
 * into this module. Employees see their own tasks; managers/admins can see all
 * tasks on projects they can view.
 */

declare(strict_types=1);

final class TaskController extends Controller
{
    private Task $tasks;
    private Project $projects;
    private ProjectMember $members;

    public function __construct()
    {
        parent::__construct(true);
        FeatureFlagsHelper::requireProjects();
        $this->tasks    = new Task();
        $this->projects = new Project();
        $this->members  = new ProjectMember();
    }

    /** GET /tasks  (My Tasks vs All Tasks based on role) */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.view');
        $this->requireInstalled();

        $userId  = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('projects.view_all')
            || AuthHelper::hasRole(AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER);
        $defaultScope = $viewAll && PermissionHelper::has('tasks.assign') ? 'all' : 'mine';
        $scope = (string) $request->input('scope', $defaultScope);
        if (!in_array($scope, ['mine', 'all'], true)) {
            $scope = $defaultScope;
        }
        if ($scope === 'all' && !$viewAll) {
            $scope = 'mine';
        }

        $viewMode = (string) $request->input('view', 'list');
        if (!in_array($viewMode, ['list', 'kanban'], true)) {
            $viewMode = 'list';
        }

        $filters = [
            'scope'       => $scope,
            'project_id'  => (int) $request->input('project_id', 0),
            'assigned_to' => (int) $request->input('assigned_to', 0),
            'status'      => (string) $request->input('status', ''),
            'priority'    => (string) $request->input('priority', ''),
            'due'         => (string) $request->input('due', ''),
            'q'           => trim((string) $request->input('q', '')),
            'sort'        => (string) $request->input('sort', 'due'),
            'dir'         => strtolower((string) $request->input('dir', 'asc')) === 'desc' ? 'desc' : 'asc',
        ];

        $result = $this->tasks->listFiltered(
            $filters,
            (int) $request->input('page', 1),
            25,
            $userId,
            $viewAll
        );

        $kanban = $viewMode === 'kanban'
            ? $this->tasks->kanbanColumns($filters, $userId, $viewAll)
            : [];

        $this->render('tasks/index', [
            'pageTitle'   => 'Tasks',
            'result'      => $result,
            'kanban'      => $kanban,
            'filters'     => $filters,
            'viewMode'    => $viewMode,
            'scope'       => $scope,
            'viewAll'     => $viewAll,
            'projects'    => $this->visibleProjects($userId, $viewAll),
            'people'      => $this->assignablePeople(),
            'statuses'    => Task::STATUSES,
            'priorities'  => Task::PRIORITIES,
            'canCreate'   => WorkspacePolicy::canCreateTask(),
            'canEdit'     => PermissionHelper::has('tasks.edit'),
            'canDelete'   => PermissionHelper::has('tasks.delete'),
            'canAssign'   => PermissionHelper::has('tasks.assign'),
            'canTrack'    => PermissionHelper::has('time.track') && Timer::installed() && FeatureFlagsHelper::trackerVisible(),
            'userId'      => $userId,
        ]);
    }

    /** GET /tasks/create  (optional ?project_id=&parent_task_id=) */
    public function create(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.create');
        WorkspacePolicy::requireCanCreateTask();
        $this->requireInstalled();

        $projectId = (int) $request->input('project_id', 0);
        $parentId  = (int) $request->input('parent_task_id', 0);
        $project   = $projectId > 0 ? $this->loadVisibleProject($projectId) : null;
        $parent    = null;

        if ($parentId > 0) {
            $parent = $this->tasks->findDetailed($parentId);
            if ($parent === null) {
                $this->notFound();
            }
            $project = $this->loadVisibleProject((int) $parent['project_id']);
            $projectId = (int) $project['id'];
        }

        $this->render('tasks/create', $this->formData([
            'pageTitle'   => $parent ? 'New subtask' : 'New task',
            'task'        => $this->blankTask($projectId, $parentId > 0 ? $parentId : null),
            'formAction'  => url('/tasks'),
            'submitLabel' => $parent ? 'Create subtask' : 'Create task',
            'isEdit'      => false,
            'parent'      => $parent,
            'project'     => $project,
        ]));
    }

    /** POST /tasks  and POST /projects/{id}/tasks */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.create');
        // task_creation_policy is a second gate so a crafted POST cannot skip the workspace rule.
        WorkspacePolicy::requireCanCreateTask();
        $this->requireInstalled();

        $projectId = (int) ($params['id'] ?? $request->input('project_id', 0));
        $failPath  = '/tasks/create' . ($projectId > 0 ? '?project_id=' . $projectId : '');
        $parentId  = (int) $request->input('parent_task_id', 0);
        if ($parentId > 0) {
            $failPath .= (str_contains($failPath, '?') ? '&' : '?') . 'parent_task_id=' . $parentId;
        }

        $project = $this->loadVisibleProject($projectId);
        $this->assertProjectOpen($project, $failPath);

        $data = $this->validatedTask($failPath, $project);

        if ($this->tasks->nameTaken(
            (int) $project['id'],
            $data['name'],
            null,
            $data['parent_task_id']
        )) {
            $this->backWithErrors($failPath, ['name' => 'A task with this name already exists at this level.']);
        }

        $id = $this->tasks->create([
            'project_id'         => (int) $project['id'],
            'parent_task_id'     => $data['parent_task_id'],
            'name'               => $data['name'],
            'description'        => $data['description'],
            'status'             => $data['status'],
            'priority'           => $data['priority'],
            'estimated_hours'    => $data['estimated_hours'],
            'completion_percent' => $data['completion_percent'],
            'start_date'         => $data['start_date'],
            'due_date'           => $data['due_date'],
            'is_billable'        => $data['is_billable'],
            'created_by'         => (int) AuthHelper::id(),
        ]);

        $assigneeIds = $this->resolveAssignees((int) $project['id'], $data['assigned_to']);
        if ($assigneeIds !== []) {
            try {
                TimeTrackingRules::assertAssignable($project, $assigneeIds);
            } catch (HttpException $e) {
                $this->backWithErrors($failPath, ['assigned_to' => $e->getMessage()]);
            }
            $this->tasks->syncAssignees(
                $id,
                $assigneeIds,
                $this->assignableIds($project)
            );
        }

        if ($data['parent_task_id'] !== null) {
            $this->tasks->recalculateAncestors($id);
        }

        LoggerHelper::audit('task.created', 'task', $id, [
            'project_id' => (int) $project['id'],
            'name'       => $data['name'],
        ]);
        $this->notifyAssignees(
            $assigneeIds,
            (string) $data['name'],
            $id,
            (int) $project['id'],
            (string) ($project['name'] ?? '')
        );

        $this->flash('success', 'Task "' . $data['name'] . '" was added.');
        $this->redirect($this->afterSavePath($request, $id, (int) $project['id']));
    }

    /** GET /tasks/{id} */
    public function view(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.view');
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $tree     = $this->tasks->treeFrom($task);
        $children = $tree['children'] ?? $this->tasks->childrenOf((int) $task['id']);
        $hours    = $this->tasks->hoursFor((int) $task['id']);
        $archived = (string) $project['status'] === Project::STATUS_ARCHIVED;

        $this->render('tasks/view', [
            'pageTitle'      => (string) $task['name'],
            'task'           => array_merge($task, $hours),
            'project'        => $project,
            'tree'           => $tree,
            'children'       => $children,
            'members'        => $this->members->forProject((int) $project['id']),
            'timeLog'        => $this->tasks->timeLog((int) $task['id']),
            'scheduleLog'    => $this->tasks->scheduleHistory((int) $task['id']),
            'statuses'       => Task::STATUSES,
            'canEdit'        => PermissionHelper::has('tasks.edit'),
            'canDelete'      => PermissionHelper::has('tasks.delete'),
            'canAssign'      => PermissionHelper::has('tasks.assign'),
            'canCreate'      => WorkspacePolicy::canCreateTask() && !$archived,
            'canTrack'       => PermissionHelper::has('time.track') && Timer::installed() && !$archived && FeatureFlagsHelper::trackerVisible(),
            'canManual'      => PermissionHelper::has('time.edit_own') && TimeEntry::installed() && !$archived && FeatureFlagsHelper::allowManual() && FeatureFlagsHelper::trackerVisible(),
            'canSchedule'    => PermissionHelper::has('schedule.create') && !$archived && FeatureFlagsHelper::schedulingEnabled(),
            'trackProjects'  => $this->trackableProjects(),
        ]);
    }

    /** GET /tasks/{id}/edit */
    public function edit(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.edit');
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));

        $this->render('tasks/edit', $this->formData([
            'pageTitle'   => 'Edit task',
            'task'        => $task,
            'formAction'  => url('/tasks/' . (int) $task['id']),
            'submitLabel' => 'Save changes',
            'isEdit'      => true,
            'parent'      => $task['parent_task_id'] ? $this->tasks->findDetailed((int) $task['parent_task_id']) : null,
            'project'     => $project,
        ]));
    }

    /** POST /tasks/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.edit');
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $failPath = '/tasks/' . (int) $task['id'] . '/edit';

        $data = $this->validatedTask($failPath, $project, (int) $task['id']);
        $oldParentId = $this->parentId($task);

        if (Task::isDone((string) $task['status']) && (string) $data['name'] !== (string) $task['name']) {
            $this->backWithErrors($failPath, ['name' => 'Completed tasks cannot be renamed. Mark the task active first.']);
        }

        if ($this->tasks->nameTaken(
            (int) $project['id'],
            $data['name'],
            (int) $task['id'],
            $data['parent_task_id']
        )) {
            $this->backWithErrors($failPath, ['name' => 'A task with this name already exists at this level.']);
        }

        $this->tasks->update((int) $task['id'], [
            'parent_task_id'     => $data['parent_task_id'],
            'name'               => $data['name'],
            'description'        => $data['description'],
            'status'             => $data['status'],
            'priority'           => $data['priority'],
            'estimated_hours'    => $data['estimated_hours'],
            'completion_percent' => $data['completion_percent'],
            'start_date'         => $data['start_date'],
            'due_date'           => $data['due_date'],
            'is_billable'        => $data['is_billable'],
        ]);

        $assigneeIds = $this->resolveAssignees((int) $project['id'], $data['assigned_to']);
        if (PermissionHelper::has('tasks.assign')) {
            try {
                TimeTrackingRules::assertAssignable($project, $assigneeIds);
            } catch (HttpException $e) {
                $this->backWithErrors($failPath, ['assigned_to' => $e->getMessage()]);
            }
            $this->tasks->syncAssignees(
                (int) $task['id'],
                $assigneeIds,
                $this->assignableIds($project)
            );
        }

        $this->tasks->recalculateAncestors((int) $task['id']);
        if ($oldParentId !== null && $oldParentId !== $data['parent_task_id']) {
            // The task moved: its previous parent lost a child and must be recalculated too.
            $this->tasks->refreshFrom($oldParentId);
        }

        LoggerHelper::audit('task.updated', 'task', (int) $task['id'], ['name' => $data['name']]);
        $this->notifyAssignees(
            $assigneeIds,
            (string) $data['name'],
            (int) $task['id'],
            (int) $project['id'],
            (string) ($project['name'] ?? '')
        );

        $this->flash('success', 'Task "' . $data['name'] . '" was updated.');
        $this->redirect($this->afterSavePath($request, (int) $task['id'], (int) $project['id']));
    }

    /** POST /tasks/{id}/status  (AJAX or form: status + optional completion %) */
    public function updateStatus(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.edit');
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $status  = Task::normalizeStatus((string) $request->input('status', ''));
        $percent = $request->input('completion_percent', null);

        if (!in_array($status, Task::STATUSES, true)) {
            if ($request->wantsJson() || $request->isAjax()) {
                $this->json(['ok' => false, 'message' => 'Choose a valid task status.'], 422);
            }
            $this->flash('danger', 'Choose a valid task status.');
            $this->redirect('/tasks/' . (int) $task['id']);
        }

        $pct = $percent === null || $percent === '' ? null : (int) $percent;
        $this->tasks->setStatus((int) $task['id'], $status, $pct);

        LoggerHelper::audit('task.status_changed', 'task', (int) $task['id'], [
            'from' => (string) $task['status'],
            'to'   => $status,
        ]);

        $fresh = $this->tasks->findDetailed((int) $task['id']) ?? $task;
        $pctOut = (int) ($fresh['completion_percent'] ?? Task::percentForStatus($status));

        if ($request->wantsJson() || $request->isAjax()) {
            $this->json([
                'ok'                 => true,
                'status'             => $status,
                'completion_percent' => $pctOut,
                'status_css'         => Task::statusCss($status),
            ]);
        }

        $this->flash('success', '"' . $task['name'] . '" is now ' . $status . '.');
        $back = (string) $request->input('back', '');
        $this->redirect($back !== '' ? $back : '/tasks/' . (int) $task['id']);
    }

    /** POST /tasks/{id}/status  (legacy alias used by the project tab) */
    public function status(Request $request, array $params): void
    {
        $this->updateStatus($request, $params);
    }

    /** POST /tasks/{id}/rename (inline edit on the project Tasks tab, JSON) */
    public function rename(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.edit');

        [$task] = $this->loadTask((int) ($params['id'] ?? 0));
        $name = trim((string) $request->input('name', ''));

        if ($name === '' || mb_strlen($name) > 180) {
            $this->json(['ok' => false, 'message' => 'Task name must be 1 to 180 characters.', 'name' => (string) $task['name']], 422);
        }

        if ($name !== (string) $task['name']) {
            if (Task::isDone((string) $task['status'])) {
                $this->json(['ok' => false, 'message' => 'Completed tasks cannot be renamed. Mark the task active first.', 'name' => (string) $task['name']], 422);
            }
            if ($this->tasks->nameTaken((int) $task['project_id'], $name, (int) $task['id'], $this->parentId($task))) {
                $this->json(['ok' => false, 'message' => 'A task with this name already exists.', 'name' => (string) $task['name']], 422);
            }

            $this->tasks->update((int) $task['id'], ['name' => $name]);
            LoggerHelper::audit('task.updated', 'task', (int) $task['id'], ['name' => $name]);
        }

        $this->json(['ok' => true, 'name' => $name]);
    }

    /** POST /tasks/{id}/assignees (inline assignee picker on the project Tasks tab, JSON) */
    public function assignees(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.assign');

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));

        $assigneeIds = $this->postedAssigneeIds();
        try {
            TimeTrackingRules::assertAssignable($project, $assigneeIds);
        } catch (HttpException $e) {
            $this->json(['ok' => false, 'message' => $e->getMessage()], 422);
        }
        $this->tasks->syncAssignees((int) $task['id'], $assigneeIds, $this->assignableIds($project));

        $names = [];
        foreach ($this->members->forProject((int) $project['id']) as $member) {
            if (in_array((int) $member['user_id'], $assigneeIds, true)) {
                $names[] = (string) $member['name'];
            }
        }
        sort($names, SORT_NATURAL | SORT_FLAG_CASE);

        LoggerHelper::audit('task.updated', 'task', (int) $task['id'], [
            'name'      => (string) $task['name'],
            'assignees' => count($assigneeIds),
        ]);
        $this->notifyAssignees(
            $assigneeIds,
            (string) $task['name'],
            (int) $task['id'],
            (int) $project['id'],
            (string) ($project['name'] ?? '')
        );

        $this->json(['ok' => true, 'names' => $names]);
    }

    /** POST /tasks/{id}/delete */
    public function delete(Request $request, array $params): void
    {
        $this->destroy($request, $params);
    }

    /** POST /tasks/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.delete');
        $this->requireInstalled();

        [$task, $project] = $this->loadTask((int) ($params['id'] ?? 0));
        $parentId = $this->parentId($task);

        $this->tasks->deleteWithLinks((int) $task['id']);

        if ($parentId !== null) {
            $this->tasks->refreshFrom($parentId);
        }

        LoggerHelper::audit('task.deleted', 'task', (int) $task['id'], [
            'project_id' => (int) $project['id'],
            'name'       => (string) $task['name'],
        ]);
        $this->flash('success', 'Task "' . $task['name'] . '" was deleted.');

        $back = (string) $request->input('back', '');
        if ($back !== '') {
            $this->redirect($back);
        }
        if ($parentId !== null) {
            $this->redirect('/tasks/' . $parentId);
        }
        $this->redirect('/tasks');
    }

    /** JSON: parent-task options for a project (used by the create/edit form). */
    public function parentsJson(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.view');
        $this->requireInstalled();

        $projectId = (int) $request->input('project_id', 0);
        $excludeId = (int) $request->input('exclude', 0);
        $project   = $this->loadVisibleProject($projectId);
        $options   = $this->tasks->parentOptions((int) $project['id'], $excludeId > 0 ? $excludeId : null);
        $flat      = $this->tasks->flatten($this->tasks->nest($options));

        $out = [];
        foreach ($flat as $row) {
            $out[] = [
                'id'    => (int) $row['id'],
                'name'  => (string) $row['name'],
                'depth' => (int) ($row['depth'] ?? 0),
            ];
        }

        $this->json(['ok' => true, 'parents' => $out]);
    }

    /** JSON: members of a project (assignee choices). */
    public function membersJson(Request $request, array $params): void
    {
        PermissionHelper::require('tasks.view');

        $project = $this->loadVisibleProject((int) $request->input('project_id', 0));
        $members = [];
        foreach ($this->members->forProject((int) $project['id']) as $member) {
            if ((string) ($member['status'] ?? 'active') !== 'active') {
                continue;
            }
            if (strtolower((string) ($member['project_role'] ?? '')) === ProjectMember::ROLE_VIEWER) {
                continue;
            }
            $members[] = [
                'id'   => (int) $member['user_id'],
                'name' => (string) $member['name'],
            ];
        }

        // The project manager is assignable even when not listed as a member.
        $managerId = (int) ($project['manager_id'] ?? 0);
        if ($managerId > 0 && !in_array($managerId, array_column($members, 'id'), true)) {
            $manager = Database::fetchOne(
                "SELECT id, name FROM users WHERE id = :id AND status = 'active'",
                ['id' => $managerId]
            );
            if ($manager !== null) {
                $members[] = ['id' => (int) $manager['id'], 'name' => (string) $manager['name']];
            }
        }

        $this->json(['ok' => true, 'members' => $members]);
    }

    private function requireInstalled(): void
    {
        if (!Task::installed()) {
            $this->flash('warning', 'Tasks are not installed yet. Import database/schema.sql or database/phase5.sql.');
            $this->redirect('/dashboard');
        }
    }

    /** @return array<string, mixed> */
    private function loadVisibleProject(int $id): array
    {
        if ($id < 1) {
            $this->notFound();
        }

        $project = $this->projects->findWithRelations($id);
        if ($project === null) {
            $this->notFound();
        }

        if (!$this->projects->userCanView($project, (int) AuthHelper::id(), PermissionHelper::has('projects.view_all'))) {
            $this->forbidden();
        }
        ClientScope::assertCanSeeProject($project);

        return $project;
    }

    /** @return array{0: array<string, mixed>, 1: array<string, mixed>} [task, project] */
    private function loadTask(int $id): array
    {
        if ($id < 1 || !Task::installed()) {
            $this->notFound();
        }

        $task = $this->tasks->findDetailed($id) ?? $this->tasks->find($id);
        if ($task === null) {
            $this->notFound();
        }

        return [$task, $this->loadVisibleProject((int) $task['project_id'])];
    }

    /** @param array<string, mixed> $project */
    private function assertProjectOpen(array $project, string $back): void
    {
        if ((string) $project['status'] === Project::STATUS_ARCHIVED) {
            $this->flash('danger', 'Archived projects cannot receive new tasks.');
            $this->redirect($back);
        }
    }

    /**
     * @param array<string, mixed> $project
     * @return array<string, mixed>
     */
    private function validatedTask(string $failPath, array $project, ?int $ignoreId = null): array
    {
        $statusList   = implode(',', Task::STATUSES);
        $priorityList = implode(',', Task::PRIORITIES);

        $data = $this->validate([
            'name'               => 'required|string|max:180',
            'description'        => 'nullable|string|max:5000',
            'status'             => 'nullable|in:' . $statusList,
            'priority'           => 'nullable|in:' . $priorityList,
            'parent_task_id'     => 'nullable|int',
            'assigned_to'        => 'nullable|int',
            'estimated_hours'    => 'nullable|numeric|min:0|max:9999',
            'completion_percent' => 'nullable|int|min:0|max:100',
            'start_date'         => 'nullable|date',
            'due_date'           => 'nullable|date',
            'is_billable'        => 'nullable|boolean',
        ], $failPath, [
            'name'               => 'Task name',
            'description'        => 'Description',
            'status'             => 'Status',
            'priority'           => 'Priority',
            'parent_task_id'     => 'Parent task',
            'assigned_to'        => 'Assignee',
            'estimated_hours'    => 'Estimated hours',
            'completion_percent' => 'Completion',
            'start_date'         => 'Start date',
            'due_date'           => 'Due date',
            'is_billable'        => 'Billable',
        ]);

        $status = Task::normalizeStatus((string) ($data['status'] ?? Task::STATUS_TODO));
        if (!in_array($status, Task::STATUSES, true)) {
            $status = Task::STATUS_TODO;
        }

        $parentId = isset($data['parent_task_id']) && (int) $data['parent_task_id'] > 0
            ? (int) $data['parent_task_id'] : null;
        if ($parentId !== null) {
            $parent = $this->tasks->find($parentId);
            if ($parent === null || (int) $parent['project_id'] !== (int) $project['id']) {
                $this->backWithErrors($failPath, ['parent_task_id' => 'Choose a parent task from the same project.']);
            }
            if ($ignoreId !== null && $parentId === $ignoreId) {
                $this->backWithErrors($failPath, ['parent_task_id' => 'A task cannot be its own parent.']);
            }
            if ($ignoreId !== null) {
                $blocked = $this->tasks->parentOptions((int) $project['id'], $ignoreId);
                $ok = false;
                foreach ($blocked as $option) {
                    if ((int) $option['id'] === $parentId) {
                        $ok = true;
                        break;
                    }
                }
                if (!$ok) {
                    $this->backWithErrors($failPath, ['parent_task_id' => 'A task cannot be nested under one of its own subtasks.']);
                }
            }
        }

        $assignedTo = isset($data['assigned_to']) && (int) $data['assigned_to'] > 0
            ? (int) $data['assigned_to'] : null;
        if ($assignedTo !== null && !in_array($assignedTo, $this->assignableIds($project), true)) {
            $this->backWithErrors($failPath, ['assigned_to' => 'Assignee must be a member of the project.']);
        }

        $startDate = isset($data['start_date']) && $data['start_date'] !== '' ? (string) $data['start_date'] : null;
        $dueDate   = isset($data['due_date']) && $data['due_date'] !== '' ? (string) $data['due_date'] : null;
        if ($startDate !== null && $dueDate !== null && $dueDate < $startDate) {
            $this->backWithErrors($failPath, ['due_date' => 'Due date cannot be before the start date.']);
        }

        $percent = isset($data['completion_percent']) ? (int) $data['completion_percent'] : Task::percentForStatus($status);
        if ($status === Task::STATUS_COMPLETED) {
            $percent = 100;
        } elseif ($status === Task::STATUS_TODO && $percent === 0) {
            $percent = 0;
        }

        $billable = $data['is_billable'] ?? null;
        $isBillable = in_array($billable, [1, '1', true, 'true', 'on', 'yes'], true) ? 1 : 0;
        if ($billable === null) {
            $isBillable = (int) ($project['is_billable'] ?? 0) === 1 ? 1 : 0;
        }

        return [
            'name'               => (string) $data['name'],
            'description'        => isset($data['description']) && $data['description'] !== '' ? (string) $data['description'] : null,
            'status'             => $status,
            'priority'           => in_array((string) ($data['priority'] ?? ''), Task::PRIORITIES, true)
                ? (string) $data['priority'] : Task::PRIORITY_MEDIUM,
            'parent_task_id'     => $parentId,
            'assigned_to'        => $assignedTo,
            'estimated_hours'    => isset($data['estimated_hours']) ? (float) $data['estimated_hours'] : 0,
            'completion_percent' => max(0, min(100, $percent)),
            'start_date'         => $startDate,
            'due_date'           => $dueDate,
            'is_billable'        => $isBillable,
        ];
    }

    /** @return list<int> */
    private function postedAssigneeIds(): array
    {
        $raw = $this->request->input('assignee_ids', []);
        if (!is_array($raw)) {
            $raw = $raw === null || $raw === '' ? [] : [$raw];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * Users who may be assigned work on a project: non-viewer members plus its manager.
     *
     * @param array<string, mixed> $project
     * @return list<int>
     */
    private function assignableIds(array $project): array
    {
        return TimeTrackingRules::assignableUserIds($project);
    }

    /**
     * @return list<int>
     */
    private function resolveAssignees(int $projectId, ?int $assignedTo): array
    {
        $ids = $this->postedAssigneeIds();
        if ($ids === [] && $assignedTo !== null && PermissionHelper::has('tasks.assign')) {
            $ids = [$assignedTo];
        } elseif ($ids === [] && $assignedTo !== null) {
            $ids = [$assignedTo];
        }

        if (!PermissionHelper::has('tasks.assign') && $ids === [] && $assignedTo === null) {
            return [];
        }

        return $ids;
    }

    /**
     * @param list<int> $assigneeIds
     */
    private function notifyAssignees(array $assigneeIds, string $taskName, int $taskId, int $projectId, string $projectName): void
    {
        $actor = (int) AuthHelper::id();

        foreach ($assigneeIds as $assigneeId) {
            if ($assigneeId === $actor) {
                continue;
            }
            NotificationHelper::taskAssigned($assigneeId, $taskName, $taskId, $projectId, $projectName);
            LoggerHelper::taskAssigned($taskId, $assigneeId, $taskName, $projectId);
        }
    }

    /**
     * @param array<string, mixed> $extra
     * @return array<string, mixed>
     */
    private function formData(array $extra): array
    {
        $userId  = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('projects.view_all');
        $project = $extra['project'] ?? null;
        $task    = $extra['task'] ?? [];
        $projectId = (int) ($project['id'] ?? $task['project_id'] ?? 0);

        $parents = [];
        $members = [];
        if ($projectId > 0) {
            $exclude = !empty($extra['isEdit']) ? (int) ($task['id'] ?? 0) : 0;
            $parents = $this->tasks->flatten(
                $this->tasks->nest($this->tasks->parentOptions($projectId, $exclude > 0 ? $exclude : null))
            );
            $members = $this->members->forProject($projectId);
        }

        return array_merge([
            'projects'    => $this->visibleProjects($userId, $viewAll, true),
            'parents'     => $parents,
            'members'     => $members,
            'statuses'    => Task::STATUSES,
            'priorities'  => Task::PRIORITIES,
            'canAssign'   => PermissionHelper::has('tasks.assign'),
        ], $extra);
    }

    /**
     * @return array<string, mixed>
     */
    private function blankTask(int $projectId, ?int $parentId): array
    {
        return [
            'id'                 => 0,
            'project_id'         => $projectId,
            'parent_task_id'     => $parentId,
            'name'               => '',
            'description'        => '',
            'status'             => Task::STATUS_TODO,
            'priority'           => Task::PRIORITY_MEDIUM,
            'assigned_to'        => null,
            'estimated_hours'    => '',
            'completion_percent' => 0,
            'start_date'         => '',
            'due_date'           => '',
            'is_billable'        => 1,
            'assignee_ids'       => [],
        ];
    }

    /** @return list<array<string, mixed>> */
    private function visibleProjects(int $userId, bool $viewAll, bool $openOnly = false): array
    {
        $where = [];
        $params = [];

        if ($openOnly) {
            $where[] = "p.status IN ('Planning','Active','On Hold')";
        }

        if (!$viewAll) {
            $where[] = '(p.manager_id = :uid_mgr OR p.created_by = :uid_own
                OR EXISTS (SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :uid_mem))';
            $params['uid_mgr'] = $userId;
            $params['uid_own'] = $userId;
            $params['uid_mem'] = $userId;
        }

        $sql = 'SELECT p.id, p.name, p.project_code, p.status, p.color, p.is_billable, c.name AS client_name
                FROM projects p
                INNER JOIN clients c ON c.id = p.client_id';
        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY p.name ASC';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    private function assignablePeople(): array
    {
        return Database::fetchAll(
            "SELECT u.id, u.name, u.email, r.name AS role
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.status = 'active' AND r.name IN ('admin','manager','employee')
             ORDER BY u.name ASC"
        );
    }

    /** @return list<array<string, mixed>> */
    private function trackableProjects(): array
    {
        if (!class_exists('TimeEntry') || !TimeEntry::installed()) {
            return [];
        }

        try {
            return (new TimeEntry())->trackableProjects(
                (int) AuthHelper::id(),
                PermissionHelper::has('projects.view_all')
            );
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            return [];
        }
    }

    /** @param array<string, mixed> $task */
    private function parentId(array $task): ?int
    {
        if (!isset($task['parent_task_id']) || $task['parent_task_id'] === null || $task['parent_task_id'] === '') {
            return null;
        }
        $id = (int) $task['parent_task_id'];

        return $id > 0 ? $id : null;
    }

    private function afterSavePath(Request $request, int $taskId, int $projectId): string
    {
        $back = (string) $request->input('back', '');
        if ($back !== '') {
            return $back;
        }
        if (str_starts_with($request->path(), '/projects/')) {
            return '/projects/' . $projectId . '?tab=tasks';
        }

        return '/tasks/' . $taskId;
    }
}
