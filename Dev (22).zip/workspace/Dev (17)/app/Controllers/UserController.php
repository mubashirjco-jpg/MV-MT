<?php
/**
 * Admin user management (Phase 9): employees, hourly rates, roles and
 * active/inactive status.
 *
 * Access is enforced twice:
 *   - the constructor lets admin and manager in (they both hold users.view);
 *   - each mutating method re-checks the granular users.* permission, and role
 *     and status changes additionally require roles.manage (admin only).
 */

declare(strict_types=1);

final class UserController extends Controller
{
    /** @var list<string> */
    private const STATUSES = ['active', 'inactive', 'suspended'];

    public function __construct()
    {
        parent::__construct(true, [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER]);
    }

    /** GET /users */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('users.view');

        $filters = [
            'q'      => trim((string) $request->input('q', '')),
            'role'   => (string) $request->input('role', 'all'),
            'status' => (string) $request->input('status', 'all'),
        ];

        if (!in_array($filters['role'], array_merge(['all'], AuthHelper::ROLES), true)) {
            $filters['role'] = 'all';
        }
        if (!in_array($filters['status'], array_merge(['all'], self::STATUSES), true)) {
            $filters['status'] = 'all';
        }

        [$where, $bindings] = $this->buildFilters($filters);

        $perPage = 20;
        $page    = max(1, (int) $request->input('page', 1));

        $from = ' FROM users u INNER JOIN roles r ON r.id = u.role_id';
        $total = (int) Database::fetchValue("SELECT COUNT(*){$from}{$where}", $bindings);
        $pages = max(1, (int) ceil($total / $perPage));
        $page  = min($page, $pages);
        $offset = ($page - 1) * $perPage;

        $users = Database::fetchAll(
            "SELECT u.id, u.name, u.email, u.phone, u.job_title, u.hourly_rate, r.name AS role, u.status,
                    u.last_login_at, u.created_at, r.display_name AS role_name
             {$from}{$where}
             ORDER BY u.name ASC
             LIMIT {$perPage} OFFSET {$offset}",
            $bindings
        );

        $this->render('users/index', [
            'pageTitle' => 'Users',
            'users'     => $users,
            'filters'   => $filters,
            'total'     => $total,
            'page'      => $page,
            'pages'     => $pages,
            'canManage' => PermissionHelper::has('users.edit'),
            'currentId' => (int) AuthHelper::id(),
        ]);
    }

    /** GET /users/create */
    public function create(Request $request, array $params): void
    {
        PermissionHelper::require('users.create');

        $this->render('users/form', [
            'pageTitle' => 'New user',
            'user'      => null,
            'roles'     => $this->roles(),
            'timezones' => DateTimeZone::listIdentifiers(),
            'statuses'  => self::STATUSES,
            'action'    => url('/users'),
            'clients'   => $this->clientOptions(),
            'linkedClientIds' => [],
        ]);
    }

    /** POST /users */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('users.create');

        $data = $this->validate([
            'name'        => 'required|string|max:120',
            'email'       => 'required|email|max:190|unique:users,email',
            'password'    => 'required|string|strong_password',
            'phone'       => ['nullable', 'string', 'max:30', 'regex:/^[0-9+().\-\s]+$/'],
            'job_title'   => 'nullable|string|max:100',
            'hourly_rate' => 'nullable|numeric|min:0|max:100000',
            'timezone'    => 'required|timezone',
            'role'        => 'required|in:' . implode(',', AuthHelper::ROLES),
            'status'      => 'required|in:' . implode(',', self::STATUSES),
        ], '/users/create', $this->labels());

        $roleId   = $this->roleId((string) $data['role']);
        $roleName = $this->roleName($roleId);

        $mustChangeCol = SchemaHelper::columnExists('users', 'must_change_password');
        $id = Database::transaction(function () use ($data, $roleId, $roleName, $mustChangeCol): int {
            $columns = 'role_id, role, name, email, password, phone, job_title, hourly_rate, timezone, status, password_changed_at';
            $values  = ':role_id, :role, :name, :email, :password, :phone, :job_title, :hourly_rate, :timezone, :status, NULL';
            $params  = [
                'role_id'     => $roleId,
                'role'        => $roleName,
                'name'        => $data['name'],
                'email'       => strtolower((string) $data['email']),
                'password'    => password_hash((string) $data['password'], PASSWORD_BCRYPT, ['cost' => 12]),
                'phone'       => $data['phone'],
                'job_title'   => $data['job_title'],
                'hourly_rate' => $data['hourly_rate'] ?? 0,
                'timezone'    => $data['timezone'],
                'status'      => $data['status'],
            ];
            if ($mustChangeCol) {
                $columns .= ', must_change_password';
                $values  .= ', 1';
            }
            Database::execute(
                'INSERT INTO users (' . $columns . ') VALUES (' . $values . ')',
                $params
            );

            $newId = Database::lastInsertId();
            if ($roleName === AuthHelper::ROLE_CLIENT) {
                ClientScope::syncUserClients($newId, $this->postedClientIds());
            }

            return $newId;
        });

        LoggerHelper::logEvent('user.created', LoggerHelper::MODULE_USER, $id, null, [
            'name'   => $data['name'],
            'email'  => strtolower((string) $data['email']),
            'role'   => $roleName,
            'status' => $data['status'],
        ]);

        NotificationHelper::push(
            $id,
            Notification::TYPE_INFO,
            'Welcome to ' . (string) Config::get('app.name', 'TimeTrack'),
            'Your account is ready. Change the temporary password from your profile.',
            '/profile'
        );

        $this->flash('success', 'User "' . $data['name'] . '" was created.');
        $this->redirect('/users');
    }

    /** GET /users/{id}/edit */
    public function edit(Request $request, array $params): void
    {
        PermissionHelper::require('users.edit');

        $user = $this->loadUser((int) ($params['id'] ?? 0));

        $this->render('users/form', [
            'pageTitle' => 'Edit ' . $user['name'],
            'user'      => $user,
            'roles'     => $this->roles(),
            'timezones' => DateTimeZone::listIdentifiers(),
            'statuses'  => self::STATUSES,
            'action'    => url('/users/' . (int) $user['id']),
            'clients'   => $this->clientOptions(),
            'linkedClientIds' => ClientScope::clientIds((int) $user['id']),
        ]);
    }

    /** POST /users/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('users.edit');

        $user = $this->loadUser((int) ($params['id'] ?? 0));
        $id   = (int) $user['id'];

        $data = $this->validate([
            'name'        => 'required|string|max:120',
            'email'       => 'required|email|max:190|unique:users,email,' . $id,
            'password'    => 'nullable|string|strong_password',
            'phone'       => ['nullable', 'string', 'max:30', 'regex:/^[0-9+().\-\s]+$/'],
            'job_title'   => 'nullable|string|max:100',
            'hourly_rate' => 'nullable|numeric|min:0|max:100000',
            'timezone'    => 'required|timezone',
            'role'        => 'required|in:' . implode(',', AuthHelper::ROLES),
            'status'      => 'required|in:' . implode(',', self::STATUSES),
        ], '/users/' . $id . '/edit', $this->labels());

        $isSelf         = $id === (int) AuthHelper::id();
        $roleChanged    = (string) $user['role'] !== (string) $data['role'];
        $statusChanged  = (string) $user['status'] !== (string) $data['status'];

        // Only administrators may change roles or status.
        if (($roleChanged || $statusChanged) && !PermissionHelper::has('roles.manage')) {
            $this->forbidden();
        }

        // Guard against locking yourself (or the last admin) out.
        if ($isSelf && (string) $data['status'] !== 'active') {
            $this->backWithErrors('/users/' . $id . '/edit', ['status' => 'You cannot deactivate your own account.']);
        }
        if ($isSelf && (string) $data['role'] !== AuthHelper::ROLE_ADMIN && $this->lastAdminCount() <= 1) {
            $this->backWithErrors('/users/' . $id . '/edit', ['role' => 'You are the only administrator, so your role cannot change.']);
        }

        $roleId   = $this->roleId((string) $data['role']);
        $roleName = $this->roleName($roleId);

        Database::transaction(function () use ($id, $data, $roleId, $roleName): void {
            Database::execute(
                'UPDATE users
                 SET role_id = :role_id, role = :role, name = :name, email = :email,
                     phone = :phone, job_title = :job_title, hourly_rate = :hourly_rate,
                     timezone = :timezone, status = :status
                 WHERE id = :id',
                [
                    'role_id'     => $roleId,
                    'role'        => $roleName,
                    'name'        => $data['name'],
                    'email'       => strtolower((string) $data['email']),
                    'phone'       => $data['phone'],
                    'job_title'   => $data['job_title'],
                    'hourly_rate' => $data['hourly_rate'] ?? 0,
                    'timezone'    => $data['timezone'],
                    'status'      => $data['status'],
                    'id'          => $id,
                ]
            );

            if (!empty($data['password'])) {
                $sql = 'UPDATE users SET password = :password, password_changed_at = UTC_TIMESTAMP()';
                if (SchemaHelper::columnExists('users', 'must_change_password')) {
                    $sql .= ', must_change_password = 1';
                }
                $sql .= ' WHERE id = :id';
                Database::execute($sql, [
                    'password' => password_hash((string) $data['password'], PASSWORD_BCRYPT, ['cost' => 12]),
                    'id'       => $id,
                ]);
            }

            if ($roleName === AuthHelper::ROLE_CLIENT) {
                ClientScope::syncUserClients($id, $this->postedClientIds());
            } elseif (ClientScope::installed()) {
                ClientScope::syncUserClients($id, []);
            }
        });

        LoggerHelper::logEvent('user.updated', LoggerHelper::MODULE_USER, $id, [
            'role'   => (string) $user['role'],
            'status' => (string) $user['status'],
        ], [
            'role'   => $roleName,
            'status' => (string) $data['status'],
            'name'   => (string) $data['name'],
        ]);

        if ($statusChanged) {
            LoggerHelper::logEvent('user.status_changed', LoggerHelper::MODULE_USER, $id, ['status' => (string) $user['status']], ['status' => (string) $data['status']]);
        }

        $this->flash('success', 'User "' . $data['name'] . '" was updated.');
        $this->redirect('/users');
    }

    /** POST /users/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        PermissionHelper::require('users.delete');

        $user = $this->loadUser((int) ($params['id'] ?? 0));
        $id   = (int) $user['id'];

        if ($id === (int) AuthHelper::id()) {
            $this->flash('danger', 'You cannot delete your own account.');
            $this->redirect('/users');
        }

        if ((string) $user['role'] === AuthHelper::ROLE_ADMIN && $this->lastAdminCount() <= 1) {
            $this->flash('danger', 'The last administrator cannot be deleted.');
            $this->redirect('/users');
        }

        try {
            Database::execute('DELETE FROM users WHERE id = :id', ['id' => $id]);
        } catch (Throwable $e) {
            // Foreign keys (time entries, projects) protect historical records.
            LoggerHelper::exception($e);
            $this->flash('danger', 'This user has linked records and cannot be deleted. Deactivate the account instead.');
            $this->redirect('/users');
        }

        LoggerHelper::logEvent('user.deleted', LoggerHelper::MODULE_USER, $id, [
            'name'  => (string) $user['name'],
            'email' => (string) $user['email'],
        ], null);

        $this->flash('success', 'User "' . $user['name'] . '" was deleted.');
        $this->redirect('/users');
    }

    /* ------------------------------------------------------------- helpers */

    /** @return array<string, mixed> */
    private function loadUser(int $id): array
    {
        if ($id < 1) {
            $this->notFound();
        }

        $user = Database::fetchOne(
            'SELECT u.id, u.name, u.email, u.phone, u.job_title, u.hourly_rate, u.timezone,
                    r.name AS role, u.status
             FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE u.id = :id LIMIT 1',
            ['id' => $id]
        );

        if ($user === null) {
            $this->notFound();
        }

        return $user;
    }

    /** @return list<array<string, mixed>> */
    private function roles(): array
    {
        return Database::fetchAll('SELECT id, name, display_name FROM roles ORDER BY id ASC');
    }

    /** @return list<array<string, mixed>> */
    private function clientOptions(): array
    {
        return Database::fetchAll('SELECT id, name, company FROM clients ORDER BY name ASC');
    }

    /** @return list<int> */
    private function postedClientIds(): array
    {
        $raw = $this->request->input('client_ids', []);
        if (!is_array($raw)) {
            $raw = [$raw];
        }

        return array_values(array_unique(array_filter(
            array_map('intval', $raw),
            static fn (int $id): bool => $id > 0
        )));
    }

    private function roleId(string $role): int
    {
        $id = (int) Database::fetchValue('SELECT id FROM roles WHERE name = :name LIMIT 1', ['name' => $role]);

        if ($id < 1) {
            throw new RuntimeException('Unknown role: ' . $role);
        }

        return $id;
    }

    private function roleName(int $roleId): string
    {
        $name = (string) Database::fetchValue(
            'SELECT name FROM roles WHERE id = :id LIMIT 1',
            ['id' => $roleId]
        );

        if ($name === '' || !in_array($name, AuthHelper::ROLES, true)) {
            throw new RuntimeException('Unknown role id: ' . $roleId);
        }

        return $name;
    }

    private function lastAdminCount(): int
    {
        return (int) Database::fetchValue(
            "SELECT COUNT(*) FROM users u
             INNER JOIN roles r ON r.id = u.role_id
             WHERE r.name = 'admin' AND u.status = 'active'"
        );
    }

    /**
     * @param array<string, mixed> $filters
     * @return array{0: string, 1: array<string, mixed>}
     */
    private function buildFilters(array $filters): array
    {
        $clauses = [];
        $params  = [];

        if ($filters['q'] !== '') {
            $clauses[] = '(u.name LIKE :q OR u.email LIKE :q OR u.job_title LIKE :q)';
            $params['q'] = '%' . str_replace(['%', '_'], ['\\%', '\\_'], mb_substr((string) $filters['q'], 0, 100, 'UTF-8')) . '%';
        }

        if ($filters['role'] !== 'all') {
            $clauses[] = 'r.name = :role';
            $params['role'] = $filters['role'];
        }

        if ($filters['status'] !== 'all') {
            $clauses[] = 'u.status = :status';
            $params['status'] = $filters['status'];
        }

        return [$clauses === [] ? '' : ' WHERE ' . implode(' AND ', $clauses), $params];
    }

    /** @return array<string, string> */
    private function labels(): array
    {
        return [
            'name'        => 'Name',
            'email'       => 'Email',
            'password'    => 'Password',
            'phone'       => 'Phone',
            'job_title'   => 'Job title',
            'hourly_rate' => 'Hourly rate',
            'timezone'    => 'Timezone',
            'role'        => 'Role',
            'status'      => 'Status',
        ];
    }
}
