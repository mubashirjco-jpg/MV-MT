<?php
/**
 * Closing markup and scripts. Shared by the "app" and "auth" layouts.
 */

$isShell = AuthHelper::check();
?>
<?php if ($isShell): ?>
        </main>

        <footer class="app-footer">
            <span>&copy; <?= e(gmdate('Y')) ?> <?= e((string) Config::get('app.name', 'TimeTrack')) ?></span>
            <span class="text-secondary">Times are shown in <?= e(str_replace('_', ' ', FormatHelper::displayTimezone())) ?></span>
        </footer>
    </div><!-- /.app-main -->
</div><!-- /.app-shell -->
<?php endif; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('js/app.js')) ?>"></script>
<?php if ($isShell && PermissionHelper::has('time.track')): ?>
<script src="<?= e(asset('js/timer.js')) ?>"></script>
<?php endif; ?>
<?php if (!empty($scheduleAssets)): ?>
<script src="<?= e(asset('js/schedule.js')) ?>"></script>
<?php endif; ?>
</body>
</html>
