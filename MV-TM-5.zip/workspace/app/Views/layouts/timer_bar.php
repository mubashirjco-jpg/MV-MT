<?php
/**
 * Strip shown at the very top of the page content (inside <main>): the running-timer
 * bar followed by one-time flash messages.
 *
 * The bar is always in the DOM (hidden when idle) so timer.js can show it without a reload.
 *
 * @var array<string, mixed>|null $activeTimer optional; loaded here when omitted
 */

$flashes = flash_pull();
$icons   = ['success' => 'fa-circle-check', 'danger' => 'fa-circle-exclamation', 'warning' => 'fa-triangle-exclamation', 'info' => 'fa-circle-info'];

$canTrackTimer = AuthHelper::check() && PermissionHelper::has('time.track') && class_exists('Timer') && Timer::installed();
$timer = isset($activeTimer) && is_array($activeTimer) ? $activeTimer : null;
if (!isset($activeTimer) && $canTrackTimer) {
    try {
        $timer = (new Timer())->getActive((int) AuthHelper::id());
    } catch (Throwable) {
        $timer = null;
    }
}

$running = $canTrackTimer && is_array($timer) && !empty($timer['started_at']);
$startedIso = '';
if ($running) {
    try {
        $startedIso = (new DateTimeImmutable((string) $timer['started_at'], new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');
    } catch (Exception) {
        $startedIso = '';
    }
}
?>
<?php if ($canTrackTimer): ?>
    <div id="timerBar"
         class="timer-bar<?= $running ? '' : ' is-idle' ?>"
         role="status"
         <?= $running ? '' : 'hidden' ?>
         data-timer-bar
         data-status-url="<?= e(url('/time/status')) ?>"
         data-start-url="<?= e(url('/time/start')) ?>"
         data-stop-url="<?= e(url('/time/stop')) ?>"
         data-ping-url="<?= e(url('/time/ping')) ?>"
         data-tasks-url="<?= e(url('/time/tasks')) ?>"
         data-started-at="<?= e($startedIso) ?>"
         data-elapsed="<?= $running ? (int) ($timer['elapsed_seconds'] ?? 0) : 0 ?>">
        <span class="timer-pulse" aria-hidden="true"></span>
        <span class="timer-label">
            <strong data-timer-project><?= e($running ? ($timer['project_name'] ?? 'Timer running') : 'Timer running') ?></strong>
            <span class="timer-task<?= $running && !empty($timer['task_name']) ? '' : ' d-none' ?>" data-timer-task><?= e($running ? ($timer['task_name'] ?? '') : '') ?></span>
        </span>
        <span class="timer-clock" data-timer-clock><?= $running ? e(FormatHelper::duration((int) ($timer['elapsed_seconds'] ?? 0))) : '0:00:00' ?></span>
        <button type="button" class="btn btn-sm btn-dark timer-stop" data-timer-stop<?= $running ? '' : ' disabled' ?>>
            <i class="fa-solid fa-stop" aria-hidden="true"></i> Stop
        </button>
    </div>
<?php endif; ?>

<?php foreach ($flashes as $type => $messages): ?>
    <?php foreach ((array) $messages as $message): ?>
        <div class="alert alert-<?= e($type) ?> d-flex align-items-start gap-2 alert-dismissible fade show" role="<?= $type === 'danger' ? 'alert' : 'status' ?>" data-auto-dismiss="<?= $type === 'success' || $type === 'info' ? '6000' : '0' ?>">
            <i class="fa-solid <?= e($icons[$type] ?? 'fa-circle-info') ?> mt-1" aria-hidden="true"></i>
            <div class="flex-grow-1"><?= e($message) ?></div>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Dismiss"></button>
        </div>
    <?php endforeach; ?>
<?php endforeach; ?>
