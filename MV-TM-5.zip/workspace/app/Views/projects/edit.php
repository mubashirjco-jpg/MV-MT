<?php
/**
 * Edit project.
 *
 * @var array<string, mixed> $project
 * @var string               $formAction
 * @var string               $submitLabel
 */
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Edit project</h2>
        <p class="page-lead"><?= e($project['project_code'] ?? '') ?> · <?= e($project['name'] ?? '') ?></p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= e(url('/projects/' . (int) ($project['id'] ?? 0))) ?>">Back to overview</a>
</div>
<?php require APP_PATH . '/Views/projects/form.php'; ?>
