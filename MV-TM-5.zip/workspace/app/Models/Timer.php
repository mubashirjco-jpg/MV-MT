<?php
/**
 * Server-authoritative running timer. One row per user (UNIQUE user_id).
 *
 * Elapsed time is always computed from the server clock against started_at,
 * never from a client-supplied duration.
 */

declare(strict_types=1);

final class Timer extends Model
{
    protected string $table = 'active_timers';

    protected array $columns = [
        'id', 'user_id', 'project_id', 'task_id',
        'started_at', 'last_activity_at', 'description', 'is_billable', 'created_at',
    ];

    protected array $fillable = [
        'user_id', 'project_id', 'task_id',
        'started_at', 'last_activity_at', 'description', 'is_billable',
    ];

    protected bool $timestamps = false;

    /** True when the active_timers table has been installed. */
    public static function installed(): bool
    {
        static $installed = null;

        if ($installed === null) {
            try {
                $installed = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = 'active_timers'"
                ) > 0;
            } catch (Throwable) {
                $installed = false;
            }
        }

        return $installed;
    }

    /**
     * Start a timer for $userId. At most one active timer exists per user:
     * an existing row is rejected (the caller must stop it first).
     *
     * @return array<string, mixed>
     */
    public function start(
        int $userId,
        int $projectId,
        ?int $taskId,
        string $description,
        bool $isBillable
    ): array {
        if ($userId < 1 || $projectId < 1) {
            throw new InvalidArgumentException('A user and project are required to start a timer.');
        }

        $description = mb_substr(trim($description), 0, 255, 'UTF-8');

        return Database::transaction(function (PDO $pdo) use ($userId, $projectId, $taskId, $description, $isBillable): array {
            $existing = $this->lockForUser($pdo, $userId);
            if ($existing !== null) {
                throw new RuntimeException('You already have a timer running. Stop it before starting another.');
            }

            $now = gmdate('Y-m-d H:i:s', time());

            try {
                Database::execute(
                    'INSERT INTO active_timers
                        (user_id, project_id, task_id, started_at, last_activity_at, description, is_billable, created_at)
                     VALUES
                        (:user_id, :project_id, :task_id, :started_at, :last_activity_at, :description, :is_billable, :created_at)',
                    [
                        'user_id'          => $userId,
                        'project_id'       => $projectId,
                        'task_id'          => $taskId,
                        'started_at'       => $now,
                        'last_activity_at' => $now,
                        'description'      => $description !== '' ? $description : null,
                        'is_billable'      => $isBillable ? 1 : 0,
                        'created_at'       => $now,
                    ]
                );
            } catch (PDOException $e) {
                if ((int) ($e->errorInfo[1] ?? 0) === 1062) {
                    throw new RuntimeException('You already have a timer running. Stop it before starting another.');
                }
                throw $e;
            }

            $row = $this->getActive($userId);
            if ($row === null) {
                throw new RuntimeException('Timer could not be started.');
            }

            return $row;
        });
    }

    /**
     * Fetch the user's running timer with project/task names and server elapsed seconds.
     *
     * @return array<string, mixed>|null
     */
    public function getActive(int $userId): ?array
    {
        if ($userId < 1 || !self::installed()) {
            return null;
        }

        $taskSelect = Task::installed() ? 'tk.name AS task_name' : 'NULL AS task_name';
        $taskJoin   = Task::installed() ? 'LEFT JOIN tasks tk ON tk.id = t.task_id' : '';

        $row = Database::fetchOne(
            "SELECT t.id, t.user_id, t.project_id, t.task_id, t.started_at, t.last_activity_at,
                    t.description, t.is_billable, t.created_at,
                    p.name AS project_name, p.project_code, p.hourly_rate, p.is_billable AS project_billable,
                    {$taskSelect}
             FROM active_timers t
             INNER JOIN projects p ON p.id = t.project_id
             {$taskJoin}
             WHERE t.user_id = :user_id
             LIMIT 1",
            ['user_id' => $userId]
        );

        if ($row === null) {
            return null;
        }

        return $this->withElapsed($row);
    }

    /**
     * Stop the running timer: insert a time_entries row with exact elapsed seconds,
     * delete the active_timers row, return the new entry.
     *
     * @return array<string, mixed>
     */
    public function stop(int $userId): array
    {
        if ($userId < 1) {
            throw new InvalidArgumentException('A user is required to stop a timer.');
        }

        return Database::transaction(function (PDO $pdo) use ($userId): array {
            $row = $this->lockForUser($pdo, $userId);
            if ($row === null) {
                throw new RuntimeException('No timer is running.');
            }

            $startedAt = (string) $row['started_at'];
            $startedTs = strtotime($startedAt . ' UTC');
            if ($startedTs === false) {
                $startedTs = time();
            }

            $endedTs  = time();
            $elapsed  = max(1, $endedTs - $startedTs);
            $endTime  = gmdate('Y-m-d H:i:s', $startedTs + $elapsed);
            $rate     = $this->projectRate((int) $row['project_id']);
            $billable = (int) $row['is_billable'] === 1 ? 1 : 0;

            $entry = (new TimeEntry())->createEntry([
                'user_id'          => $userId,
                'project_id'       => (int) $row['project_id'],
                'task_id'          => $row['task_id'] !== null ? (int) $row['task_id'] : null,
                'start_time'       => $startedAt,
                'end_time'         => $endTime,
                'break_minutes'    => 0,
                'description'      => $row['description'],
                'is_billable'      => $billable,
                'billable_rate'    => $rate,
                'status'           => TimeEntry::STATUS_PENDING,
            ]);

            Database::execute(
                'DELETE FROM active_timers WHERE user_id = :user_id',
                ['user_id' => $userId]
            );

            return $entry;
        });
    }

    /** Touch last_activity_at so idle detection can see the user is still around. */
    public function ping(int $userId): bool
    {
        if ($userId < 1 || !self::installed()) {
            return false;
        }

        return Database::execute(
            'UPDATE active_timers SET last_activity_at = :now WHERE user_id = :user_id',
            ['now' => gmdate('Y-m-d H:i:s', time()), 'user_id' => $userId]
        ) > 0;
    }

    /**
     * @param array<string, mixed> $row
     * @return array<string, mixed>
     */
    public function withElapsed(array $row): array
    {
        $startedTs = strtotime((string) $row['started_at'] . ' UTC');
        if ($startedTs === false) {
            $startedTs = time();
        }

        $elapsed = max(0, time() - $startedTs);

        $row['elapsed_seconds'] = $elapsed;
        $row['elapsed_display'] = FormatHelper::duration($elapsed);
        $row['is_billable']     = (int) ($row['is_billable'] ?? 0);
        $row['project_id']      = (int) $row['project_id'];
        $row['task_id']         = $row['task_id'] !== null ? (int) $row['task_id'] : null;
        $row['user_id']         = (int) $row['user_id'];
        $row['id']              = (int) $row['id'];

        return $row;
    }

    /**
     * Lock the user's timer row (if any) for the rest of the transaction.
     *
     * @return array<string, mixed>|null
     */
    private function lockForUser(PDO $pdo, int $userId): ?array
    {
        $stmt = $pdo->prepare('SELECT * FROM active_timers WHERE user_id = :user_id LIMIT 1 FOR UPDATE');
        $stmt->bindValue(':user_id', $userId, PDO::PARAM_INT);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);

        return $row === false ? null : $row;
    }

    private function projectRate(int $projectId): float
    {
        $rate = Database::fetchValue(
            'SELECT hourly_rate FROM projects WHERE id = :id LIMIT 1',
            ['id' => $projectId]
        );

        return $rate !== null ? (float) $rate : 0.0;
    }
}
