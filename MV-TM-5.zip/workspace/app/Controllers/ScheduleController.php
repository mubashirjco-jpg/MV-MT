<?php
/**
 * Planned work: calendar, my schedule, team matrix, conflict-aware create/update.
 *
 * Employees see and edit their own blocks on assigned projects.
 * Managers see the team and can plan work for members of projects they manage.
 * Admins have full access.
 */

declare(strict_types=1);

final class ScheduleController extends Controller
{
    private Schedule $schedules;
    private Project $projects;

    public function __construct()
    {
        parent::__construct(true);
        $this->schedules = new Schedule();
        $this->projects  = new Project();
    }

    /** GET /schedule */
    public function calendar(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');

        $view = (string) $request->input('view', 'week');
        if (!in_array($view, ['month', 'week', 'day'], true)) {
            $view = 'week';
        }

        $this->view('schedule/calendar', $this->pageData([
            'pageTitle'     => 'Schedule',
            'activeTab'     => 'calendar',
            'calendarView'  => $view,
            'focusUserId'   => (int) $request->input('user_id', 0),
            'scheduleAssets'=> true,
        ]));
    }

    /** GET /schedule/events */
    public function eventsJson(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');

        [$startUtc, $endUtc] = $this->rangeFromRequest($request);
        $userId    = (int) AuthHelper::id();
        $viewTeam  = PermissionHelper::has('schedule.view_team');
        $focusUser = $viewTeam ? (int) $request->input('user_id', 0) : $userId;

        $rows = $this->schedules->inRange(
            $startUtc,
            $endUtc,
            $focusUser > 0 ? $focusUser : null,
            $viewTeam,
            $userId
        );

        $events = [];
        foreach ($rows as $row) {
            if (!$this->schedules->userCanView($row, $userId, $viewTeam)) {
                continue;
            }

            $title = (string) $row['project_name'];
            if (!empty($row['task_name'])) {
                $title .= ' · ' . $row['task_name'];
            }

            $events[] = [
                'id'               => (int) $row['id'],
                'title'            => $title,
                'start'            => $this->toIsoUtc((string) $row['start_datetime']),
                'end'              => $this->toIsoUtc((string) $row['end_datetime']),
                'color'            => (string) $row['color'],
                'status'           => (string) $row['status'],
                'project_id'       => (int) $row['project_id'],
                'project_name'     => (string) $row['project_name'],
                'project_code'     => (string) $row['project_code'],
                'project_priority' => (string) ($row['project_priority'] ?? ''),
                'task_id'          => $row['task_id'],
                'task_name'        => (string) ($row['task_name'] ?? ''),
                'user_id'          => (int) $row['user_id'],
                'user_name'        => (string) $row['user_name'],
                'notes'            => (string) ($row['notes'] ?? ''),
                'estimated_hours'  => (float) $row['estimated_hours'],
                'editable'         => $this->schedules->userCanEdit(
                    $row,
                    $userId,
                    AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
                    AuthHelper::hasRole(AuthHelper::ROLE_MANAGER)
                ),
            ];
        }

        $this->json(['ok' => true, 'events' => $events]);
    }

    /** GET /schedule/my */
    public function mySchedule(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');

        $userId = (int) AuthHelper::id();
        $from   = (new DateTimeImmutable('today', new DateTimeZone('UTC')))->format('Y-m-d 00:00:00');
        $items  = $this->schedules->forUser($userId, $from, 80);
        $groups = $this->groupByLocalDay($items);

        $this->view('schedule/my_schedule', $this->pageData([
            'pageTitle'      => 'My schedule',
            'activeTab'      => 'mine',
            'groups'         => $groups,
            'canTimer'       => is_file(APP_PATH . '/Controllers/TimerController.php') && PermissionHelper::has('time.track'),
            'scheduleAssets' => true,
        ]));
    }

    /** GET /schedule/team */
    public function teamSchedule(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view_team');

        $anchor = $this->parseLocalDate((string) $request->input('week', ''));
        $weekStart = $anchor->modify('Monday this week')->setTime(0, 0, 0);
        $weekEnd   = $weekStart->modify('+7 days');

        $startUtc = $weekStart->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
        $endUtc   = $weekEnd->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');

        $workload = $this->schedules->teamWorkload($startUtc, $endUtc);
        $events   = $this->schedules->inRange($startUtc, $endUtc, null, true, (int) AuthHelper::id());

        $byUser = [];
        foreach ($events as $event) {
            $byUser[(int) $event['user_id']][] = $event;
        }

        $days = [];
        for ($i = 0; $i < 7; $i++) {
            $days[] = $weekStart->modify('+' . $i . ' day');
        }

        $this->view('schedule/team_schedule', $this->pageData([
            'pageTitle'      => 'Team schedule',
            'activeTab'      => 'team',
            'weekStart'      => $weekStart,
            'weekEnd'        => $weekEnd,
            'days'           => $days,
            'workload'       => $workload,
            'byUser'         => $byUser,
            'prevWeek'       => $weekStart->modify('-7 days')->format('Y-m-d'),
            'nextWeek'       => $weekStart->modify('+7 days')->format('Y-m-d'),
            'scheduleAssets' => true,
        ]));
    }

    /** POST /schedule */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.create');

        $payload = $this->validatedBlock('/schedule');
        $this->assertCanAssign($payload['user_id'], $payload['project_id']);

        $conflicts = $this->schedules->checkConflict(
            $payload['user_id'],
            $payload['start_datetime'],
            $payload['end_datetime']
        );

        if ($conflicts !== [] && !$this->wantsOverride($request)) {
            $this->conflictResponse($conflicts);
        }

        $payload['created_by'] = (int) AuthHelper::id();
        $id = $this->schedules->create($payload);

        $recurrence = $this->postedRecurrence();
        if ($recurrence !== null) {
            $this->schedules->saveRecurrence($id, $recurrence);
            $this->schedules->expandRecurrence($id);
        }

        LoggerHelper::audit('schedule.created', 'schedule', $id, [
            'user_id'    => $payload['user_id'],
            'project_id' => $payload['project_id'],
            'overridden' => $conflicts !== [],
        ]);

        if ($request->wantsJson()) {
            $this->json(['ok' => true, 'id' => $id]);
        }

        $this->flash('success', 'Planned work was saved.');
        $this->redirect('/schedule');
    }

    /** POST /schedule/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.edit');

        $row = $this->loadEditable((int) ($params['id'] ?? 0));
        $payload = $this->validatedBlock('/schedule');
        $this->assertCanAssign($payload['user_id'], $payload['project_id']);

        $conflicts = $this->schedules->checkConflict(
            $payload['user_id'],
            $payload['start_datetime'],
            $payload['end_datetime'],
            (int) $row['id']
        );

        if ($conflicts !== [] && !$this->wantsOverride($request)) {
            $this->conflictResponse($conflicts);
        }

        unset($payload['created_by']);
        $this->schedules->update((int) $row['id'], $payload);

        $recurrence = $this->postedRecurrence();
        if ($recurrence !== null) {
            $this->schedules->saveRecurrence((int) $row['id'], $recurrence);
        }

        LoggerHelper::audit('schedule.updated', 'schedule', (int) $row['id']);

        if ($request->wantsJson()) {
            $this->json(['ok' => true, 'id' => (int) $row['id']]);
        }

        $this->flash('success', 'Planned work was updated.');
        $this->redirect('/schedule');
    }

    /** POST /schedule/{id}/time  AJAX drag/resize */
    public function updateEventTime(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.edit');

        $row = $this->loadEditable((int) ($params['id'] ?? 0));

        $startRaw = (string) $request->input('start_datetime', $request->input('start', ''));
        $endRaw   = (string) $request->input('end_datetime', $request->input('end', ''));
        $startUtc = $this->parseIncomingDatetime($startRaw);
        $endUtc   = $this->parseIncomingDatetime($endRaw);

        if ($startUtc === null || $endUtc === null || $endUtc <= $startUtc) {
            $this->json(['ok' => false, 'errors' => ['start_datetime' => 'The new time range is not valid.']], 422);
        }

        $conflicts = $this->schedules->checkConflict(
            (int) $row['user_id'],
            $startUtc,
            $endUtc,
            (int) $row['id']
        );

        if ($conflicts !== [] && !$this->wantsOverride($request)) {
            $this->conflictResponse($conflicts);
        }

        $this->schedules->update((int) $row['id'], [
            'start_datetime'  => $startUtc,
            'end_datetime'    => $endUtc,
            'estimated_hours' => Schedule::hoursBetween($startUtc, $endUtc),
            'status'          => (string) $row['status'] === Schedule::STATUS_SCHEDULED
                ? Schedule::STATUS_RESCHEDULED
                : $row['status'],
        ]);

        LoggerHelper::audit('schedule.moved', 'schedule', (int) $row['id'], [
            'overridden' => $conflicts !== [],
        ]);

        $this->json(['ok' => true, 'id' => (int) $row['id']]);
    }

    /** POST /schedule/{id}/delete */
    public function destroy(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.delete');

        $row = $this->loadEditable((int) ($params['id'] ?? 0));
        $this->schedules->cancel((int) $row['id']);
        LoggerHelper::audit('schedule.cancelled', 'schedule', (int) $row['id']);

        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }

        $this->flash('success', 'Planned work was cancelled.');
        $this->redirect('/schedule');
    }

    /** GET /schedule/tasks?project_id= */
    public function tasksJson(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');

        $projectId = (int) $request->input('project_id', 0);
        $this->assertCanViewProject($projectId);

        $this->json(['ok' => true, 'tasks' => $this->tasksForProject($projectId)]);
    }

    /** GET /schedule/assignees?project_id= */
    public function assigneesJson(Request $request, array $params): void
    {
        PermissionHelper::require('schedule.view');

        $projectId = (int) $request->input('project_id', 0);
        $this->assertCanViewProject($projectId);

        $this->json(['ok' => true, 'users' => $this->assigneesForProject($projectId)]);
    }

    /** @return array<string, mixed> */
    private function pageData(array $extra): array
    {
        $userId   = (int) AuthHelper::id();
        $viewTeam = PermissionHelper::has('schedule.view_team');

        return array_merge([
            'projects'     => $this->visibleProjects($userId, $viewTeam),
            'people'       => $viewTeam ? $this->activePeople() : [],
            'statuses'     => Schedule::STATUSES,
            'canCreate'    => PermissionHelper::has('schedule.create'),
            'canEdit'      => PermissionHelper::has('schedule.edit'),
            'canDelete'    => PermissionHelper::has('schedule.delete'),
            'canTeam'      => $viewTeam,
            'canAssign'    => $viewTeam || AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            'defaultUser'  => $userId,
            'timezone'     => FormatHelper::displayTimezone(),
            'hasTasks'     => $this->tasksTableExists(),
        ], $extra);
    }

    /** @return array<string, mixed> */
    private function validatedBlock(string $failPath): array
    {
        $rules = [
            'project_id'      => 'required|int|exists:projects,id',
            'user_id'         => 'required|int|exists:users,id',
            'start_datetime'  => 'required|datetime',
            'end_datetime'    => 'required|datetime',
            'status'          => 'required|in:' . implode(',', Schedule::STATUSES),
            'notes'           => 'nullable|string|max:2000',
            'estimated_hours' => 'nullable|numeric|min:0|max:24',
            'task_id'         => 'nullable|int',
        ];

        if ($this->tasksTableExists()) {
            $rules['task_id'] = 'nullable|int|exists:tasks,id';
        }

        $data = $this->validate($rules, $failPath, [
            'project_id'     => 'Project',
            'user_id'        => 'Person',
            'start_datetime' => 'Start',
            'end_datetime'   => 'End',
            'status'         => 'Status',
            'notes'          => 'Notes',
            'task_id'        => 'Task',
        ]);

        $startUtc = $this->parseIncomingDatetime((string) $data['start_datetime']);
        $endUtc   = $this->parseIncomingDatetime((string) $data['end_datetime']);

        if ($startUtc === null || $endUtc === null) {
            $this->failOrJson($failPath, ['start_datetime' => 'Start and end must be valid date and time.']);
        }
        if ($endUtc <= $startUtc) {
            $this->failOrJson($failPath, ['end_datetime' => 'End must be after start.']);
        }

        $hours = $data['estimated_hours'] !== null
            ? (float) $data['estimated_hours']
            : Schedule::hoursBetween($startUtc, $endUtc);

        return [
            'project_id'      => (int) $data['project_id'],
            'task_id'         => $data['task_id'] !== null ? (int) $data['task_id'] : null,
            'user_id'         => (int) $data['user_id'],
            'start_datetime'  => $startUtc,
            'end_datetime'    => $endUtc,
            'estimated_hours' => $hours,
            'status'          => (string) $data['status'],
            'notes'           => $data['notes'],
        ];
    }

    /** @return array{recurrence_type: string, repeat_until: ?string, days_of_week: ?string}|null */
    private function postedRecurrence(): ?array
    {
        $type = (string) $this->request->input('recurrence_type', '');
        if ($type === '' || $type === 'none') {
            return null;
        }
        if (!in_array($type, Schedule::RECURRENCE_TYPES, true)) {
            return null;
        }

        $until = (string) $this->request->input('repeat_until', '');
        $until = $until !== '' ? $until : null;

        $daysRaw = $this->request->input('days_of_week', []);
        $days = [];
        if (is_array($daysRaw)) {
            foreach ($daysRaw as $day) {
                $n = (int) $day;
                if ($n >= 1 && $n <= 7) {
                    $days[] = $n;
                }
            }
        } elseif (is_string($daysRaw) && $daysRaw !== '') {
            foreach (explode(',', $daysRaw) as $part) {
                $n = (int) trim($part);
                if ($n >= 1 && $n <= 7) {
                    $days[] = $n;
                }
            }
        }

        return [
            'recurrence_type' => $type,
            'repeat_until'    => $until,
            'days_of_week'    => $days === [] ? null : implode(',', array_unique($days)),
        ];
    }

    /** @return array<string, mixed> */
    private function loadEditable(int $id): array
    {
        if ($id < 1) {
            $this->notFound();
        }

        $row = $this->schedules->findWithRelations($id);
        if ($row === null) {
            $this->notFound();
        }

        $userId  = (int) AuthHelper::id();
        $viewTeam = PermissionHelper::has('schedule.view_team');
        if (!$this->schedules->userCanView($row, $userId, $viewTeam)) {
            $this->forbidden();
        }

        if (!$this->schedules->userCanEdit(
            $row,
            $userId,
            AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            AuthHelper::hasRole(AuthHelper::ROLE_MANAGER)
        )) {
            $this->forbidden();
        }

        return $row;
    }

    private function assertCanAssign(int $userId, int $projectId): void
    {
        $this->assertCanViewProject($projectId);

        $viewer = (int) AuthHelper::id();
        $canAssignOthers = PermissionHelper::has('schedule.view_team') || AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);

        if ($userId !== $viewer && !$canAssignOthers) {
            $this->forbidden();
        }

        $project = $this->projects->find($projectId);
        if ($project === null) {
            $this->notFound();
        }

        $member = (new ProjectMember())->isMember($projectId, $userId)
            || (int) ($project['manager_id'] ?? 0) === $userId
            || (int) ($project['created_by'] ?? 0) === $userId;

        if (!$member && !AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)) {
            $this->failOrJson('/schedule', ['user_id' => 'That person is not on this project.']);
        }
    }

    private function assertCanViewProject(int $projectId): void
    {
        if ($projectId < 1) {
            $this->notFound();
        }

        $project = $this->projects->find($projectId);
        if ($project === null) {
            $this->notFound();
        }

        if (!$this->projects->userCanView(
            $project,
            (int) AuthHelper::id(),
            PermissionHelper::has('projects.view_all')
        )) {
            $this->forbidden();
        }
    }

    private function wantsOverride(Request $request): bool
    {
        $raw = $request->input('override_conflict', 0);

        return $raw === 1 || $raw === '1' || $raw === true || $raw === 'true' || $raw === 'on';
    }

    /** @param list<array<string, mixed>> $conflicts */
    private function conflictResponse(array $conflicts): never
    {
        $message = 'This overlaps existing planned work.';

        if ($this->request->wantsJson()) {
            $this->json([
                'ok'        => false,
                'conflict'  => true,
                'message'   => $message,
                'conflicts' => $conflicts,
            ], 409);
        }

        $detail = $conflicts[0]['project_name'] . ' (' . $conflicts[0]['time_range'] . ')';
        $this->flash('warning', $message . ' Conflicting: ' . $detail . '. Save again with override to keep both.');
        $this->redirect('/schedule');
    }

    /** @param array<string, string> $errors */
    private function failOrJson(string $failPath, array $errors): never
    {
        if ($this->request->wantsJson()) {
            $this->json(['ok' => false, 'errors' => $errors], 422);
        }
        $this->backWithErrors($failPath, $errors);
    }

    /** @return array{0: string, 1: string} */
    private function rangeFromRequest(Request $request): array
    {
        $startRaw = (string) $request->input('start', '');
        $endRaw   = (string) $request->input('end', '');

        $startUtc = $this->parseIncomingDatetime($startRaw);
        $endUtc   = $this->parseIncomingDatetime($endRaw);

        if ($startUtc === null || $endUtc === null) {
            $now = new DateTimeImmutable('now', new DateTimeZone('UTC'));
            $startUtc = $now->modify('Monday this week')->setTime(0, 0, 0)->format('Y-m-d H:i:s');
            $endUtc   = $now->modify('Monday this week')->modify('+7 days')->format('Y-m-d H:i:s');
        }

        return [$startUtc, $endUtc];
    }

    private function parseIncomingDatetime(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        $value = str_replace('T', ' ', $value);
        $value = preg_replace('/Z$/', '', $value) ?? $value;
        $value = preg_replace('/\.\d+$/', '', $value) ?? $value;

        if (preg_match('/[+-]\d{2}:\d{2}$/', $value) === 1 || str_ends_with($value, 'Z')) {
            try {
                $dt = new DateTimeImmutable($value);
                return $dt->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            } catch (Exception) {
                return null;
            }
        }

        $utc = FormatHelper::toUtc($value);
        if ($utc !== null) {
            return $utc;
        }

        foreach (['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d'] as $format) {
            $parsed = DateTimeImmutable::createFromFormat('!' . $format, $value, new DateTimeZone('UTC'));
            $errors = DateTimeImmutable::getLastErrors();
            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                return $parsed->format('Y-m-d H:i:s');
            }
        }

        return null;
    }

    private function toIsoUtc(string $utc): string
    {
        try {
            return (new DateTimeImmutable($utc, new DateTimeZone('UTC')))->format('Y-m-d\TH:i:s\Z');
        } catch (Exception) {
            return $utc;
        }
    }

    private function parseLocalDate(string $value): DateTimeImmutable
    {
        $zone = new DateTimeZone(FormatHelper::displayTimezone());
        if ($value !== '') {
            $parsed = DateTimeImmutable::createFromFormat('!Y-m-d', $value, $zone);
            $errors = DateTimeImmutable::getLastErrors();
            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                return $parsed;
            }
        }

        return new DateTimeImmutable('today', $zone);
    }

    /**
     * @param list<array<string, mixed>> $items
     * @return array<string, list<array<string, mixed>>>
     */
    private function groupByLocalDay(array $items): array
    {
        $groups = [];
        foreach ($items as $item) {
            $key = FormatHelper::datetime((string) $item['start_datetime'], 'Y-m-d');
            $label = FormatHelper::datetime((string) $item['start_datetime'], 'l, F j');
            $groups[$key]['label'] = $label;
            $groups[$key]['items'][] = $item;
        }

        return $groups;
    }

    /** @return list<array<string, mixed>> */
    private function visibleProjects(int $userId, bool $viewTeam): array
    {
        $sql = "SELECT p.id, p.name, p.project_code, p.status
                FROM projects p
                WHERE p.status NOT IN ('Cancelled','Archived')";
        $params = [];

        if (!PermissionHelper::has('projects.view_all')) {
            $sql .= ' AND (p.manager_id = :uid_m OR p.created_by = :uid_c OR EXISTS (
                SELECT 1 FROM project_members pm WHERE pm.project_id = p.id AND pm.user_id = :uid_p
            ))';
            $params = ['uid_m' => $userId, 'uid_c' => $userId, 'uid_p' => $userId];
        }

        $sql .= ' ORDER BY p.name ASC';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    private function activePeople(): array
    {
        $sql = "SELECT DISTINCT u.id, u.name, u.email, u.role, u.job_title
                FROM users u
                WHERE u.status = 'active' AND u.role IN ('admin','manager','employee')";
        $params = [];

        if (!PermissionHelper::has('projects.view_all')) {
            $viewer = (int) AuthHelper::id();
            $sql .= ' AND EXISTS (
                SELECT 1 FROM projects p
                WHERE (p.manager_id = :uid_mgr OR p.created_by = :uid_own)
                  AND (
                      p.manager_id = u.id
                      OR p.created_by = u.id
                      OR EXISTS (
                          SELECT 1 FROM project_members pm
                          WHERE pm.project_id = p.id AND pm.user_id = u.id
                      )
                  )
            )';
            $params = [
                'uid_mgr' => $viewer,
                'uid_own' => $viewer,
            ];
        }

        $sql .= ' ORDER BY u.name ASC';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    private function assigneesForProject(int $projectId): array
    {
        return Database::fetchAll(
            "SELECT DISTINCT u.id, u.name, u.email, u.role, u.job_title
             FROM users u
             LEFT JOIN project_members pm ON pm.user_id = u.id AND pm.project_id = :pid_m
             LEFT JOIN projects p ON p.id = :pid_p
             WHERE u.status = 'active'
               AND (pm.id IS NOT NULL OR p.manager_id = u.id OR p.created_by = u.id OR u.role = 'admin')
             ORDER BY u.name ASC",
            ['pid_m' => $projectId, 'pid_p' => $projectId]
        );
    }

    /** @return list<array<string, mixed>> */
    private function tasksForProject(int $projectId): array
    {
        if (!$this->tasksTableExists()) {
            return [];
        }

        return Database::fetchAll(
            'SELECT id, name, status FROM tasks WHERE project_id = :id ORDER BY name ASC',
            ['id' => $projectId]
        );
    }

    private function tasksTableExists(): bool
    {
        static $exists = null;
        if ($exists === null) {
            try {
                $exists = (int) Database::fetchValue(
                    "SELECT COUNT(*) FROM information_schema.tables
                     WHERE table_schema = DATABASE() AND table_name = 'tasks'"
                ) > 0;
            } catch (Throwable) {
                $exists = false;
            }
        }

        return $exists;
    }
}
