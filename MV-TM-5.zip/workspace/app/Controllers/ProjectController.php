<?php
/**
 * Projects: index with All/Active/Completed tabs, create, view, edit, archive, sync members.
 *
 * Employees only see projects they are assigned to (or manage/created).
 * Managers can manage projects they are the manager of.
 * Admins have full access.
 */

declare(strict_types=1);

final class ProjectController extends Controller
{
    private Project $projects;
    private Client $clients;
    private ProjectMember $members;

    public function __construct()
    {
        parent::__construct(true);
        $this->projects = new Project();
        $this->clients  = new Client();
        $this->members  = new ProjectMember();
    }

    /** GET /projects */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('projects.view');

        $tab = (string) $request->input('tab', 'all');
        if (!in_array($tab, ['all', 'active', 'completed', 'archived'], true)) {
            $tab = 'all';
        }

        $userId  = (int) AuthHelper::id();
        $viewAll = PermissionHelper::has('projects.view_all');

        $result = $this->projects->listFiltered([
            'tab'        => $tab,
            'status'     => (string) $request->input('status', ''),
            'client_id'  => (int) $request->input('client_id', 0),
            'manager_id' => (int) $request->input('manager_id', 0),
            'q'          => (string) $request->input('q', ''),
        ], (int) $request->input('page', 1), 12, $userId, $viewAll);

        $this->view('projects/index', [
            'pageTitle'   => 'Projects',
            'tab'         => $tab,
            'result'      => $result,
            'clients'     => $this->clients->activeOptions(),
            'managers'    => $this->managerOptions(),
            'filters'     => [
                'status'     => (string) $request->input('status', ''),
                'client_id'  => (int) $request->input('client_id', 0),
                'manager_id' => (int) $request->input('manager_id', 0),
                'q'          => (string) $request->input('q', ''),
            ],
            'canCreate'   => PermissionHelper::has('projects.create'),
            'canEdit'     => PermissionHelper::has('projects.edit'),
            'canArchive'  => PermissionHelper::has('projects.archive'),
            'isAdmin'     => AuthHelper::hasRole(AuthHelper::ROLE_ADMIN),
            'userId'      => $userId,
        ]);
    }

    /** GET /projects/create */
    public function create(Request $request, array $params): void
    {
        PermissionHelper::require('projects.create');

        $this->view('projects/create', $this->formData([
            'pageTitle'    => 'New project',
            'project'      => $this->blankProject(),
            'selectedIds'  => [],
            'memberRoles'  => [],
            'formAction'   => url('/projects'),
            'submitLabel'  => 'Create project',
        ]));
    }

    /** POST /projects */
    public function store(Request $request, array $params): void
    {
        PermissionHelper::require('projects.create');

        $data = $this->validatedProject('/projects/create');
        $data['created_by'] = (int) AuthHelper::id();

        if ($data['project_code'] === null || $data['project_code'] === '') {
            $data['project_code'] = $this->projects->nextCode();
        }

        $id = $this->projects->create($data);

        $memberIds = $this->postedMemberIds();
        if ($data['manager_id'] !== null) {
            $memberIds[] = (int) $data['manager_id'];
        }
        $memberIds[] = (int) AuthHelper::id();
        $this->members->sync($id, $memberIds, $this->postedMemberRoles($data['manager_id']));

        LoggerHelper::audit('project.created', 'project', $id, [
            'name' => $data['name'],
            'code' => $data['project_code'],
        ]);
        $this->flash('success', 'Project "' . $data['name'] . '" was created.');
        $this->redirect('/projects/' . $id);
    }

    /** GET /projects/{id} */
    public function show(Request $request, array $params): void
    {
        PermissionHelper::require('projects.view');

        $project = $this->loadVisible((int) ($params['id'] ?? 0));
        $totals  = $this->projects->totals((int) $project['id']);
        $members = $this->members->forProject((int) $project['id']);
        $canManage = $this->projects->userCanManage(
            $project,
            (int) AuthHelper::id(),
            AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)
        );

        // Tasks tab (needs database/phase5.sql and the tasks.view permission).
        $tasksReady = Task::installed() && PermissionHelper::has('tasks.view');
        $tab = (string) $request->input('tab', $tasksReady ? 'tasks' : 'overview');
        if (!in_array($tab, ['tasks', 'overview'], true) || ($tab === 'tasks' && !$tasksReady)) {
            $tab = 'overview';
        }

        $taskFilter = (string) $request->input('task_status', 'active');
        if (!in_array($taskFilter, ['active', 'done', 'all'], true)) {
            $taskFilter = 'active';
        }
        $taskSearch = trim((string) $request->input('task_q', ''));

        $taskModel = new Task();
        $tasks      = $tasksReady ? $taskModel->forProject((int) $project['id'], $taskFilter, $taskSearch) : [];
        $taskCounts = $tasksReady ? $taskModel->counts((int) $project['id']) : ['all' => 0, 'active' => 0, 'done' => 0];

        $this->view('projects/view', [
            'pageTitle'      => (string) $project['name'],
            'project'        => $project,
            'totals'         => $totals,
            'members'        => $members,
            'tab'            => $tab,
            'tasksReady'     => $tasksReady,
            'tasks'          => $tasks,
            'taskCounts'     => $taskCounts,
            'taskFilter'     => $taskFilter,
            'taskSearch'     => $taskSearch,
            'taskStatuses'   => Task::STATUSES,
            'canCreateTask'  => PermissionHelper::has('tasks.create') && (string) $project['status'] !== Project::STATUS_ARCHIVED,
            'canEditTask'    => PermissionHelper::has('tasks.edit'),
            'canDeleteTask'  => PermissionHelper::has('tasks.delete'),
            'canAssignTask'  => PermissionHelper::has('tasks.assign'),
            'canTrack'       => PermissionHelper::has('time.track') && Timer::installed() && (string) $project['status'] !== Project::STATUS_ARCHIVED,
            'canEdit'        => $canManage && PermissionHelper::has('projects.edit'),
            'canArchive'     => $canManage && PermissionHelper::has('projects.archive'),
            'canManageMembers' => $canManage && PermissionHelper::has('projects.manage_members'),
            'users'          => $this->assignableUsers(),
            'memberRoles'    => ProjectMember::ROLES,
        ]);
    }

    /** GET /projects/{id}/edit */
    public function edit(Request $request, array $params): void
    {
        PermissionHelper::require('projects.edit');

        $project = $this->loadVisible((int) ($params['id'] ?? 0));
        $this->assertCanManage($project);

        $members = $this->members->forProject((int) $project['id']);
        $selectedIds = array_map(static fn (array $row): int => (int) $row['user_id'], $members);
        $roles = [];
        foreach ($members as $row) {
            $roles[(int) $row['user_id']] = (string) $row['project_role'];
        }

        $this->view('projects/edit', $this->formData([
            'pageTitle'   => 'Edit ' . $project['name'],
            'project'     => $project,
            'selectedIds' => $selectedIds,
            'memberRoles' => $roles,
            'formAction'  => url('/projects/' . (int) $project['id']),
            'submitLabel' => 'Save changes',
        ]));
    }

    /** POST /projects/{id} */
    public function update(Request $request, array $params): void
    {
        PermissionHelper::require('projects.edit');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        $data = $this->validatedProject('/projects/' . $id . '/edit', $id);
        unset($data['created_by']);
        $this->projects->update($id, $data);

        if (PermissionHelper::has('projects.manage_members')) {
            $memberIds = $this->postedMemberIds();
            if ($data['manager_id'] !== null) {
                $memberIds[] = (int) $data['manager_id'];
            }
            $this->members->sync($id, $memberIds, $this->postedMemberRoles($data['manager_id']));
        }

        LoggerHelper::audit('project.updated', 'project', $id, ['name' => $data['name']]);
        $this->flash('success', 'Project "' . $data['name'] . '" was updated.');
        $this->redirect('/projects/' . $id);
    }

    /** POST /projects/{id}/archive */
    public function archive(Request $request, array $params): void
    {
        PermissionHelper::require('projects.archive');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        if ((string) $project['status'] === Project::STATUS_ARCHIVED) {
            $this->flash('info', 'This project is already archived.');
            $this->redirect('/projects/' . $id);
        }

        $this->projects->archive($id);
        LoggerHelper::audit('project.archived', 'project', $id, ['name' => $project['name']]);
        $this->flash('success', 'Project "' . $project['name'] . '" was archived.');
        $this->redirect('/projects?tab=archived');
    }

    /** POST /projects/{id}/members */
    public function syncMembers(Request $request, array $params): void
    {
        PermissionHelper::require('projects.manage_members');

        $id      = (int) ($params['id'] ?? 0);
        $project = $this->loadVisible($id);
        $this->assertCanManage($project);

        $memberIds = $this->postedMemberIds();
        if (!empty($project['manager_id'])) {
            $memberIds[] = (int) $project['manager_id'];
        }
        $this->members->sync($id, $memberIds, $this->postedMemberRoles($project['manager_id'] ?? null));

        LoggerHelper::audit('project.members_synced', 'project', $id, ['count' => count(array_unique($memberIds))]);
        $this->flash('success', 'Project members were updated.');
        $this->redirect('/projects/' . $id . '?tab=overview');
    }

    /** @return array<string, mixed> */
    private function loadVisible(int $id): array
    {
        if ($id < 1) {
            $this->notFound();
        }

        $project = $this->projects->findWithRelations($id);
        if ($project === null) {
            $this->notFound();
        }

        $viewAll = PermissionHelper::has('projects.view_all');
        if (!$this->projects->userCanView($project, (int) AuthHelper::id(), $viewAll)) {
            $this->forbidden();
        }

        return $project;
    }

    /** @param array<string, mixed> $project */
    private function assertCanManage(array $project): void
    {
        if (!$this->projects->userCanManage(
            $project,
            (int) AuthHelper::id(),
            AuthHelper::hasRole(AuthHelper::ROLE_ADMIN)
        )) {
            $this->forbidden();
        }
    }

    /** @return array<string, mixed> */
    private function validatedProject(string $failPath, ?int $ignoreId = null): array
    {
        $codeRule = $ignoreId !== null
            ? 'nullable|string|max:40|unique:projects,project_code,' . $ignoreId
            : 'nullable|string|max:40|unique:projects,project_code';

        $data = $this->validate([
            'client_id'       => 'required|int|exists:clients,id',
            'project_code'    => $codeRule,
            'name'            => 'required|string|max:160',
            'description'     => 'nullable|string|max:5000',
            'start_date'      => 'nullable|date',
            'due_date'        => 'nullable|date',
            'status'          => 'required|in:' . implode(',', Project::STATUSES),
            'priority'        => 'required|in:' . implode(',', Project::PRIORITIES),
            'estimated_hours' => 'nullable|numeric|min:0|max:999999',
            'budget'          => 'nullable|numeric|min:0|max:99999999',
            'hourly_rate'     => 'nullable|numeric|min:0|max:99999',
            'is_billable'     => 'nullable|boolean',
            'manager_id'      => 'nullable|int|exists:users,id',
        ], $failPath, [
            'client_id'       => 'Client',
            'project_code'    => 'Project code',
            'name'            => 'Name',
            'description'     => 'Description',
            'start_date'      => 'Start date',
            'due_date'        => 'Due date',
            'status'          => 'Status',
            'priority'        => 'Priority',
            'estimated_hours' => 'Estimated hours',
            'budget'          => 'Budget',
            'hourly_rate'     => 'Hourly rate',
            'is_billable'     => 'Billable',
            'manager_id'      => 'Manager',
        ]);

        if ($data['start_date'] !== null && $data['due_date'] !== null && $data['due_date'] < $data['start_date']) {
            $this->backWithErrors($failPath, ['due_date' => 'Due date must be on or after the start date.']);
        }

        $data['estimated_hours'] = $data['estimated_hours'] ?? 0;
        $data['budget']          = $data['budget'] ?? 0;
        $data['hourly_rate']     = $data['hourly_rate'] ?? 0;
        $data['is_billable']     = (int) ($data['is_billable'] ?? 0);

        if ($data['manager_id'] !== null) {
            $manager = Database::fetchOne(
                "SELECT id, role, status FROM users WHERE id = :id LIMIT 1",
                ['id' => (int) $data['manager_id']]
            );
            if ($manager === null || $manager['status'] !== 'active') {
                $this->backWithErrors($failPath, ['manager_id' => 'Manager does not exist.']);
            }
            if (!in_array((string) $manager['role'], [AuthHelper::ROLE_ADMIN, AuthHelper::ROLE_MANAGER], true)) {
                $this->backWithErrors($failPath, ['manager_id' => 'Manager must be an admin or a manager.']);
            }
        }

        return $data;
    }

    /** @return list<int> */
    private function postedMemberIds(): array
    {
        $raw = $this->request->input('member_ids', []);
        if (!is_array($raw)) {
            $raw = $raw === null || $raw === '' ? [] : [$raw];
        }

        $ids = [];
        foreach ($raw as $value) {
            $id = (int) $value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }

        return array_values(array_unique($ids));
    }

    /**
     * @return array<int, string>
     */
    private function postedMemberRoles(mixed $managerId): array
    {
        $raw = $this->request->input('member_roles', []);
        $roles = [];

        if (is_array($raw)) {
            foreach ($raw as $userId => $role) {
                $uid = (int) $userId;
                $role = (string) $role;
                if ($uid > 0 && in_array($role, ProjectMember::ROLES, true)) {
                    $roles[$uid] = $role;
                }
            }
        }

        if ($managerId !== null && (int) $managerId > 0) {
            $roles[(int) $managerId] = ProjectMember::ROLE_MANAGER;
        }

        return $roles;
    }

    /**
     * @param array<string, mixed> $extra
     * @return array<string, mixed>
     */
    private function formData(array $extra): array
    {
        return array_merge([
            'clients'     => $this->clients->activeOptions(),
            'managers'    => $this->managerOptions(),
            'users'       => $this->assignableUsers(),
            'statuses'    => Project::STATUSES,
            'priorities'  => Project::PRIORITIES,
            'memberRoles' => $extra['memberRoles'] ?? [],
        ], $extra);
    }

    /** @return array<string, mixed> */
    private function blankProject(): array
    {
        return [
            'id'              => 0,
            'client_id'       => (int) ($this->request->input('client_id', 0)),
            'project_code'    => $this->projects->nextCode(),
            'name'            => '',
            'description'     => '',
            'start_date'      => '',
            'due_date'        => '',
            'status'          => Project::STATUS_PLANNING,
            'priority'        => Project::PRIORITY_MEDIUM,
            'estimated_hours' => '',
            'budget'          => '',
            'hourly_rate'     => '',
            'is_billable'     => 1,
            'manager_id'      => AuthHelper::hasRole(AuthHelper::ROLE_MANAGER) ? AuthHelper::id() : null,
        ];
    }

    /** @return list<array<string, mixed>> */
    private function managerOptions(): array
    {
        return Database::fetchAll(
            "SELECT id, name, email, role FROM users
             WHERE status = 'active' AND role IN ('admin','manager')
             ORDER BY name ASC"
        );
    }

    /** @return list<array<string, mixed>> */
    private function assignableUsers(): array
    {
        return Database::fetchAll(
            "SELECT id, name, email, role, job_title FROM users
             WHERE status = 'active' AND role IN ('admin','manager','employee')
             ORDER BY name ASC"
        );
    }
}
