/*
 * Server-authoritative timer.
 *
 * Fetches /time/status on load, ticks from the server-reported elapsed seconds
 * (not Date.parse of a client clock), and handles every [data-timer-start] /
 * [data-timer-stop] control on the page.
 */
(function () {
    'use strict';

    var bar = document.querySelector('[data-timer-bar]');
    if (!bar) { return; }

    var statusUrl = bar.getAttribute('data-status-url') || '';
    var startUrl = bar.getAttribute('data-start-url') || '';
    var stopUrl = bar.getAttribute('data-stop-url') || '';
    var pingUrl = bar.getAttribute('data-ping-url') || '';
    var tasksUrl = bar.getAttribute('data-tasks-url') || '';

    var clockEl = bar.querySelector('[data-timer-clock]');
    var projectEl = bar.querySelector('[data-timer-project]');
    var taskEl = bar.querySelector('[data-timer-task]');
    var stopBtn = bar.querySelector('[data-timer-stop]');

    var originElapsed = 0;
    var originAt = 0;
    var running = false;
    var tickTimer = null;
    var busy = false;

    function pad(n) { return n < 10 ? '0' + n : String(n); }

    function formatElapsed(seconds) {
        seconds = Math.max(0, Math.floor(seconds));
        var h = Math.floor(seconds / 3600);
        var m = Math.floor((seconds % 3600) / 60);
        var s = seconds % 60;
        return h + ':' + pad(m) + ':' + pad(s);
    }

    function currentElapsed() {
        if (!running) { return originElapsed; }
        return originElapsed + Math.max(0, Math.floor((Date.now() - originAt) / 1000));
    }

    function renderClock() {
        if (clockEl) {
            clockEl.textContent = formatElapsed(currentElapsed());
        }
    }

    function applyTimer(timer) {
        if (!timer) {
            running = false;
            originElapsed = 0;
            originAt = Date.now();
            bar.hidden = true;
            bar.classList.add('is-idle');
            bar.setAttribute('data-started-at', '');
            bar.setAttribute('data-elapsed', '0');
            if (stopBtn) { stopBtn.disabled = true; }
            if (projectEl) { projectEl.textContent = 'Timer running'; }
            if (taskEl) {
                taskEl.textContent = '';
                taskEl.classList.add('d-none');
            }
            renderClock();
            return;
        }

        originElapsed = parseInt(timer.elapsed_seconds, 10) || 0;
        originAt = Date.now();
        running = true;

        bar.hidden = false;
        bar.classList.remove('is-idle');
        bar.setAttribute('data-started-at', timer.started_at_iso || '');
        bar.setAttribute('data-elapsed', String(originElapsed));

        if (projectEl) { projectEl.textContent = timer.project_name || 'Timer running'; }
        if (taskEl) {
            if (timer.task_name) {
                taskEl.textContent = timer.task_name;
                taskEl.classList.remove('d-none');
            } else {
                taskEl.textContent = '';
                taskEl.classList.add('d-none');
            }
        }
        if (stopBtn) { stopBtn.disabled = false; }
        renderClock();
    }

    function tick() {
        if (!running) { return; }
        renderClock();
    }

    function ensureTicker() {
        if (tickTimer) { return; }
        tickTimer = window.setInterval(tick, 1000);
    }

    function parseJson(response) {
        return response.text().then(function (text) {
            var data = {};
            if (text) {
                try { data = JSON.parse(text); } catch (e) { data = {}; }
            }
            data._http = response.status;
            data._okHttp = response.ok;
            return data;
        });
    }

    function fail(message) {
        window.alert(message || 'The timer request failed.');
    }

    function startFrom(el) {
        if (busy) { return; }

        var form = el.closest ? el.closest('[data-timer-start-form], form') : null;
        var projectId = el.getAttribute('data-project-id')
            || (form && form.querySelector('[name="project_id"]') ? form.querySelector('[name="project_id"]').value : '')
            || '';
        var taskId = el.getAttribute('data-task-id')
            || (form && form.querySelector('[name="task_id"]') ? form.querySelector('[name="task_id"]').value : '')
            || '';
        var description = el.getAttribute('data-description')
            || (form && form.querySelector('[name="description"]') ? form.querySelector('[name="description"]').value : '')
            || '';
        var billable = el.getAttribute('data-billable');
        if (billable === null && form) {
            var billableField = form.querySelector('[name="is_billable"]');
            if (billableField) {
                billable = billableField.type === 'checkbox' ? (billableField.checked ? '1' : '0') : billableField.value;
            }
        }

        if (!projectId) {
            fail('Choose a project first.');
            return;
        }

        var body = {
            project_id: parseInt(projectId, 10),
            description: description
        };
        if (taskId) { body.task_id = parseInt(taskId, 10); }
        if (billable === '0' || billable === '1') { body.is_billable = parseInt(billable, 10); }

        busy = true;
        fetch(startUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(body)
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not start the timer.');
                return;
            }
            applyTimer(data.timer);
        }).catch(function () {
            busy = false;
            fail('Could not start the timer.');
        });
    }

    function stopTimer() {
        if (busy) { return; }
        busy = true;

        fetch(stopUrl, {
            method: 'POST',
            headers: {
                'Accept': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            }
        }).then(parseJson).then(function (data) {
            busy = false;
            if (!data.ok) {
                fail(data.message || (data.error && data.error.message) || 'Could not stop the timer.');
                return;
            }
            applyTimer(null);
        }).catch(function () {
            busy = false;
            fail('Could not stop the timer.');
        });
    }

    function loadStatus() {
        if (!statusUrl) { return; }

        fetch(statusUrl, {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(parseJson).then(function (data) {
            if (data.ok) {
                applyTimer(data.timer || null);
            }
        }).catch(function () { /* keep server-rendered bar */ });
    }

    function ping() {
        if (!running || !pingUrl) { return; }
        fetch(pingUrl, {
            method: 'POST',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).catch(function () { /* ignore */ });
    }

    function fillTasks(select, projectId, selectedId) {
        if (!select || !tasksUrl) { return; }
        select.innerHTML = '<option value="">No task</option>';
        if (!projectId) { return; }

        fetch(tasksUrl + (tasksUrl.indexOf('?') === -1 ? '?' : '&') + 'project_id=' + encodeURIComponent(projectId), {
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(parseJson).then(function (data) {
            if (!data.ok || !data.tasks) { return; }
            data.tasks.forEach(function (task) {
                var opt = document.createElement('option');
                opt.value = String(task.id);
                opt.textContent = task.name;
                if (selectedId && String(selectedId) === String(task.id)) {
                    opt.selected = true;
                }
                select.appendChild(opt);
            });
        }).catch(function () { /* keep empty */ });
    }

    document.addEventListener('click', function (event) {
        var startEl = event.target.closest ? event.target.closest('[data-timer-start]') : null;
        if (startEl && startEl.tagName !== 'SPAN') {
            event.preventDefault();
            startFrom(startEl);
            return;
        }

        var stopEl = event.target.closest ? event.target.closest('[data-timer-stop]') : null;
        if (stopEl) {
            event.preventDefault();
            stopTimer();
        }
    });

    document.querySelectorAll('[data-timer-project-select]').forEach(function (select) {
        var root = select.closest('form') || select.parentElement;
        var taskSelect = root ? root.querySelector('[data-timer-task-select]') : null;
        select.addEventListener('change', function () {
            fillTasks(taskSelect, select.value, '');
        });
        if (select.value) {
            var selected = taskSelect ? (taskSelect.getAttribute('data-selected-task') || '') : '';
            fillTasks(taskSelect, select.value, selected);
        }
    });

    var manualModal = document.getElementById('manualEntryModal');
    if (manualModal && manualModal.getAttribute('data-open') === '1' && window.bootstrap && window.bootstrap.Modal) {
        window.bootstrap.Modal.getOrCreateInstance(manualModal).show();
    }

    window.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'visible') {
            loadStatus();
        }
    });

    applyTimer(bar.classList.contains('is-idle') ? null : {
        elapsed_seconds: parseInt(bar.getAttribute('data-elapsed') || '0', 10) || 0,
        started_at_iso: bar.getAttribute('data-started-at') || '',
        project_name: projectEl ? projectEl.textContent : '',
        task_name: taskEl && !taskEl.classList.contains('d-none') ? taskEl.textContent : ''
    });

    ensureTicker();
    loadStatus();
    window.setInterval(ping, 60000);
})();
