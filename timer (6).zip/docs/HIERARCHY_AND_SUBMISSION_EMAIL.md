# TimeTrack hierarchy and submission notifications

## Hierarchy

Admin > Project Manager > Department Manager > Team Manager > Team members

A department belongs to one project. It has one department manager and any number of
team managers. Each team manager has their own members.

Example:

```
ADMIN
└── Project Manager
    └── Department 1
        ├── Department Manager
        ├── Team Manager A
        │   ├── Member 1
        │   └── Member 2
        └── Team Manager B
            └── Member 3
```

A Team Manager is assigned on `teams.manager_id`. A Department Manager is assigned on
`departments.manager_id`. The same person may manage more than one team, but not as both
department manager and team manager in the same department.

## Time submission email chain

For submitted time entries, recipients are resolved from the actual project/team of those
entries:
1. Team Manager
2. Department Manager
3. Project Manager
4. All active Admin users

For submissions spanning multiple teams/projects, all distinct applicable managers/PMs
are included. Duplicate recipients are removed and the submitter is excluded.

Admins submitting their own time are routed only to other active admins.

## Time locking

A submission creates a timesheet batch and links only the selected time entries. Existing
submitted/approved entries stay locked; new unsubmitted entries in the same week/month remain
recordable. This allows one task to remain active across multiple weeks with many time chunks.
