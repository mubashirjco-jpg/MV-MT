# Prompt: Fix the project / team / task hierarchy in TimeTrack

Paste this whole file into your AI coding assistant together with the project source (`Dev.zip`) and the live database dump (`u897128490_timetrack.sql`). The assistant must treat everything below as the specification.

---

## 0. Your role and operating rules

You are a senior PHP / MariaDB engineer working on a live, in-production internal system (custom PHP MVC, no framework, MariaDB 11.8). Your job is to fix a role-and-scope design flaw in how **tasks** relate to the **project → team → people hierarchy**, without breaking anything that works today.

Rules you must follow:

1. **Read before you write.** Before changing anything, read these files completely: `app/Helpers/WorkspacePolicy.php`, `app/Helpers/Permission.php`, `app/Helpers/ApprovalChain.php`, `app/Helpers/TimeTrackingRules.php`, `app/Controllers/TaskController.php`, `app/Controllers/ProjectController.php`, `app/Controllers/TeamGroupController.php`, `app/Models/Task.php`, `app/Models/TeamGroup.php`, `app/Models/ProjectMember.php`, `app/Models/Project.php`, `app/Helpers/InvitationService.php`, `app/Controllers/ImportController.php`, `app/Views/tasks/panel.php`, `app/Views/teams/*`, `routes/web.php`, `database/UPGRADE_LIVE.sql`.
2. **Follow the existing code style exactly:** `declare(strict_types=1)`, `final class`, `Database::fetchAll/fetchOne/execute` with bound parameters only, `LoggerHelper::audit(...)` for state changes, `$this->flash(...)` / `HttpException` for errors, the existing CSRF and middleware setup untouched. Do not add Composer packages or frameworks.
3. **PHP level:** use only syntax the codebase already uses (it already uses `match`, `never`, `str_starts_with`). Do not introduce anything newer. Run `php -l` on every file you touch and update `docs/PHP_LINT_REPORT.txt`.
4. **Database changes** go into `database/UPGRADE_LIVE.sql` as a new, clearly labelled STEP, written in the same idempotent style (information_schema check + `PREPARE`/`EXECUTE`), safe to run twice, and you must extend the final OK/MISSING checklist query at the bottom of that file.
5. **Never modify live data automatically.** Data repairs are delivered as (a) a read-only report query and (b) a CLI script in `tools/` that defaults to `--dry-run` and needs an explicit `--apply`.
6. **Deny by default.** Every new authorization check must fail closed. Menu/button hiding is not security; every POST route must enforce the rule server-side.
7. **Ship in phases** (section 6). After each phase stop, list the files changed, how to test, and what could go wrong. Do not start the next phase until the current one is complete.
8. If something here conflicts with the code, trust the code, state the conflict, and pick the safest option. Do not ask me questions; write down your assumptions.

---

## 1. The business model (what the system is supposed to do)

A company runs **projects** (for example "Expansion of AFIC"). Several **teams** work on one project. The intended hierarchy is:

```
Admin
└── Project  ── 1 Project Manager (PM)          projects.manager_id
     └── Team ── 1 Team Manager (TM)            teams.manager_id
          ├── 1 Team Lead                       teams.lead_id
          └── Members                           team_members
```

This hierarchy already exists in the database and already drives **timesheet approval** (`ApprovalChainHelper`). It is completely ignored by **tasks**. That is the flaw. Tasks must obey the same hierarchy.

Guiding principle: **the global role (admin / manager / employee / client) says which modules a person may use; their position in the hierarchy says what they may do on a specific project and team.** Position is resolved per project and per team, never globally.

---

## 2. Evidence from the live database (use these facts)

Workspace "Maven Projects LLP.", MariaDB 11.8.9.

**Users and roles:** 1 System Admin (admin). Managers by role: 2 Morgan Lee, 7 Sara Ahmed, 10 Hamza Raza (job title "Team Lead"), 15 Maham Iqbal. Employees: 3 John Carter, 4 Sarah Khan, 8 Usman Malik, 11 Fatima Shah, 13 Hira Ali, 14 Danish Khan, 16 Rummish Saleem, 17 Mubashir Hassan.

**Projects:** 1 Al Shifa Trust Eye Hospital (manager_id 10, private); 2 Citadel 7 Novacare Hospital (manager_id 2, private); 3 Expansion of AFIC (manager_id 1, **is_public = 1**); 4 Support Services Hub Novacare Hospital (manager_id 10, private).

**Teams (both in project 1):**
- Team 1 "Design Services": manager 10, lead 11, members 3, 7, 13, 14, 16.
- Team 2 "MEP": manager 1 (admin), lead 16, members 4, 7, 11, 13, 14, 15, 17.
- Projects 2, 3 and 4 have **no teams**.

**Role permissions actually granted (tasks / projects):**
- `employee`: `tasks.view`, **`tasks.edit`**, `projects.view`, time.track/view_own/edit_own. No `tasks.create`, `tasks.assign`, `tasks.delete`.
- `manager`: `tasks.view/create/edit/delete/assign`, `projects.view/create/edit/archive/manage_members`, `time.view_all`, `time.approve`. No `projects.view_all`.
- `admin`: everything. `client`: `projects.view` only.

**Workspace settings:** `task_creation_policy = admins_project_managers`, `project_creation_policy = admins_project_managers`, `hide_projects = 0`, `regular_user_time_visibility = own`, `default_project_visibility = private`, `edit_time_others_policy = admins_team_managers`.

**Tasks:** 17 rows, all created by user 1, all `status = 'To Do'`, none has a team. They are discipline buckets ("CON - Building Envelope", "TP - MEP + HVAC" ...). Only task 17 has assignees (13, 3, 1). The `tasks` table has no `team_id`.

**Data integrity problems already present:**
- User **13 (Hira Ali)** is in both teams of project 1 but has **no row in `project_members` for project 1**. Today she cannot be assigned a task there (the error says "Viewers cannot be assigned tasks", which is misleading) and cannot track time there.
- Users **7, 11, 13, 14, 16** are in **both** teams. User 11 leads Team 1 and is a member of Team 2. User 16 leads Team 2 and is a member of Team 1. Position must therefore be resolved **per team**.
- `project_members.project_role = 'manager'` rows disagree with `projects.manager_id`: project 1 has two manager rows (users 15 and 10) but `manager_id = 10`; project 2 has manager rows for users 2 and 3 but `manager_id = 2`. User 3 is an employee, user 15 is not the project manager.
- Team leads 11 and 16 are `employee` role, so **they cannot create tasks at all** today (no `tasks.create`, and the policy does not recognise team leads).

---

## 3. Flaws to fix (root causes)

| # | Flaw | Where | Effect today |
|---|---|---|---|
| F1 | `isProjectManager()` is not project-scoped: true if the user is `manager` by role **or** has `project_role='manager'` on **any** project | `WorkspacePolicy::isProjectManager`, `allowsByCreationPolicy` | Manager-role users 2, 7, 10, 15 can create and delete tasks in **any** project they can view, including public AFIC (project 3), even if they are not on it |
| F2 | Task edit / status / rename / assign / delete check only a **global** permission plus "can view project" | `TaskController::update/status/rename/assignees/destroy`, `loadTask`, `loadVisibleProject` | Any employee (has `tasks.edit`) can rename, change the status of, or complete **any** task on any project they can view, including other teams' tasks and, on a public project, tasks of a project they are not on. A `viewer` member is not blocked either |
| F3 | Tasks have no team | `tasks` table | Nothing says which team owns a task, so scope, review and visibility cannot be enforced |
| F4 | Assignment ignores teams | `TimeTrackingRules::assignableUserIds` | Team 1's lead can assign Team 2's people |
| F5 | Team membership and project membership are not synced | `TeamGroup::create/update` | People can be in a team but not on the project (user 13). Breaks assignment and time tracking |
| F6 | "Manager" means four different things (global role, `projects.manager_id`, `project_members.project_role='manager'`, `teams.manager_id`) | many files | Inconsistent permissions, stray manager rows |
| F7 | `Review` status exists but nobody has to review | `Task::setStatus`, `TaskController::status` | Anyone with `tasks.edit` can jump to Completed |
| F8 | Only admins can manage teams | `TeamGroupController` | PMs cannot set up teams of their own project |
| F9 | Time tracking on unassigned tasks is open to "anyone" on the project | `TimeTrackingRules::assertTrackableTask` | A team-owned task with no assignee would be open to other teams |
| F10 | Other code paths that write tasks or assignments bypass any policy | `InvitationService` (assigns tasks, projects, teams on accept), `ImportController` (imports tasks, task_assignees, project_members) | A scoped rule would be silently bypassed |

---

## 4. Target design

### 4.1 Positions (single source of truth)

Create one helper, `TaskPolicy` (or extend `ApprovalChainHelper`; reuse its per-request snapshot instead of adding new queries), with:

```
positionFor(int $userId, int $projectId, ?int $teamId): string
```

Return one of, highest first: `admin`, `pm`, `team_manager`, `team_lead`, `team_member`, `project_member` (on project, in no team), `viewer`, `none`.

Rules:
- `admin` = global role admin.
- `pm` = `projects.manager_id` of that project. **Only this.** `project_members.project_role = 'manager'` must no longer grant power.
- `team_manager` / `team_lead` / `team_member` are resolved for the **specific team** passed in (`teams.manager_id`, `teams.lead_id`, `team_members`). Someone can be lead of Team 2 and plain member of Team 1; that is resolved per team.
- `viewer` = `project_members.project_role = 'viewer'`. Also anyone who can see a public project but is not a member is `none` (read-only).
- The **global role `manager` grants nothing** on a specific project by itself. It only keeps its current meaning of "may be chosen as PM" (`ProjectController::managerOptions`).
- Inactive users and inactive teams (`teams.status <> 'active'`) hold no position.
- Provide `highestPositionInProject()` and `teamsOf($userId, $projectId)` for the UI.

### 4.2 Two gates on every task action

1. **Gate 1 – capability.** Keep `PermissionHelper::require('tasks.x')`, but treat it as satisfied when the person **either** has the permission **or** holds an approving position (lead, team manager, PM) in some project. Mirror the existing `ApprovalChainHelper::canAccessApprovals` pattern. This lets Team Leads (role `employee`) create tasks **without** changing `role_permissions`.
2. **Gate 2 – scope.** `TaskPolicy::can(string $action, ?array $task, array $project, ?int $teamId): bool` using the matrix below. Controllers call it after loading the task/project and **before** any write.

### 4.3 Permission matrix

"Own team" means a team where the person holds that position. "Task team" is `tasks.team_id`. `team_id IS NULL` means a **project-level task** owned by the PM.

| Action | Admin | PM | Team Manager | Team Lead | Member | Viewer / non-member |
|---|---|---|---|---|---|---|
| Create project-level task (no team) | yes | yes (own project) | no | no | no | no |
| Create team task | yes | yes, any team of own project | own team | own team | no (see setting S3) | no |
| Edit / rename / delete task | yes | any task in own project | tasks of own team | tasks of own team | no | no |
| Assign task to | anyone in project | anyone in project | people of own team (lead, members) | members of own team and self | no | no |
| Change status | any | any in project | tasks of own team | tasks of own team | **own assigned** tasks: To Do ↔ In Progress ↔ On Hold, and → Review. Never → Completed or Cancelled | no |
| Review (Review → Completed / back to In Progress) | yes | yes | yes, for lead and members of the team | yes, for members of the team | no | no |
| Cancel / reopen | yes | yes | own team | own team | no | no |
| View | all | all in project | own teams (see S2 for others) | own team (see S2) | own team and project-level (see S2) | read-only on visible projects |
| Manage teams of a project | yes | **yes, own project only (new)** | no | no | no | no |

Notes:
- A person may hold several positions. Evaluate against the **task's team**. User 11 may edit Team 1 tasks as lead but only change status of own assigned Team 2 tasks as member.
- On a project with **no teams** (projects 2, 3, 4 today), the PM acts as lead for everybody. Other members are plain `project_member`: status up to Review on tasks assigned to them, nothing else.
- Forged requests must fail: a lead posting `team_id` of another team gets 403. A PM may only choose teams of the project the task belongs to.
- A `parent_task_id` must be in the same project. Subtasks **inherit** the parent's `team_id` unless the actor is PM/admin and picks another valid team. A team lead may create a subtask under a project-level (NULL team) task **only** with their own team; the subtask then belongs to that team. This matches the existing structure (project-level discipline tasks such as "CON - Building Envelope", with teams adding child tasks).

### 4.4 Assignment rules

- Replace `TimeTrackingRules::assignableUserIds($project)` usage in task flows with `TaskPolicy::assignableIdsFor($actorId, $project, $teamId)`:
  - PM / admin: all non-viewer project members plus PM (current behaviour).
  - Team manager / lead: that team's lead, manager and members **who are also non-viewer members of the project** (see sync, 4.6), plus themselves.
  - For a project-level task assigned by PM: any non-viewer member.
- Fix the misleading message. Distinguish: "X is a viewer", "X is not on this project", "X is not in team <name>".
- Each assignee's rejection must name the person.

### 4.5 Task status workflow and review chain

Allowed transitions (enforce in `Task::setStatus` or a new `Task::assertTransition`, not only in the controller):

```
To Do → In Progress → Review → Completed
          ↑   ↓          ↓
        On Hold      back to In Progress (reviewer, reason required)
Any open status → Cancelled (lead+ of the task team, PM, admin)
Completed / Cancelled → In Progress (reopen: lead+ of the task team, PM, admin)
```

- **Reviewer of a task** = the next level above the assignee(s), reusing `ApprovalChainHelper` (same chain as timesheets, so they never disagree):
  - assigned to a member → team lead, team manager, PM, admin
  - assigned to the team lead → team manager, PM, admin
  - assigned to the team manager → PM, admin
  - assigned to the PM → admin
  - with several assignees, the reviewer must outrank **all** of them
  - **nobody reviews their own work**, and the creator is not automatically the reviewer
  - unassigned task: the team lead of the task team, or the PM for project-level tasks
- `ApprovalChainHelper` is scoped by project, not by team. Add a **team-scoped** variant (for example `approversForTeam($userId, $teamId)`) instead of re-implementing the chain, so someone in two teams does not route to the wrong manager.
- Rejection from Review requires a reason (store it, show it, notify the assignee).
- Moving to Completed sets `completion_percent = 100`, `reviewed_by`, `reviewed_at`.
- Setting `S4 task_review_required = 0` lets lead+ complete directly (members still cannot).

### 4.6 Membership sync (fixes F5, F6)

- Saving a team (`TeamGroup::create/update`) must **upsert `project_members`** for the team manager, lead and every member, as `project_role = 'member'` (never downgrade an existing `viewer` silently; report it instead and skip). Do it in the same DB transaction.
- `project_members.project_role = 'manager'` is reserved for the project manager. When a project's `manager_id` changes, set the new PM's row to `manager` and demote the previous PM's row to `member`. Stop writing `manager` for anyone else (`ProjectController::store/update/syncMembers/memberRole/addMembers`, `ImportController::projectMember`, `InvitationService`). `memberRole` must refuse to set `manager` for a person who is not `projects.manager_id`.
- Removing someone from a project must be blocked or must warn if they are the PM, a team manager or a team lead of a team in that project; removing a member from the project also removes them from that project's teams.
- Do **not** cascade project removal into task history. Existing assignees stay for audit but are flagged as "no longer on team" in the UI.

### 4.7 Visibility

- Project-level tasks: visible to everyone who can view the project.
- Team tasks: visible to the task's team (all positions), the PM, admins, and the assignees.
- Everybody else who can view the project sees other teams' tasks according to setting S2 (`readonly` default = visible but no controls; `hidden` = not listed).
- Public project (`is_public = 1`) lets everybody **view**, never mutate. Non-members and viewers have no write position.
- Clients: read-only on their own projects, every mutation endpoint returns 403.

### 4.8 Time tracking alignment (fixes F9)

`TimeTrackingRules::assertTrackableTask`:
- Assigned task: only assignees (unchanged).
- Unassigned **team** task: open only to members, lead and manager of that team.
- Unassigned **project-level** task: open to non-viewer project members (unchanged).
- Admins keep their existing exemption from permission checks, but not from data-integrity rules.
- The timer / manual-entry task pickers (`/time/tasks`, `/schedule/tasks`) must use the same rule so a person never sees a task they cannot track.

### 4.9 New workspace settings (register in `Workspace::DEFAULT_SETTINGS`, WorkspaceController, and the settings view)

| Key | Values | Default | Meaning |
|---|---|---|---|
| `task_scope_mode` | `legacy` / `strict` | **`legacy`** in the migration | Rollout switch. `legacy` = old behaviour, `strict` = everything in this spec. Lets us deploy safely and flip after testing, and gives an instant rollback |
| S2 `other_team_tasks_visibility` | `readonly` / `hidden` | `readonly` | What other teams' tasks look like to someone outside the team |
| S3 `members_can_create_subtasks` | `0` / `1` | `0` | Lets a member add subtasks under a task assigned to them (inherits team) |
| S4 `task_review_required` | `0` / `1` | `1` | Review step before Completed |

`task_creation_policy` keeps working but its meaning changes in strict mode: `admins` = admin only; `admins_project_managers` = admin, PM and **team managers/leads for their own scope**; `anyone` = still limited by scope, never cross-team. The setting must never widen scope beyond section 4.3.

---

## 5. Database changes (all idempotent, in `database/UPGRADE_LIVE.sql`, new STEP)

1. `tasks.team_id INT UNSIGNED NULL DEFAULT NULL` after `project_id`, index `idx_tasks_team`, FK `fk_tasks_team` → `teams(id)` **ON DELETE SET NULL ON UPDATE CASCADE**. Existing 17 tasks stay `NULL` = project-level. No backfill guessing.
2. `tasks.reviewed_by INT UNSIGNED NULL`, `tasks.reviewed_at DATETIME NULL`, `tasks.review_note VARCHAR(500) NULL`, FK `fk_tasks_reviewed_by` → `users(id)` ON DELETE SET NULL.
3. Optional hardening: integrity check that `tasks.team_id`'s team belongs to `tasks.project_id`. MariaDB cannot express this with a plain FK, so enforce it in `Task::create/update` **and** report violations in the checklist query.
4. Insert the new workspace settings with `INSERT IGNORE` (workspace_id 1 and every workspace row), default `task_scope_mode = 'legacy'`.
5. Extend the bottom checklist query: new columns, index, FK, settings present, and these data checks returning `OK` or a count:
   - team members missing from `project_members`
   - `project_role='manager'` rows that differ from `projects.manager_id`
   - tasks whose `team_id` team belongs to another project
   - task assignees who are `viewer` or not on the project
6. Provide `database/REPAIR_REPORT.sql` with **read-only** SELECTs for the above. On the live data it must list at least: user 13 missing from project 1; manager rows (project 1: user 15; project 2: user 3) that differ from `manager_id`.
7. Provide `tools/repair_hierarchy.php` (CLI only, like `tools/golive.php`): `--dry-run` default, `--apply` required to write. It (a) inserts missing `project_members` rows for team people as `member`, (b) demotes stray `manager` rows to `member`, (c) sets the true PM's row to `manager`. Every change is printed and written to the audit log. Never delete rows.
8. Provide a rollback section in `docs/DEPLOY.md`: set `task_scope_mode = 'legacy'`; the new columns are additive and harmless.

---

## 6. Implementation phases

### Phase 0 – Pre-flight
- Create a branch/working copy. Take the DB backup instruction into `docs/DEPLOY.md`.
- Check the web server PHP version is at least what the code needs (the dump header shows a PHP 7.2.34 for phpMyAdmin, but the app uses PHP 8.x syntax). Add a one-line check to `tools/` or `docs/DEPLOY.md`; do not change app syntax level.
- Run `php -l` on all files and record the baseline. Run `php tools/route_matrix.php` and save the output.

**Done when:** baseline recorded, no code changed.

### Phase 1 – Close the security holes (still no schema change)
- Implement `TaskPolicy` with positions (4.1) and the matrix (4.3), reading data from the existing `projects`, `teams`, `team_members`, `project_members` tables.
- Fix `WorkspacePolicy::isProjectManager`: replace with `isProjectManagerOf(int $projectId)` using `projects.manager_id` only. Keep a deprecated no-argument wrapper that is **only** used in legacy mode.
- Add the `task_scope_mode` setting. In `strict` mode every `TaskController` action (`store`, `update`, `status`, `rename`, `assignees`, `destroy`) and `ProjectController::show` flags use `TaskPolicy`; in `legacy` mode behaviour is unchanged.
- Forged-request safety: `rename` and `status` currently do not call `requireInstalled`/scope checks consistently. Make them consistent.
- JSON endpoints must return `{"ok":false,"message":"..."}` with HTTP 403 and a human message ("Only the lead or manager of <team> can edit this task").
- Make `ProjectController::memberRole` and `ProjectController::syncMembers` stop creating non-PM `manager` rows (4.6).
- Audit-log every denial through `LoggerHelper::warning` (already done by `deny()`; keep).

**Done when:** in strict mode, tests T1–T8, T14 (section 8) pass; in legacy mode nothing changed.

### Phase 2 – Data model and sync
- Apply the migration (section 5).
- `TeamGroup::create/update` upsert `project_members` in one transaction; warn on viewer conflicts.
- Allow the **PM to manage teams of their own project** (`TeamGroupController`): admin sees all projects, a PM sees and edits only teams where `projects.manager_id = self`. Project choice in the form is restricted accordingly. Keep a user's global `settings.manage` requirement for admins unchanged.
- Team delete confirmation must state how many tasks are currently assigned to that team; `ON DELETE SET NULL` will make them project-level; write that into the audit log.
- Update `InvitationService` and `ImportController` so they cannot create `manager` rows or team-less assignees that violate the rules; imports of `tasks` accept an optional `team` column (name, resolved within the project) and report rows that violate scope instead of silently inserting.
- Deliver the repair report and script (5.6, 5.7). Run them in `--dry-run` against the live dump and paste the output into your phase summary.

**Done when:** migration runs twice with all-OK checklist; team save leaves no team person missing from `project_members` (user 13 case); T9 passes.

### Phase 3 – Team-aware tasks, assignment, UI
- `Task::create/update` accept and validate `team_id`. Team lead/manager: `team_id` is forced to their own team (a dropdown only if they hold several positions in that project). PM/admin: any team of the project or none.
- `TaskController::resolveAssignees` / `assignableIds` use `TaskPolicy::assignableIdsFor`.
- `Task::` listing queries (`listForProject`, `findDetailed`, analytics that count tasks) return `team_id` and `team_name`; apply setting S2.
- `tasks/panel.php` and `form_modal.php`: add a **Team** column and filter, grouping by team (project-level first), and compute **per-task** flags (`canEdit`, `canAssign`, `canStatus`, `canReview`, `canDelete`) instead of the single page-level booleans currently passed by `ProjectController::show`. Controls the actor cannot use are not rendered, but the server still enforces them.
- Assignee picker lists only `assignableIdsFor(...)` people and shows each person's position badge (Lead, Manager, Member).
- `TimeTrackingRules::assertTrackableTask` and the task pickers (4.8).
- Notifications: new task → assignees (existing) plus FYI to the team manager and PM when a lead creates a task; implement through `NotificationHelper` using the existing pattern.

**Done when:** T1–T13 pass in strict mode on a staging copy of the live dump.

### Phase 4 – Review workflow
- Status state machine and reviewer resolution (4.5), team-scoped chain in `ApprovalChainHelper`.
- UI: "Send for review" for assignees; a **Review queue** list (tasks in Review that the current user may decide, scoped like the timesheet approval queue and sidebar badge); Approve / Return with reason.
- Notifications on submit-for-review, approved, returned.
- `ActivityLog`/`LoggerHelper::audit` entries: `task.review_requested`, `task.review_approved`, `task.review_returned`, with from/to status and reviewer.

**Done when:** T5, T15 pass; self-review is impossible even for a user who is both team lead and assignee.

### Phase 5 – Tests, docs, handover
- Extend `docs/STEP20_TEST_MATRIX.md` (role matrix rows by **position**, plus the tests below), `WorkspacePolicy::MATRIX` (new settings), `docs/LIVE_SCHEMA_DIFF.md`, `docs/DEPLOY.md` (migration order, repair script, rollout switch, rollback), and `tools/route_matrix.php` if it lists task routes.
- Write a short `docs/TASK_HIERARCHY.md`: the positions, the matrix, the review chain, and the settings, in plain language for administrators.
- Final report: files changed, migration steps, rollout steps (see section 9), residual risks.

---

## 7. Edge cases the implementation must handle

1. A person in two teams of the same project (users 7, 11, 13, 14, 16): position is resolved from the **task's** team, never "highest across teams".
2. Lead of Team 2 who is a member of Team 1 (user 16): may edit Team 2 tasks, may only update status of tasks assigned to them in Team 1.
3. PM who is also a team manager (user 10 is PM of project 1 **and** manager of Team 1): holds both; PM scope wins, no double-listing in approver lists.
4. Team manager who is an admin (Team 2 manager = user 1): admin scope applies; admin's own tasks are reviewed by other admins only (existing rule).
5. Team lead or manager removed or deactivated: their open tasks stay; review of tasks assigned to them falls up the chain; nothing is orphaned.
6. Team set to inactive, or deleted: tasks keep working (`team_id` kept while inactive; `NULL` after delete); the PM sees them.
7. Project with no teams (projects 2, 3, 4): PM-only management, members update their own status up to Review. No regression in behaviour for these projects.
8. Public project (AFIC): everybody can read, nobody outside the hierarchy can write.
9. Task moved between teams by PM: assignees who are not in the new team are listed in a warning and must be reassigned or kept explicitly (PM choice); never silently dropped.
10. Parent/child: subtask team mismatch with parent, and the existing recalculation of ancestor completion (`recalculateAncestors`) must still work.
11. Archived projects stay closed to new tasks (existing check `assertProjectOpen`).
12. A viewer-role project member who is also a team member: viewer wins, read-only.
13. Concurrency: two reviewers approving the same task; use a conditional UPDATE (`WHERE status='Review'`) and report the second as already handled.
14. Imports and invitations must not be able to write rows that the UI would reject.

---

## 8. Acceptance tests (use the live users; run as each user, UI **and** raw POST)

Project 1 has Team 1 "Design Services" (TM 10, lead 11, members 3, 7, 13, 14, 16) and Team 2 "MEP" (TM 1, lead 16, members 4, 7, 11, 13, 14, 15, 17). PM of project 1 is user 10.

| # | As | Action | Expected |
|---|---|---|---|
| T1 | 11 (lead T1, employee role) | Create task in project 1 | Allowed; `team_id = 1` set automatically |
| T1b | 11 | Assign it to user 3; to user 11; to user 4 | OK; OK; **422** "Sarah Khan is not in team Design Services" |
| T2 | 11 | Forge `team_id = 2` on create | **403** (member only in T2) |
| T3 | 16 (lead T2, member T1) | Edit a Team 2 task; edit a Team 1 task | OK; **403** |
| T4 | 3 (member T1) | On own assigned Team 1 task: → In Progress; → Review; → Completed; rename; delete; assign | OK; OK; **403** (needs review); **403**; **403**; **403** |
| T4b | 3 | Change status of a Team 2 task, and of a Team 1 task not assigned to them | **403**, **403** |
| T5 | 11 | Approve user 3's task in Review; approve a Team 1 task assigned to himself | OK; **403** (self); user 10 can approve the latter; user 16 (peer lead of another team) cannot |
| T6 | 10 (PM project 1) | Edit/assign/delete any task in project 1; touch project 2 tasks; create in AFIC | OK; **403**; **403** |
| T7 | 7 and 15 (manager role, not PM) | Create and delete task in AFIC (project 3) | **403** (today allowed) |
| T8 | 2 (PM project 2, no teams) | Create, assign, delete in project 2 | OK; task has `team_id NULL` |
| T9 | Repair | Run `repair_hierarchy.php --apply`, then 11 assigns user 13 to a Team 1 task | OK (13 now in `project_members`) |
| T10 | 1 (admin) | Everything; existing tasks 1–17 still list as project-level; task 17's assignees (13, 3, 1) still shown | OK |
| T11 | client user | Any POST to the 6 task routes | **403** |
| T12 | 3 and 4 | Start a timer on an unassigned Team 1 task | 3 OK; 4 **403** |
| T13 | 1 | Delete Team 1 with open tasks | Warning shows count; tasks become project-level; audit entry written |
| T14 | all roles | `curl` each task route directly with a valid CSRF token | Same result as the UI; never a 500 |
| T15 | 3 → 11 | Member sends to Review; lead returns with reason; member resubmits; lead approves | Statuses, notes, notifications and audit entries correct |
| T16 | strict vs legacy | Flip `task_scope_mode` back and forth | Behaviour switches instantly, no data change |

Also run the existing `docs/STEP20_TEST_MATRIX.md` suite and the "direct URL authorization checklist"; nothing that passed before may fail.

---

## 9. Rollout plan (include in `docs/DEPLOY.md`)

1. Full DB and file backup.
2. Deploy code with `task_scope_mode = legacy` (no behaviour change).
3. Run `database/UPGRADE_LIVE.sql` (twice; checklist all OK).
4. Run `database/REPAIR_REPORT.sql`, review, then `php tools/repair_hierarchy.php --dry-run`, then `--apply`.
5. On staging (copy of the dump), switch to `strict` and run section 8.
6. Tell users: leads and team managers can now create and assign tasks for their team; members complete tasks by sending them for review.
7. Switch production to `strict` outside working hours; watch `storage/logs` for "Workspace policy denied" in the first days.
8. Rollback = set `task_scope_mode` back to `legacy`.

---

## 10. Non-goals

- No cross-team task requests or approval-before-create for lead-created tasks. If a lead tries to assign across teams, return a clear message telling them to ask the project manager.
- No change to timesheet approval logic beyond adding the team-scoped helper used by tasks.
- No change to client/invoice/report modules, authentication, sessions, or the desktop agent.
- No new role names. Positions are derived from the existing tables.
- No automatic data changes outside the dry-run-first repair script.

---

## 11. Deliverables and output format

For each phase give me:
1. A list of every file created or changed (full paths).
2. The complete code for new files and a unified diff (or full replacement file) for changed files.
3. The SQL for the migration, report and checklist additions.
4. The exact test steps run, with results.
5. Assumptions made and risks left.

**Definition of done:** all of section 8 passes in strict mode, legacy mode is unchanged, the migration is repeatable, every changed PHP file lints clean, docs are updated, and no task write path (UI, JSON, import, invitation) can bypass the position rules.
