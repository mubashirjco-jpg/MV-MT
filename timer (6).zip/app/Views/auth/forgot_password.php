<?php
/**
 * Request a password reset email.
 */

$appName = SettingsService::appName();
$flashes = flash_pull();
$emailError = field_error('email');
?>
<div class="login-page">
    <section class="login-aside" aria-hidden="true">
        <div class="login-aside-inner">
            <div class="brand-link">
                <?= BrandingHelper::mark() ?>
                <span class="brand-name"><?= e($appName) ?></span>
            </div>
            <p class="login-claim">Reset your password.</p>
            <p class="login-sub">If that email is on an account, we send a single-use link.</p>
        </div>
    </section>
    <main class="login-main" id="main-content">
        <div class="login-card">
            <h1 class="login-title">Forgot password</h1>
            <p class="login-lead">Enter the email for your account.</p>

            <?php foreach ($flashes as $type => $messages): ?>
                <?php foreach ((array) $messages as $message): ?>
                    <div class="alert alert-<?= e($type) ?>" role="<?= $type === 'danger' ? 'alert' : 'status' ?>"><?= e($message) ?></div>
                <?php endforeach; ?>
            <?php endforeach; ?>

            <form method="post" action="<?= e(url('/forgot-password')) ?>" novalidate data-single-submit>
                <?= csrf_field() ?>
                <div class="mb-4">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" id="email" name="email" required autocomplete="username"
                           class="form-control form-control-lg<?= $emailError !== null ? ' is-invalid' : '' ?>"
                           value="<?= e(old('email')) ?>">
                    <?php if ($emailError !== null): ?><div class="invalid-feedback"><?= e($emailError) ?></div><?php endif; ?>
                </div>
                <button type="submit" class="btn btn-primary btn-lg w-100">Send reset link</button>
            </form>
            <p class="login-foot"><a href="<?= e(url('/login')) ?>">Back to sign in</a></p>
        </div>
    </main>
</div>
