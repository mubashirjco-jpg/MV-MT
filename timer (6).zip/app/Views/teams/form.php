<?php
/**
 * Create / edit a department with nested team managers and members.
 *
 * @var array<string, mixed>|null $department
 * @var list<array{id: int, name: string, manager_id: int, member_ids: list<int>}> $teamBlocks
 * @var int $projectId
 * @var list<array<string, mixed>> $projects
 * @var list<array<string, mixed>> $people
 * @var list<string> $statuses
 */

$isEdit  = is_array($department);
$action  = $isEdit ? '/teams/' . (int) $department['id'] : '/teams';
$hasOld  = old('name') !== '' || old('project_id') !== '';

$name    = $hasOld ? old('name') : (string) ($department['name'] ?? '');
$selProj = $hasOld ? (int) old('project_id', '0') : $projectId;
$selMgr  = $hasOld ? (int) old('manager_id', '0') : (int) ($department['manager_id'] ?? 0);
$selStat = $hasOld ? old('status', 'active') : (string) ($department['status'] ?? 'active');

if ($teamBlocks === []) {
    $teamBlocks = [['id' => 0, 'name' => '', 'manager_id' => 0, 'member_ids' => []]];
}

$roleLabel = static function (string $role): string {
    return $role === 'employee' ? 'Member' : ucfirst($role);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading"><?= $isEdit ? 'Edit department' : 'New department' ?></h2>
        <p class="page-lead">A department sits under one project. Add a department manager, then team managers and their members.</p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= e(url('/teams')) ?>">Back to departments</a>
</div>

<div class="row">
    <div class="col-lg-10">
        <section class="panel">
            <form method="post" action="<?= e(url($action)) ?>" novalidate id="department-form">
                <?= csrf_field() ?>
                <div class="row g-3">
                    <div class="col-md-6">
                        <label for="team-name" class="form-label">Department name</label>
                        <input type="text" id="team-name" name="name" maxlength="120" required
                               class="form-control<?= field_error('name') ? ' is-invalid' : '' ?>" value="<?= e($name) ?>">
                        <?php if (field_error('name')): ?><div class="invalid-feedback"><?= e(field_error('name')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label for="team-project-id" class="form-label">Project</label>
                        <select id="team-project-id" name="project_id" required class="form-select<?= field_error('project_id') ? ' is-invalid' : '' ?>">
                            <option value="">Choose a project</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= (int) $project['id'] ?>"<?= $selProj === (int) $project['id'] ? ' selected' : '' ?>>
                                    <?= e((string) $project['name']) ?> — PM: <?= !empty($project['manager_name']) ? e((string) $project['manager_name']) : 'not set' ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('project_id')): ?><div class="invalid-feedback"><?= e(field_error('project_id')) ?></div><?php endif; ?>
                        <div class="form-text">The project manager of this project approves for every department in it.</div>
                    </div>
                    <div class="col-md-8">
                        <label for="dept-manager" class="form-label">Department manager</label>
                        <select id="dept-manager" name="manager_id" class="form-select<?= field_error('manager_id') ? ' is-invalid' : '' ?>">
                            <option value="0">None</option>
                            <?php foreach ($people as $person): ?>
                                <option value="<?= (int) $person['id'] ?>"<?= $selMgr === (int) $person['id'] ? ' selected' : '' ?>><?= e((string) $person['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php if (field_error('manager_id')): ?><div class="invalid-feedback"><?= e(field_error('manager_id')) ?></div><?php endif; ?>
                    </div>
                    <div class="col-md-4">
                        <label for="team-status" class="form-label">Status</label>
                        <select id="team-status" name="status" class="form-select">
                            <?php foreach ($statuses as $status): ?>
                                <option value="<?= e($status) ?>"<?= $selStat === $status ? ' selected' : '' ?>><?= e(ucfirst($status)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <hr class="my-4">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h3 class="h6 mb-0">Team managers</h3>
                        <p class="small text-muted mb-0">Each team manager has their own members. Members of Team A do not belong to Team B.</p>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-primary" data-add-team>
                        <i class="fa-solid fa-plus me-1" aria-hidden="true"></i>Add team manager
                    </button>
                </div>

                <div data-team-list>
                    <?php foreach ($teamBlocks as $i => $block): ?>
                        <?php
                        $blockName = (string) ($block['name'] ?? '');
                        $blockMgr  = (int) ($block['manager_id'] ?? 0);
                        $blockIds  = array_map('intval', $block['member_ids'] ?? []);
                        $blockPk   = (int) ($block['id'] ?? 0);
                        $mgrErr    = field_error('teams.' . $i . '.manager_id');
                        $nameErr   = field_error('teams.' . $i . '.name');
                        ?>
                        <div class="team-block border rounded p-3 mb-3" data-team-block>
                            <input type="hidden" name="teams[<?= $i ?>][id]" value="<?= $blockPk ?>">
                            <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
                                <strong class="small text-muted" data-team-label>Team <?= $i + 1 ?></strong>
                                <button type="button" class="btn btn-sm btn-outline-danger" data-remove-team>Remove</button>
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">Team name</label>
                                    <input type="text" name="teams[<?= $i ?>][name]" maxlength="120"
                                           class="form-control<?= $nameErr ? ' is-invalid' : '' ?>" value="<?= e($blockName) ?>" placeholder="e.g. Team A">
                                    <?php if ($nameErr): ?><div class="invalid-feedback"><?= e($nameErr) ?></div><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">Team manager</label>
                                    <select name="teams[<?= $i ?>][manager_id]" class="form-select<?= $mgrErr ? ' is-invalid' : '' ?>" data-team-manager>
                                        <option value="0">None</option>
                                        <?php foreach ($people as $person): ?>
                                            <option value="<?= (int) $person['id'] ?>"<?= $blockMgr === (int) $person['id'] ? ' selected' : '' ?>><?= e((string) $person['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if ($mgrErr): ?><div class="invalid-feedback"><?= e($mgrErr) ?></div><?php endif; ?>
                                </div>
                                <div class="col-12">
                                    <div class="d-flex justify-content-between align-items-end mb-1">
                                        <label class="form-label mb-0">Team members</label>
                                        <input type="search" class="form-control form-control-sm w-auto" placeholder="Filter people" aria-label="Filter people" data-team-filter>
                                    </div>
                                    <div class="border rounded p-2" style="max-height:220px;overflow:auto" data-team-members>
                                        <?php foreach ($people as $person): ?>
                                            <div class="form-check" data-team-person data-name="<?= e(mb_strtolower((string) $person['name'], 'UTF-8')) ?>" data-user-id="<?= (int) $person['id'] ?>">
                                                <input class="form-check-input" type="checkbox" name="teams[<?= $i ?>][member_ids][]" id="member-<?= $i ?>-<?= (int) $person['id'] ?>"
                                                       value="<?= (int) $person['id'] ?>"<?= in_array((int) $person['id'], $blockIds, true) ? ' checked' : '' ?>>
                                                <label class="form-check-label" for="member-<?= $i ?>-<?= (int) $person['id'] ?>">
                                                    <?= e((string) $person['name']) ?> <span class="text-muted small">(<?= e($roleLabel((string) $person['role'])) ?>)</span>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="form-text">The department manager and this team manager are chosen above and do not need to be ticked here.</div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="mt-4 d-flex gap-2 flex-wrap">
                    <button type="submit" class="btn btn-primary"><?= $isEdit ? 'Save department' : 'Create department' ?></button>
                    <a class="btn btn-outline-secondary" href="<?= e(url('/teams')) ?>">Cancel</a>
                </div>
            </form>
        </section>
    </div>
</div>
<template id="team-block-template">
    <div class="team-block border rounded p-3 mb-3" data-team-block>
        <input type="hidden" name="teams[__INDEX__][id]" value="0">
        <div class="d-flex justify-content-between align-items-start gap-2 mb-2">
            <strong class="small text-muted" data-team-label>Team</strong>
            <button type="button" class="btn btn-sm btn-outline-danger" data-remove-team>Remove</button>
        </div>
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Team name</label>
                <input type="text" name="teams[__INDEX__][name]" maxlength="120" class="form-control" placeholder="e.g. Team A">
            </div>
            <div class="col-md-6">
                <label class="form-label">Team manager</label>
                <select name="teams[__INDEX__][manager_id]" class="form-select" data-team-manager>
                    <option value="0">None</option>
                    <?php foreach ($people as $person): ?>
                        <option value="<?= (int) $person['id'] ?>"><?= e((string) $person['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-end mb-1">
                    <label class="form-label mb-0">Team members</label>
                    <input type="search" class="form-control form-control-sm w-auto" placeholder="Filter people" aria-label="Filter people" data-team-filter>
                </div>
                <div class="border rounded p-2" style="max-height:220px;overflow:auto" data-team-members>
                    <?php foreach ($people as $person): ?>
                        <div class="form-check" data-team-person data-name="<?= e(mb_strtolower((string) $person['name'], 'UTF-8')) ?>" data-user-id="<?= (int) $person['id'] ?>">
                            <input class="form-check-input" type="checkbox" name="teams[__INDEX__][member_ids][]" id="member-__INDEX__-<?= (int) $person['id'] ?>"
                                   value="<?= (int) $person['id'] ?>">
                            <label class="form-check-label" for="member-__INDEX__-<?= (int) $person['id'] ?>">
                                <?= e((string) $person['name']) ?> <span class="text-muted small">(<?= e($roleLabel((string) $person['role'])) ?>)</span>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="form-text">The department manager and this team manager are chosen above and do not need to be ticked here.</div>
            </div>
        </div>
    </div>
</template>
<script src="<?= e(asset('js/team-form.js')) ?>"></script>
