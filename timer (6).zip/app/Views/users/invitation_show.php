<?php
/**
 * Invitation detail.
 *
 * @var array<string, mixed> $invitation
 * @var bool $canManage
 */

$status = (string) $invitation['status'];
$open = in_array($status, ['pending', 'sent', 'expired'], true);
$statusClass = match ($status) {
    'sent' => 'status-active',
    'pending' => 'status-hold',
    'accepted' => 'status-completed',
    'expired' => 'status-inactive',
    'cancelled' => 'status-cancelled',
    default => 'status-planning',
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Invitation</h2>
        <p class="page-lead"><?= e((string) $invitation['email']) ?></p>
    </div>
    <a class="btn btn-outline-secondary" href="<?= e(url('/users/invitations')) ?>"><i class="fa-solid fa-arrow-left me-1" aria-hidden="true"></i>Back</a>
</div>

<div class="row g-4">
    <div class="col-xl-8">
        <section class="panel mb-4">
            <div class="panel-head">
                <h2 class="panel-title">Details</h2>
                <span class="status-badge <?= e($statusClass) ?>"><?= e(ucfirst($status)) ?></span>
            </div>
            <dl class="facts panel-body">
                <div><dt>Name</dt><dd><?= e((string) $invitation['name']) ?></dd></div>
                <div><dt>Email</dt><dd><?= e((string) $invitation['email']) ?></dd></div>
                <div><dt>Role</dt><dd><span class="role-pill role-<?= e(strtolower((string) $invitation['role'])) ?>"><?= e((string) $invitation['role_name']) ?></span></dd></div>
                <div><dt>Job title</dt><dd><?= e((string) ($invitation['job_title'] ?? '')) ?: '—' ?></dd></div>
                <div><dt>Account after accept</dt><dd><?= e(ucfirst((string) ($invitation['account_status'] ?? 'active'))) ?></dd></div>
                <div><dt>Invited by</dt><dd><?= e((string) ($invitation['invited_by_name'] ?? '—')) ?></dd></div>
                <div><dt>Created</dt><dd><?= e(FormatHelper::datetime((string) $invitation['created_at'], 'M j, Y H:i')) ?></dd></div>
                <div><dt>Expires</dt><dd><?= e(FormatHelper::datetime((string) $invitation['expires_at'], 'M j, Y H:i')) ?></dd></div>
                <div><dt>Accepted</dt><dd><?= !empty($invitation['accepted_at']) ? e(FormatHelper::datetime((string) $invitation['accepted_at'], 'M j, Y H:i')) : '—' ?></dd></div>
                <div><dt>Last sent</dt><dd><?= !empty($invitation['last_sent_at']) ? e(FormatHelper::datetime((string) $invitation['last_sent_at'], 'M j, Y H:i')) : 'Never' ?></dd></div>
                <div><dt>Send count</dt><dd><?= (int) ($invitation['send_count'] ?? 0) ?></dd></div>
            </dl>
        </section>

        <section class="panel mb-4">
            <div class="panel-head"><h2 class="panel-title">Projects</h2></div>
            <div class="panel-body">
                <?php if (empty($invitation['projects'])): ?>
                    <p class="text-secondary mb-0">None selected.</p>
                <?php else: ?>
                    <ul class="mb-0">
                        <?php foreach ($invitation['projects'] as $project): ?>
                            <li><?= e((string) $project['name']) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </section>

        <section class="panel mb-4">
            <div class="panel-head"><h2 class="panel-title">Tasks</h2></div>
            <div class="panel-body">
                <?php if (empty($invitation['tasks'])): ?>
                    <p class="text-secondary mb-0">None selected.</p>
                <?php else: ?>
                    <ul class="mb-0">
                        <?php foreach ($invitation['tasks'] as $task): ?>
                            <li><?= e((string) $task['project_name']) ?> — <?= e((string) $task['name']) ?></li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </section>

        <?php if (!empty($invitation['teams'])): ?>
            <section class="panel mb-4">
                <div class="panel-head"><h2 class="panel-title">Teams</h2></div>
                <div class="panel-body">
                    <ul class="mb-0">
                        <?php foreach ($invitation['teams'] as $team): ?>
                            <li><?= e((string) $team['name']) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </section>
        <?php endif; ?>

        <?php if ($canManage && $open): ?>
            <div class="d-flex gap-2">
                <form method="post" action="<?= e(url('/users/invitations/' . (int) $invitation['id'] . '/resend')) ?>" data-confirm="Resend this invitation? The previous link will stop working.">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-primary">Resend</button>
                </form>
                <form method="post" action="<?= e(url('/users/invitations/' . (int) $invitation['id'] . '/cancel')) ?>" data-confirm="Cancel this invitation?">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-outline-danger">Cancel</button>
                </form>
            </div>
        <?php endif; ?>
    </div>
</div>
