<?php
/**
 * Invitation list.
 *
 * @var array{items: list<array<string, mixed>>, total: int, page: int, per_page: int, pages: int} $result
 * @var array{q: string, status: string} $filters
 * @var list<string> $statuses
 * @var bool $canManage
 * @var bool $smtpReady
 */

$items = $result['items'];
$page = (int) $result['page'];
$pages = (int) $result['pages'];

$statusClass = static fn (string $status): string => match ($status) {
    'sent' => 'status-active',
    'pending' => 'status-hold',
    'accepted' => 'status-completed',
    'expired' => 'status-inactive',
    'cancelled' => 'status-cancelled',
    default => 'status-planning',
};

$query = static function (array $extra = []) use ($filters): string {
    $params = array_filter([
        'q' => $extra['q'] ?? $filters['q'],
        'status' => ($extra['status'] ?? $filters['status']) !== 'all' ? ($extra['status'] ?? $filters['status']) : null,
        'page' => $extra['page'] ?? null,
    ], static fn ($v): bool => $v !== null && $v !== '');

    return $params === [] ? '' : '?' . http_build_query($params);
};
?>
<div class="page-toolbar">
    <div>
        <h2 class="page-heading">Invitations</h2>
        <p class="page-lead">Pending, sent, accepted and cancelled invitation emails.</p>
    </div>
    <div class="d-flex gap-2 flex-wrap">
        <a class="btn btn-outline-secondary" href="<?= e(url('/users')) ?>">Users</a>
        <?php if ($canManage): ?>
            <a class="btn btn-primary" href="<?= e(url('/users/invite')) ?>">
                <i class="fa-solid fa-envelope me-1" aria-hidden="true"></i>Invite user
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if (!$smtpReady): ?>
    <div class="alert alert-warning" role="status">
        SMTP is not configured. Invitations stay pending until you add a mail server in
        <a href="<?= e(url('/settings#smtp')) ?>">System settings</a>.
    </div>
<?php endif; ?>

<form method="get" action="<?= e(url('/users/invitations')) ?>" class="filter-bar">
    <div class="filter-search">
        <label for="invite-q" class="visually-hidden">Search invitations</label>
        <input type="search" id="invite-q" name="q" class="form-control" placeholder="Search name or email" value="<?= e($filters['q']) ?>">
    </div>
    <div>
        <label for="invite-status" class="visually-hidden">Status</label>
        <select id="invite-status" name="status" class="form-select">
            <option value="all">All statuses</option>
            <?php foreach ($statuses as $status): ?>
                <option value="<?= e($status) ?>"<?= $filters['status'] === $status ? ' selected' : '' ?>><?= e(ucfirst($status)) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <button type="submit" class="btn btn-outline-secondary">Filter</button>
</form>

<section class="panel">
    <div class="panel-head">
        <h2 class="panel-title">Invitations <span class="count-pill"><?= (int) $result['total'] ?></span></h2>
    </div>

    <?php if ($items === []): ?>
        <div class="empty-state">
            <i class="fa-regular fa-envelope" aria-hidden="true"></i>
            <p>No invitations match these filters.</p>
        </div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table data-table table-stack mb-0">
                <thead>
                    <tr>
                        <th>Invited user</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Team</th>
                        <th>Invited by</th>
                        <th>Status</th>
                        <th>Expires</th>
                        <th>Last sent</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $row): ?>
                        <?php
                        $status = (string) $row['status'];
                        $open = in_array($status, ['pending', 'sent', 'expired'], true);
                        ?>
                        <tr>
                            <td data-label="Invited user">
                                <strong><?= e((string) $row['name']) ?></strong>
                                <?php if (!empty($row['job_title'])): ?><span class="d-block text-secondary small"><?= e((string) $row['job_title']) ?></span><?php endif; ?>
                            </td>
                            <td data-label="Email"><?= e((string) $row['email']) ?></td>
                            <td data-label="Role"><span class="role-pill role-<?= e(strtolower((string) $row['role'])) ?>"><?= e((string) $row['role_name']) ?></span></td>
                            <td data-label="Team"><?php
                                $teamNames = array_map(static fn (array $t): string => (string) $t['name'], $row['teams'] ?? []);
                                echo $teamNames === [] ? '<span class="text-secondary">—</span>' : e(implode(', ', $teamNames));
                            ?></td>
                            <td data-label="Invited by"><?= e((string) ($row['invited_by_name'] ?? '—')) ?></td>
                            <td data-label="Status"><span class="status-badge <?= e($statusClass($status)) ?>"><?= e(ucfirst($status)) ?></span></td>
                            <td data-label="Expires"><?= e(FormatHelper::datetime((string) $row['expires_at'], 'M j, Y H:i')) ?></td>
                            <td data-label="Last sent"><?= !empty($row['last_sent_at']) ? e(FormatHelper::datetime((string) $row['last_sent_at'], 'M j, Y H:i')) : '<span class="text-secondary">Never</span>' ?></td>
                            <td data-label="Actions" class="text-end text-nowrap">
                                <a class="btn btn-sm btn-outline-secondary" href="<?= e(url('/users/invitations/' . (int) $row['id'])) ?>">View</a>
                                <?php if ($canManage && $open): ?>
                                    <form method="post" action="<?= e(url('/users/invitations/' . (int) $row['id'] . '/resend')) ?>" class="d-inline" data-confirm="Resend this invitation? The previous link will stop working.">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-secondary">Resend</button>
                                    </form>
                                    <form method="post" action="<?= e(url('/users/invitations/' . (int) $row['id'] . '/cancel')) ?>" class="d-inline" data-confirm="Cancel this invitation?">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">Cancel</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php if ($pages > 1): ?>
            <nav class="pager" aria-label="Invitation pages">
                <?php for ($p = 1; $p <= $pages; $p++): ?>
                    <a class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-outline-secondary' ?>" href="<?= e(url('/users/invitations') . $query(['page' => $p])) ?>"><?= $p ?></a>
                <?php endfor; ?>
            </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>
