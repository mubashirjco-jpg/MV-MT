<?php
declare(strict_types=1);

/**
 * Dashboard for admins, managers and members (Clockify-style):
 * summary strip, stacked daily chart, project donut + ranking, activities table.
 * Admins/managers also get a per-team overview. Members keep schedule, tasks and recent entries below.
 *
 * @var array<string, mixed> $week
 * @var bool $canTrack
 * @var bool $canApprove
 * @var int $pendingApprovals
 * @var int $unread
 * @var list<array<string, mixed>> $notifications
 * @var bool $showWhoSwitch
 * @var string $audience
 */

$dur = static fn (int $s): string => FormatHelper::duration($s);
$dashUrl = static fn (array $q): string => url('/dashboard') . '?' . http_build_query($q);
$who = !empty($week['only_me']) ? 'me' : 'team';
$periodTitle = match ((string) ($week['range'] ?? 'week')) { 'today' => 'today', 'month' => 'this month', 'last30' => 'last 30 days', 'past2weeks' => 'past two weeks', 'year' => 'this year', default => !empty($week['is_current']) ? 'this week' : 'selected period' };

// Chart payload: one dataset per project, one value (hours) per weekday.
$labels   = [];
$totals   = [];
foreach ($week['days'] as $day) {
    $labels[] = $day['label'];
    $totals[] = (int) $day['seconds'];
}
$datasets = [];
foreach ($week['projects'] as $p) {
    $series = [];
    foreach ($week['days'] as $day) {
        $series[] = round(((int) ($day['projects'][$p['id']] ?? 0)) / 3600, 4);
    }
    $datasets[] = ['label' => $p['name'], 'color' => $p['color'], 'data' => $series];
}
$donut = [
    'labels' => array_map(static fn (array $p): string => $p['name'], $week['projects']),
    'data'   => array_map(static fn (array $p): int => (int) $p['seconds'], $week['projects']),
    'colors' => array_map(static fn (array $p): string => $p['color'], $week['projects']),
];
$json = static fn (mixed $v): string => e((string) json_encode($v, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT));

$maxPerson = 0;
foreach ($week['people'] as $person) {
    $maxPerson = max($maxPerson, (int) $person['total']);
}
?>
<div class="wk-head">
    <h2 class="wk-title">Dashboard</h2>
    <div class="wk-controls">
        <?php if (!empty($canApprove) && FeatureFlagsHelper::timeApprovalEnabled() && (int) $pendingApprovals > 0): ?>
            <a class="wk-pill" href="<?= e(url('/timesheets/team')) ?>"><i class="fa-solid fa-clipboard-check" aria-hidden="true"></i> <?= (int) $pendingApprovals ?> pending approval<?= (int) $pendingApprovals === 1 ? '' : 's' ?></a>
        <?php endif; ?>

        <?php if (!empty($showWhoSwitch)): ?>
        <div class="dropdown">
            <button class="wk-select dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?= $who === 'me' ? 'Only me' : 'Team' ?>
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item<?= $who === 'team' ? ' active' : '' ?>" href="<?= e($dashUrl(['range' => $week['range'] ?? 'week', 'date' => $week['anchor_date'] ?? $week['week_start'], 'who' => 'team'])) ?>">Team</a></li>
                <li><a class="dropdown-item<?= $who === 'me' ? ' active' : '' ?>" href="<?= e($dashUrl(['range' => $week['range'] ?? 'week', 'date' => $week['anchor_date'] ?? $week['week_start'], 'who' => 'me'])) ?>">Only me</a></li>
            </ul>
        </div>
        <?php endif; ?>

        <?php $range = (string) ($week['range'] ?? 'week'); $anchor = (string) ($week['anchor_date'] ?? $week['week_start']); ?>
        <?php $dashboardRange = $week; ?>
        <?php include APP_PATH . '/Views/dashboard/date_picker.php'; ?>

        <div class="wk-range">
            <a class="wk-range-btn" href="<?= e($dashUrl(['range' => $range, 'date' => $week['prev_date'] ?? $week['prev_week'], 'who' => $who])) ?>" aria-label="Previous period"><i class="fa-solid fa-chevron-left" aria-hidden="true"></i></a>
            <a class="wk-range-btn" href="<?= e($dashUrl(['range' => $range, 'date' => $week['next_date'] ?? $week['next_week'], 'who' => $who])) ?>" aria-label="Next period"><i class="fa-solid fa-chevron-right" aria-hidden="true"></i></a>
        </div>
    </div>
</div>

<section class="wk-card">
    <div class="wk-summary">
        <div>
            <span class="wk-summary-label">Total time</span>
            <strong><?= e($dur((int) $week['total'])) ?></strong>
        </div>
        <div>
            <span class="wk-summary-label">Top Project</span>
            <strong class="text-truncate"><?= e($week['top_project']['name'] ?? '—') ?></strong>
        </div>
        <div>
            <span class="wk-summary-label">Top Client</span>
            <strong class="text-truncate"><?= e($week['top_client']['name'] ?? '—') ?></strong>
        </div>
    </div>

    <div class="wk-chart-wrap">
        <canvas id="weekStackChart"
                data-labels="<?= $json($labels) ?>"
                data-datasets="<?= $json($datasets) ?>"
                data-totals="<?= $json($totals) ?>"></canvas>
    </div>

    <div class="wk-breakdown">
        <div class="wk-donut-wrap">
            <?php if ($week['projects'] !== []): ?>
                <canvas id="weekDonutChart" data-donut="<?= $json($donut) ?>"></canvas>
                <div class="wk-donut-center"><?= e($dur((int) $week['total'])) ?></div>
            <?php else: ?>
                <div class="wk-empty">No time tracked in this period.</div>
            <?php endif; ?>
        </div>

        <ul class="wk-rank">
            <?php foreach ($week['projects'] as $p): ?>
                <li>
                    <span class="wk-rank-name">
                        <a href="<?= e(url('/projects/' . (int) $p['id'])) ?>"><?= e($p['name']) ?></a>
                        <?php if ($p['client'] !== ''): ?><span class="wk-rank-client"> - <?= e($p['client']) ?></span><?php endif; ?>
                    </span>
                    <span class="wk-rank-time"><?= e($dur((int) $p['seconds'])) ?></span>
                    <span class="wk-rank-bar"><span style="width: <?= e((string) min(100, $p['percent'])) ?>%; background: <?= e($p['color']) ?>"></span></span>
                    <span class="wk-rank-pct"><?= e(number_format((float) $p['percent'], 2, ',', '')) ?>%</span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<?php if (($audience ?? '') === 'manager' && (int) ($managedTeamCount ?? 0) === 0): ?>
    <p class="wk-note">You do not manage any team yet. This dashboard shows only your own time.</p>
<?php endif; ?>

<?php $teamCards = $week['teams'] ?? []; ?>
<?php if ($teamCards !== [] && $who !== 'me'): ?>
<section class="wk-teams">
    <h3 class="wk-section-title">Teams</h3>
    <div class="wk-team-grid">
        <?php foreach ($teamCards as $card): ?>
            <?php $top = $card['top_project'] ?? null; ?>
            <article class="wk-card wk-team-card">
                <div class="wk-team-card-head">
                    <h4><?= e((string) $card['name']) ?></h4>
                    <?php if ((int) ($card['working_count'] ?? 0) > 0): ?>
                        <span class="wk-working"><?= (int) $card['working_count'] ?> working now</span>
                    <?php endif; ?>
                </div>
                <div class="wk-team-card-stats">
                    <div>
                        <span class="wk-summary-label">Total time</span>
                        <strong><?= e($dur((int) $card['total'])) ?></strong>
                    </div>
                    <div>
                        <span class="wk-summary-label">Top project</span>
                        <strong class="text-truncate"><?= e($top['name'] ?? '—') ?></strong>
                    </div>
                </div>
                <?php if (($card['projects'] ?? []) !== []): ?>
                    <ul class="wk-rank wk-rank-compact">
                        <?php foreach ($card['projects'] as $p): ?>
                            <li>
                                <span class="wk-rank-name"><?= e($p['name']) ?></span>
                                <span class="wk-rank-time"><?= e($dur((int) $p['seconds'])) ?></span>
                                <span class="wk-rank-bar"><span style="width: <?= e((string) min(100, $p['percent'])) ?>%; background: <?= e($p['color']) ?>"></span></span>
                                <span class="wk-rank-pct"><?= e(number_format((float) $p['percent'], 2, ',', '')) ?>%</span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <div class="wk-empty">No time tracked in this period.</div>
                <?php endif; ?>
                <ul class="wk-who">
                    <?php foreach ($card['people'] as $person): ?>
                        <li>
                            <span class="wk-avatar wk-avatar-sm" style="background: <?= e(WeekDashboardHelper::PALETTE[(int) $person['user_id'] % 10] ?? '#8d6e63') ?>"><?= e($person['initials']) ?></span>
                            <span class="wk-who-name"><?= e($person['name']) ?><?php if (!empty($person['working'])): ?> <i class="wk-live" title="Working now"></i><?php endif; ?></span>
                            <span class="wk-who-time"><?= e($dur((int) $person['seconds'])) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </article>
        <?php endforeach; ?>
    </div>
</section>
<?php endif; ?>

<section class="wk-card wk-team">
    <div class="wk-team-head">
        <span><?= ($audience ?? '') === 'member' || $who === 'me' ? 'Your activity' : 'Team activities' ?></span>
    </div>
    <div class="table-responsive">
        <table class="wk-table">
            <thead>
                <tr>
                    <th>Team member</th>
                    <th>Latest activity</th>
                    <th colspan="2">Total tracked (<?= e($periodTitle) ?>)</th>
                </tr>
            </thead>
            <tbody data-team-activities>
            <?php if ($week['people'] === []): ?>
                <tr><td colspan="4" class="wk-empty">No team members to display.</td></tr>
            <?php endif; ?>
            <?php foreach ($week['people'] as $person): ?>
                <?php $act = $person['activity']; ?>
                <tr>
                    <td class="wk-member">
                        <span class="wk-avatar" style="background: <?= e($person['color']) ?>"><?= e($person['initials']) ?></span>
                        <span class="wk-member-name"><?= e($person['name']) ?></span>
                    </td>
                    <td class="wk-activity">
                        <?php if ($act === null): ?>
                            <span class="text-secondary">(no activity)</span>
                        <?php else: ?>
                            <div class="wk-activity-grid">
                                <div class="wk-activity-text">
                                    <div class="wk-activity-desc"><?= $act['description'] !== '' ? e($act['description']) : '<span class="text-secondary">(no description)</span>' ?></div>
                                    <div class="wk-activity-proj"><i class="wk-dot"></i> <?= e($act['project']) ?><?= $act['task'] !== '' ? ': ' . e($act['task']) : '' ?></div>
                                </div>
                                <span class="wk-activity-dur">
                                    <span<?= !empty($act['running']) ? ' data-live-seconds="' . (int) $act['seconds'] . '"' : '' ?>><?= e($dur((int) $act['seconds'])) ?></span>
                                    <?php if (!empty($act['running'])): ?><i class="wk-live" title="Timer running"></i><?php elseif (!empty($act['paused'])): ?><i class="fa-solid fa-pause text-warning ms-1" title="Timer paused"></i><?php endif; ?>
                                </span>
                                <span class="wk-activity-ago <?= !empty($act['running']) ? 'is-live' : '' ?>"<?= !empty($act['paused']) ? ' style="color:#e6a117"' : '' ?>><?= e($act['ago']) ?></span>
                            </div>
                        <?php endif; ?>
                    </td>
                    <td class="wk-total"><?= e($dur((int) $person['total'])) ?></td>
                    <td class="wk-minibar-cell">
                        <div class="wk-minibar">
                            <?php foreach ($person['segments'] as $seg): ?>
                                <span style="width: <?= $maxPerson > 0 ? e((string) round($seg['seconds'] / $maxPerson * 100, 2)) : 0 ?>%; background: <?= e($seg['color']) ?>"></span>
                            <?php endforeach; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<?php if (!empty($canViewNotifications)): ?>
<section id="notifications" class="wk-card wk-notes"<?= $notifications === [] ? ' hidden' : '' ?>>
    <div class="wk-team-head d-flex justify-content-between align-items-center">
        <span>Notifications<?= (int) $unread > 0 ? ' (' . (int) $unread . ' new)' : '' ?></span>
        <?php if ((int) $unread > 0): ?>
            <form method="post" action="<?= e(url('/notifications/read')) ?>" class="m-0">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-outline-secondary">Mark all as read</button>
            </form>
        <?php endif; ?>
    </div>
    <ul class="wk-notes-list">
        <?php foreach ($notifications as $note): ?>
            <li class="<?= $note['is_read'] ? '' : 'is-unread' ?>">
                <?php if (!empty($note['link']) && str_starts_with((string) $note['link'], '/') && !str_starts_with((string) $note['link'], '//')): ?>
                    <a href="<?= e(url((string) $note['link'])) ?>"><?= e($note['title']) ?></a>
                <?php else: ?>
                    <?= e($note['title']) ?>
                <?php endif; ?>
                <time><?= e(FormatHelper::datetime((string) $note['created_at'], 'M j, H:i')) ?></time>
            </li>
        <?php endforeach; ?>
    </ul>
</section>
<?php endif; ?>

<?php if (!empty($showMemberExtras)): ?>
    <?php include APP_PATH . '/Views/dashboard/member_extras.php'; ?>
<?php endif; ?>