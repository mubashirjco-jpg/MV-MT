<?php declare(strict_types=1); ?>
<div class="page-head d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
  <div>
    <h2 class="page-heading mb-1">Desktop Agent</h2>
    <p class="text-muted mb-0">Connect this Windows computer so TimeTrack can detect whether the computer is being used while a timer is running.</p>
  </div>
</div>

<div class="row g-4">
  <div class="col-lg-7">
    <section class="panel">
      <div class="panel-head"><div><h3 class="panel-title">Computer activity detection</h3><p class="small text-secondary mb-0">Only activity timestamps are sent. TimeTrack does not record keystrokes, screenshots, window contents or what you type.</p></div></div>
      <div class="p-4">
        <div class="d-flex flex-wrap gap-2 mb-3">
          <span class="badge text-bg-<?= $idleEnabled ? 'success' : 'secondary' ?>"><?= $idleEnabled ? 'Policy ON' : 'Policy OFF' ?></span>
          <?php if ($idleEnabled): ?><span class="badge text-bg-light border text-dark">Idle after <?= (int)$threshold ?> minutes</span><span class="badge text-bg-light border text-dark">No response → pause after <?= (int)$warningSeconds ?> seconds</span><?php endif; ?>
        </div>
        <p class="mb-3">Install the Windows agent on the computer you use for TimeTrack. AutoCAD, Excel, Photoshop, Chrome, YouTube and other applications all count simply as computer activity.</p>
        <?php if ($isAdmin): ?>
        <ol class="mb-4">
          <li>Install the TimeTrack Windows Agent on the employee's computer.</li>
          <li>Choose the employee below and click <strong>Generate pairing code</strong>.</li>
          <li>Enter the eight-digit code in the Windows agent on that computer.</li>
          <li>Leave the agent running in the Windows background.</li>
        </ol>
        <?php if (!$keyConfigured): ?>
          <div class="alert alert-danger"><strong>Pairing is disabled.</strong> <?= e(DesktopAgent::keyMessage()) ?></div>
        <?php endif; ?>
        <?php if (!empty($pairing) && !empty($pairing['code'])): ?>
          <div class="alert alert-primary mt-3"><div class="small text-uppercase fw-semibold mb-1">One-time pairing code<?= !empty($pairing['user_name']) ? ' for '.e((string)$pairing['user_name']) : '' ?></div><div style="font-size:2rem;letter-spacing:.25em;font-weight:700"><?=e((string)$pairing['code'])?></div><div class="small mt-1">Expires <?=e(FormatHelper::datetime((string)$pairing['expires_at'], 'M j, Y H:i'))?> UTC. Enter this code in the Windows Agent now.</div></div>
        <?php endif; ?>
        <form method="post" action="<?= e(url('/agent/pairing-code')) ?>" data-single-submit>
          <?= csrf_field() ?>
          <label class="form-label" for="agent-user">Member</label>
          <select class="form-select mb-3" id="agent-user" name="user_id" required>
            <option value="">Select a person…</option>
            <?php foreach ($users as $u): ?>
              <option value="<?= (int)$u['id'] ?>"><?= e((string)$u['name']) ?> (<?= e((string)$u['email']) ?>)</option>
            <?php endforeach; ?>
          </select>
          <button class="btn btn-primary"<?= $keyConfigured ? '' : ' disabled' ?>><i class="fa-solid fa-link me-1"></i>Generate pairing code</button>
        </form>
        <?php else: ?>
        <div class="alert alert-info mb-0">To connect your computer, ask your administrator for a pairing code. Once paired, the agent starts with Windows and needs nothing else from you.</div>
        <?php endif; ?>
      </div>
    </section>
  </div>
  <div class="col-lg-5">
    <section class="panel h-100">
      <div class="panel-head"><div><h3 class="panel-title">Connected computers</h3><p class="small text-secondary mb-0"><?= $isAdmin ? 'Every connected computer in the workspace.' : 'Computers paired to your account.' ?></p></div></div>
      <div class="p-0">
        <?php if ($devices === []): ?>
          <div class="p-4 text-secondary">No Windows computer is paired yet.</div>
        <?php else: foreach ($devices as $device): ?>
          <?php $seen = strtotime((string)$device['last_seen_at'].' UTC') ?: 0; $online = $seen >= time()-120; ?>
          <div class="d-flex align-items-center justify-content-between gap-3 p-3 border-bottom">
            <div><strong><?= e((string)$device['device_name']) ?></strong><?php if ($isAdmin && !empty($device['user_name'])): ?> <span class="small text-secondary">— <?= e((string)$device['user_name']) ?></span><?php endif; ?><div class="small text-secondary"><?= $online ? 'Online' : 'Last seen '.e(FormatHelper::datetime((string)$device['last_seen_at'], 'M j, Y H:i')) ?> · Agent <?= e((string)$device['agent_version']) ?></div></div>
            <?php if ($isAdmin): ?><form method="post" action="<?= e(url('/agent/'.$device['id'].'/revoke')) ?>" data-single-submit data-confirm="Disconnect this computer?"><?= csrf_field() ?><button class="btn btn-sm btn-outline-danger">Disconnect</button></form><?php endif; ?>
          </div>
        <?php endforeach; endif; ?>
      </div>
    </section>
  </div>
</div>
