<?php
/**
 * Teams used for the approval hierarchy (tables `teams` and `team_members`).
 *
 *   Project  ── Project Manager (projects.manager_id)
 *     └── Department ── Department Manager (departments.manager_id)
 *           └── Team ── Team Manager (teams.manager_id) ── Members
 *
 * Not to be confused with the read-only Team model, which powers the /team people page.
 * The team manager is never stored in team_members, so nobody is listed twice.
 */

declare(strict_types=1);

final class TeamGroup
{
    public const STATUSES = ['active', 'inactive'];

    public static function installed(): bool
    {
        return SchemaHelper::tableExists('teams') && SchemaHelper::tableExists('team_members');
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function all(int $projectId = 0, string $search = ''): array
    {
        $where  = ['1 = 1'];
        $params = [];

        if ($projectId > 0) {
            $where[]              = 't.project_id = :project_id';
            $params['project_id'] = $projectId;
        }

        $search = trim($search);
        if ($search !== '') {
            $where[]      = '(t.name LIKE :q OR p.name LIKE :q2)';
            $params['q']  = '%' . $search . '%';
            $params['q2'] = '%' . $search . '%';
        }

        $deptSelect = SchemaHelper::columnExists('teams', 'department_id')
            ? 't.department_id, d.name AS department_name, d.manager_id AS department_manager_id, dm.name AS department_manager_name,'
            : 'NULL AS department_id, NULL AS department_name, NULL AS department_manager_id, NULL AS department_manager_name,';
        $deptJoin = SchemaHelper::columnExists('teams', 'department_id')
            ? 'LEFT JOIN departments d ON d.id = t.department_id LEFT JOIN users dm ON dm.id = d.manager_id'
            : '';

        return Database::fetchAll(
            "SELECT t.id, t.project_id, t.name, t.manager_id, t.status, t.created_at,
                    {$deptSelect}
                    p.name AS project_name, p.project_code, p.manager_id AS project_manager_id,
                    pm.name AS project_manager_name,
                    tm.name AS manager_name,
                    (SELECT COUNT(*) FROM team_members x WHERE x.team_id = t.id) AS member_count
             FROM teams t
             INNER JOIN projects p ON p.id = t.project_id
             LEFT JOIN users pm ON pm.id = p.manager_id
             LEFT JOIN users tm ON tm.id = t.manager_id
             {$deptJoin}
             WHERE " . implode(' AND ', $where) . '
             ORDER BY p.name ASC, t.name ASC',
            $params
        );
    }

    /** @return array<string, mixed>|null */
    public function find(int $id): ?array
    {
        if ($id < 1) {
            return null;
        }

        $deptCol = SchemaHelper::columnExists('teams', 'department_id') ? ', t.department_id' : '';

        return Database::fetchOne(
            "SELECT t.id, t.project_id, t.name, t.manager_id, t.status{$deptCol}
             FROM teams t WHERE t.id = :id LIMIT 1",
            ['id' => $id]
        );
    }

    /**
     * Member rows for a team, including names (team manager excluded by design).
     *
     * @param list<int> $teamIds
     * @return array<int, list<array{id: int, name: string}>>
     */
    public function membersByTeam(array $teamIds): array
    {
        $teamIds = array_values(array_unique(array_filter(array_map('intval', $teamIds), static fn (int $id): bool => $id > 0)));
        if ($teamIds === []) {
            return [];
        }

        $in   = implode(',', $teamIds);
        $rows = Database::fetchAll(
            "SELECT tm.team_id, u.id, u.name
             FROM team_members tm
             INNER JOIN users u ON u.id = tm.user_id
             WHERE tm.team_id IN ({$in})
             ORDER BY u.name ASC"
        );

        $out = [];
        foreach ($rows as $row) {
            $out[(int) $row['team_id']][] = ['id' => (int) $row['id'], 'name' => (string) $row['name']];
        }

        return $out;
    }

    /** @return list<int> */
    public function memberIds(int $teamId): array
    {
        $rows = Database::fetchAll('SELECT user_id FROM team_members WHERE team_id = :id', ['id' => $teamId]);

        return array_map(static fn (array $row): int => (int) $row['user_id'], $rows);
    }

    /** True when another team of the same department (or project) already has this name. */
    public function nameTaken(int $projectId, string $name, int $exceptId = 0, int $departmentId = 0): bool
    {
        if ($departmentId > 0 && SchemaHelper::columnExists('teams', 'department_id')) {
            return (int) Database::fetchValue(
                'SELECT COUNT(*) FROM teams WHERE department_id = :d AND name = :n AND id <> :id',
                ['d' => $departmentId, 'n' => $name, 'id' => $exceptId]
            ) > 0;
        }

        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM teams WHERE project_id = :p AND name = :n AND id <> :id',
            ['p' => $projectId, 'n' => $name, 'id' => $exceptId]
        ) > 0;
    }

    /**
     * @param array{project_id: int, name: string, manager_id: ?int, status: string, department_id?: ?int} $data
     * @param list<int> $memberIds
     */
    public function create(array $data, array $memberIds, int $createdBy): int
    {
        return (int) Database::transaction(function () use ($data, $memberIds, $createdBy): int {
            $hasDept = SchemaHelper::columnExists('teams', 'department_id');
            $sql     = $hasDept
                ? 'INSERT INTO teams (project_id, department_id, name, manager_id, status, created_by, created_at, updated_at)
                   VALUES (:project_id, :department_id, :name, :manager_id, :status, :created_by, UTC_TIMESTAMP(), UTC_TIMESTAMP())'
                : 'INSERT INTO teams (project_id, name, manager_id, status, created_by, created_at, updated_at)
                   VALUES (:project_id, :name, :manager_id, :status, :created_by, UTC_TIMESTAMP(), UTC_TIMESTAMP())';
            $params = [
                'project_id' => $data['project_id'],
                'name'       => $data['name'],
                'manager_id' => $data['manager_id'],
                'status'     => $data['status'],
                'created_by' => $createdBy > 0 ? $createdBy : null,
            ];
            if ($hasDept) {
                $params['department_id'] = $data['department_id'] ?? null;
            }
            Database::execute($sql, $params);
            $id = Database::lastInsertId();
            $this->syncMembers($id, $memberIds);
            $this->syncProjectMembers(
                (int) $data['project_id'],
                $data['manager_id'] !== null ? (int) $data['manager_id'] : null,
                $memberIds
            );

            return $id;
        });
    }

    /**
     * @param array{project_id: int, name: string, manager_id: ?int, status: string, department_id?: ?int} $data
     * @param list<int> $memberIds
     */
    public function update(int $id, array $data, array $memberIds): void
    {
        Database::transaction(function () use ($id, $data, $memberIds): void {
            $hasDept = SchemaHelper::columnExists('teams', 'department_id');
            $sql     = $hasDept
                ? 'UPDATE teams
                   SET project_id = :project_id, department_id = :department_id, name = :name, manager_id = :manager_id,
                       status = :status, updated_at = UTC_TIMESTAMP()
                   WHERE id = :id'
                : 'UPDATE teams
                   SET project_id = :project_id, name = :name, manager_id = :manager_id,
                       status = :status, updated_at = UTC_TIMESTAMP()
                   WHERE id = :id';
            $params = [
                'project_id' => $data['project_id'],
                'name'       => $data['name'],
                'manager_id' => $data['manager_id'],
                'status'     => $data['status'],
                'id'         => $id,
            ];
            if ($hasDept) {
                $params['department_id'] = $data['department_id'] ?? null;
            }
            Database::execute($sql, $params);
            $this->syncMembers($id, $memberIds);
            $this->syncProjectMembers(
                (int) $data['project_id'],
                $data['manager_id'] !== null ? (int) $data['manager_id'] : null,
                $memberIds
            );
        });
    }

    public function delete(int $id): void
    {
        Database::execute('DELETE FROM teams WHERE id = :id', ['id' => $id]);
    }

    public function taskCount(int $teamId): int
    {
        if ($teamId < 1 || !SchemaHelper::columnExists('tasks', 'team_id')) {
            return 0;
        }

        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM tasks WHERE team_id = :id',
            ['id' => $teamId]
        );
    }

    public function taskCountForDepartment(int $departmentId): int
    {
        if ($departmentId < 1 || !SchemaHelper::columnExists('tasks', 'team_id') || !SchemaHelper::columnExists('teams', 'department_id')) {
            return 0;
        }

        return (int) Database::fetchValue(
            'SELECT COUNT(*) FROM tasks ta INNER JOIN teams t ON t.id = ta.team_id WHERE t.department_id = :id',
            ['id' => $departmentId]
        );
    }

    /** @param list<int> $memberIds */
    private function syncMembers(int $teamId, array $memberIds): void
    {
        Database::execute('DELETE FROM team_members WHERE team_id = :id', ['id' => $teamId]);

        foreach (array_values(array_unique($memberIds)) as $userId) {
            Database::execute(
                'INSERT INTO team_members (team_id, user_id, created_at) VALUES (:t, :u, UTC_TIMESTAMP())',
                ['t' => $teamId, 'u' => (int) $userId]
            );
        }
    }

    /**
     * Upsert team people onto the project as members. Never writes project_role=manager
     * except for projects.manager_id. Never silently demotes a viewer.
     *
     * @param list<int> $memberIds
     * @return list<string>
     */
    public function syncProjectMembers(int $projectId, ?int $managerId, array $memberIds): array
    {
        if ($projectId < 1) {
            return [];
        }

        $ids = [];
        foreach ([$managerId, ...$memberIds] as $uid) {
            $uid = (int) $uid;
            if ($uid > 0) {
                $ids[] = $uid;
            }
        }
        $ids = array_values(array_unique($ids));
        if ($ids === []) {
            return [];
        }

        $pmId = (int) Database::fetchValue(
            'SELECT manager_id FROM projects WHERE id = :id LIMIT 1',
            ['id' => $projectId]
        );
        $warnings = [];
        $members  = new ProjectMember();

        foreach ($ids as $userId) {
            $existing = Database::fetchOne(
                'SELECT id, project_role FROM project_members WHERE project_id = :p AND user_id = :u LIMIT 1',
                ['p' => $projectId, 'u' => $userId]
            );
            if ($existing !== null && strtolower((string) $existing['project_role']) === ProjectMember::ROLE_VIEWER) {
                $name = (string) Database::fetchValue('SELECT name FROM users WHERE id = :id LIMIT 1', ['id' => $userId]);
                $warnings[] = ($name !== '' ? $name : ('User #' . $userId)) . ' is a viewer on this project and was not added as a member.';
                continue;
            }
            $role = $pmId > 0 && $userId === $pmId ? ProjectMember::ROLE_MANAGER : ProjectMember::ROLE_MEMBER;
            $members->assign($projectId, $userId, $role);
        }

        return $warnings;
    }
}
