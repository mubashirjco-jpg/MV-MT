<?php
/**
 * Clockify-style weekly dashboard for every role.
 * Members see only their own time. Managers see their teams. Admins see everyone
 * plus a per-team overview (Design Services, MEP, …).
 */

declare(strict_types=1);

final class DashboardController extends Controller
{
    public function __construct()
    {
        parent::__construct(true);
    }

    /** GET /dashboard  (optional ?week=YYYY-MM-DD&who=team|me) */
    public function index(Request $request, array $params): void
    {
        PermissionHelper::require('dashboard.view');

        $userId = (int) AuthHelper::id();
        $me = AuthHelper::user() ?? ['name' => '', 'role' => ''];
        $hour = (int) FormatHelper::datetime(gmdate('Y-m-d H:i:s'), 'G');
        $greeting = $hour < 12
            ? 'Good morning'
            : ($hour < 18 ? 'Good afternoon' : 'Good evening');

        $firstName = trim((string) strtok((string) ($me['name'] ?? ''), ' '));

        $unread = 0;
        $notifications = [];
        $canViewNotifications = PermissionHelper::has('notifications.view');

        if ($canViewNotifications) {
            try {
                $unread = (int) Database::fetchValue(
                    'SELECT COUNT(*) FROM notifications WHERE user_id = :id AND is_read = 0',
                    ['id' => $userId]
                );

                $notifications = Database::fetchAll(
                    'SELECT id, type, title, message, link, is_read, created_at
                     FROM notifications
                     WHERE user_id = :id
                     ORDER BY created_at DESC, id DESC
                     LIMIT 6',
                    ['id' => $userId]
                );
            } catch (Throwable $e) {
                LoggerHelper::exception($e);
                $unread = 0;
                $notifications = [];
            }
        }

        $shared = [
            'pageTitle' => 'Dashboard',
            'greeting' => $greeting,
            'firstName' => $firstName,
            'unread' => $unread,
            'notifications' => $notifications,
            'canViewNotifications' => $canViewNotifications,
            'canTrack' => PermissionHelper::has('time.track')
                && class_exists('Timer')
                && Timer::installed()
                && FeatureFlagsHelper::trackerVisible(),
            'currency' => AnalyticsHelper::currency(),
        ];

        $isAdmin = AuthHelper::hasRole(AuthHelper::ROLE_ADMIN);
        $isManager = AuthHelper::hasRole(AuthHelper::ROLE_MANAGER);

        $this->dashboard($request, $shared, $userId, $isAdmin, $isManager);
    }

    /**
     * @param array<string, mixed> $shared
     */
    private function dashboard(Request $request, array $shared, int $userId, bool $isAdmin, bool $isManager): void
    {
        $viewAll = $isAdmin || PermissionHelper::has('projects.view_all');
        $weekParam = (string) $request->input('week', '');
        $range = (string) $request->input('range', 'week');
        $anchorDate = (string) $request->input('date', '');
        $who = (string) $request->input('who', 'team');

        $restrictUserIds = null;
        $onlyMe = false;
        $showWhoSwitch = false;
        $includeTeamOverview = false;
        $managedTeamsOnly = false;
        $managedTeamCount = 0;
        $audience = 'member';

        if ($isAdmin) {
            $audience = 'admin';
            $onlyMe = $who === 'me';
            $showWhoSwitch = true;
            $includeTeamOverview = !$onlyMe;
        } elseif ($isManager) {
            $audience = 'manager';
            $managedTeamCount = WeekDashboardHelper::managedTeamCount($userId);
            $onlyMe = $who === 'me' || $managedTeamCount === 0;
            $showWhoSwitch = $managedTeamCount > 0;
            $includeTeamOverview = !$onlyMe;
            $managedTeamsOnly = true;
            if (!$onlyMe) {
                $restrictUserIds = WeekDashboardHelper::managedTeamUserIds($userId);
                $viewAll = true;
            }
        } else {
            $onlyMe = true;
        }

        try {
            $week = WeekDashboardHelper::build(
                $userId,
                $viewAll,
                $weekParam !== '' ? $weekParam : null,
                $onlyMe,
                $range,
                $anchorDate !== '' ? $anchorDate : null,
                $restrictUserIds,
                $includeTeamOverview,
                $managedTeamsOnly
            );
        } catch (Throwable $e) {
            LoggerHelper::exception($e);
            $week = WeekDashboardHelper::build($userId, $viewAll, null, true);
            $week['ready'] = false;
        }

        $week['managed_team_count'] = $isManager ? $managedTeamCount : (int) ($week['managed_team_count'] ?? 0);

        $pending = 0;
        $canApprove = PermissionHelper::has('time.approve')
            || ($isAdmin || $isManager);
        if (FeatureFlagsHelper::timeApprovalEnabled() && Timesheet::installed()
            && ($isAdmin || $isManager || PermissionHelper::has('time.approve'))) {
            try {
                $pending = (int) ((new Timesheet())->queueCounts((int) $userId, $isAdmin)['Submitted'] ?? 0);
            } catch (Throwable $e) {
                LoggerHelper::exception($e);
                $pending = 0;
            }
        }

        $memberExtras = [];
        if ($audience === 'member') {
            $memberExtras = $this->memberExtras($userId);
        }

        $this->render(
            'dashboard/admin_manager',
            array_merge($shared, $memberExtras, [
                'week' => $week,
                'canApprove' => $isAdmin || $isManager || PermissionHelper::has('time.approve'),
                'pendingApprovals' => $pending,
                'chartAssets' => true,
                'showWhoSwitch' => $showWhoSwitch,
                'audience' => $audience,
                'managedTeamCount' => $managedTeamCount,
            ])
        );
    }

    /**
     * Schedule, tasks and recent entries shown under a member's own dashboard.
     *
     * @return array<string, mixed>
     */
    private function memberExtras(int $userId): array
    {
        $today = AnalyticsHelper::employeeToday($userId);
        $projects = [];
        if (class_exists('TimeEntry') && TimeEntry::installed()) {
            $projects = (new TimeEntry())->trackableProjects(
                $userId,
                PermissionHelper::has('projects.view_all')
            );
        }

        return [
            'today' => $today,
            'projects' => $projects,
            'canManual' => PermissionHelper::has('time.edit_own') && FeatureFlagsHelper::allowManual(),
            'canDelete' => PermissionHelper::has('time.edit_own'),
            'canEdit' => PermissionHelper::has('time.edit_own'),
            'userId' => $userId,
            'capacityHours' => WorkspacePolicy::dailyCapacityHours(),
            'showMemberExtras' => true,
        ];
    }

    /** POST /notifications/read : mark all of the user's notifications as read. */
    public function markNotificationsRead(Request $request, array $params): void
    {
        PermissionHelper::require('notifications.view');

        Database::execute(
            'UPDATE notifications
             SET is_read = 1, read_at = UTC_TIMESTAMP()
             WHERE user_id = :id AND is_read = 0',
            ['id' => (int) AuthHelper::id()]
        );

        if ($request->wantsJson()) {
            $this->json(['ok' => true]);
        }

        $this->redirect('/dashboard');
    }
}