<?php
/**
 * Reusable HTML/text email templates with {{variable}} substitution.
 *
 * Variables are HTML-escaped in the HTML body and left plain in the text body.
 * Unknown variables become empty strings. Invitation tokens never enter a template
 * except as a fully formed invitation_url.
 */

declare(strict_types=1);

final class MailTemplate
{
    public const INVITATION = 'invitation';
    public const INVITATION_RESENT = 'invitation_resent';
    public const WELCOME = 'welcome';
    public const PASSWORD_RESET = 'password_reset';
    public const ASSIGNMENT = 'assignment';
    public const TIMESHEET_SUBMITTED = 'timesheet_submitted';

    /**
     * @param array<string, mixed> $vars
     * @return array{subject: string, html: string, text: string}
     */
    public static function render(string $name, array $vars): array
    {
        $vars = self::normalize($vars);
        $spec = self::spec($name, $vars);
        $html = self::replace($spec['html'], $vars, true);
        $isInvite = $name === self::INVITATION || $name === self::INVITATION_RESENT;

        return [
            'subject' => self::replace($spec['subject'], $vars, false),
            'html' => $isInvite ? $html : self::layout($html, $vars),
            'text' => self::replace($spec['text'], $vars, false),
        ];
    }

    /**
     * @param array<string, mixed> $vars
     * @return array<string, string>
     */
    private static function normalize(array $vars): array
    {
        $out = [];
        foreach ($vars as $key => $value) {
            if (is_array($value)) {
                $value = implode("\n", array_map(static fn ($item): string => (string) $item, $value));
            }
            $out[(string) $key] = (string) $value;
        }

        $out['company_name'] = $out['company_name'] ?? SettingsService::appName();
        $out['support_email'] = $out['support_email'] ?? SmtpSettings::replyTo();
        $out['year'] = $out['year'] ?? gmdate('Y');
        // Emails follow the brand colour chosen in System settings (teal when none is set).
        $out['brand_color'] = BrandingHelper::colorOrDefault();
        $out['brand_on'] = BrandingHelper::textOn($out['brand_color']);

        return $out;
    }

    /**
     * @param array<string, string> $vars
     * @return array{subject: string, html: string, text: string}
     */
    private static function spec(string $name, array $vars): array
    {
        return match ($name) {
            self::INVITATION, self::INVITATION_RESENT => self::invitation($name === self::INVITATION_RESENT),
            self::WELCOME => self::welcome(),
            self::PASSWORD_RESET => self::passwordReset(),
            self::ASSIGNMENT => self::assignment(),
            self::TIMESHEET_SUBMITTED => self::timesheetSubmitted(),
            default => throw new InvalidArgumentException('Unknown email template.'),
        };
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function invitation(bool $resent): array
    {
        unset($resent);

        $html = <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:Roboto,'Segoe UI',Arial,sans-serif;color:#000000;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;">
    <tr><td align="center" style="padding:32px 16px;">
      <table role="presentation" width="640" cellpadding="0" cellspacing="0" style="width:100%;max-width:640px;">
        <tr><td align="left" style="padding:0 0 24px 20px;">{{logo_html}}</td></tr>
        <tr><td style="background:#ffffff;padding:40px 20px 36px;">
          <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
            <tr><td style="padding:0 0 28px;font-size:24px;line-height:1.3;font-weight:400;color:#000000;border-bottom:1px solid #e6e9ec;">Join {{company_name}}</td></tr>
            <tr><td style="padding:24px 0 28px;font-size:14px;line-height:1.6;color:#666666;"><strong style="color:#555555;">{{invited_by}}</strong> invited you to track time on <strong style="color:#555555;">{{company_name}}</strong> workspace.</td></tr>
            <tr><td align="left" style="padding:0 0 28px;">
              <a href="{{invitation_url}}" style="display:inline-block;width:200px;box-sizing:border-box;text-align:center;background:{{brand_color}};color:{{brand_on}};text-decoration:none;padding:13px 0;font-size:14px;font-weight:400;letter-spacing:.02em;">ACCEPT INVITE</a>
            </td></tr>
            <tr><td style="font-size:12px;color:#aaaaaa;">Invitation expires in {{expiry_phrase}}.</td></tr>
          </table>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;

        $text = "Join {{company_name}}\n\n"
            . "{{invited_by}} invited you to track time on {{company_name}} workspace.\n\n"
            . "ACCEPT INVITE: {{invitation_url}}\n\n"
            . "Invitation expires in {{expiry_phrase}}.\n";

        return ['subject' => 'Join {{company_name}}', 'html' => $html, 'text' => $text];
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function welcome(): array
    {
        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">Your {{company_name}} account is now active. You can sign in with {{email}}.</p>
<p style="margin:0 0 24px;text-align:center;">
  <a href="{{login_url}}" style="display:inline-block;background:{{brand_color}};color:{{brand_on}};text-decoration:none;padding:12px 28px;border-radius:6px;font-weight:600;">Sign in</a>
</p>
HTML;
        $text = "Hello {{user_name}},\n\nYour {{company_name}} account is now active. Sign in at {{login_url}} with {{email}}.\n";

        return [
            'subject' => 'Welcome to {{company_name}}',
            'html' => $html,
            'text' => $text,
        ];
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function passwordReset(): array
    {
        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">A password reset was requested for your {{company_name}} account.</p>
<p style="margin:0 0 24px;text-align:center;">
  <a href="{{reset_url}}" style="display:inline-block;background:{{brand_color}};color:{{brand_on}};text-decoration:none;padding:12px 28px;border-radius:6px;font-weight:600;">Reset password</a>
</p>
<p style="margin:0;color:#5b6d6c;font-size:13px;">This link expires on {{expiry_date}}. If you did not request a reset, you can ignore this email.</p>
<p style="margin:16px 0 0;color:#5b6d6c;font-size:13px;">If the button does not work, copy this address into your browser:<br><a href="{{reset_url}}" style="color:{{brand_color}};word-break:break-all;">{{reset_url}}</a></p>
HTML;
        $text = "Hello {{user_name}},\n\nReset your {{company_name}} password: {{reset_url}}\nExpires: {{expiry_date}}\n";

        return [
            'subject' => '{{company_name}} password reset',
            'html' => $html,
            'text' => $text,
        ];
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function assignment(): array
    {
        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">{{invited_by}} updated your access on {{company_name}}.</p>
<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 20px;width:100%;">
  <tr><td style="padding:4px 0;color:#5b6d6c;width:120px;">Role</td><td style="padding:4px 0;"><strong>{{role}}</strong></td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;">Team</td><td style="padding:4px 0;">{{team}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;vertical-align:top;">Projects</td><td style="padding:4px 0;">{{projects_html}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;vertical-align:top;">Tasks</td><td style="padding:4px 0;">{{tasks_html}}</td></tr>
</table>
HTML;
        $text = "Hello {{user_name}},\n\n{{invited_by}} updated your access.\nRole: {{role}}\nTeam: {{team}}\nProjects:\n{{projects}}\nTasks:\n{{tasks}}\n";

        return [
            'subject' => '{{company_name}}: your access was updated',
            'html' => $html,
            'text' => $text,
        ];
    }

    /** @return array{subject: string, html: string, text: string} */
    private static function timesheetSubmitted(): array
    {
        $html = <<<HTML
<p style="margin:0 0 16px;">Hello {{user_name}},</p>
<p style="margin:0 0 16px;">{{submitter_name}} submitted a timesheet for approval.</p>
<table role="presentation" cellpadding="0" cellspacing="0" style="margin:0 0 20px;width:100%;">
  <tr><td style="padding:4px 0;color:#5b6d6c;width:140px;">Period</td><td style="padding:4px 0;"><strong>{{period}}</strong></td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;">Total time</td><td style="padding:4px 0;">{{total_time}}</td></tr>
  <tr><td style="padding:4px 0;color:#5b6d6c;">Your role</td><td style="padding:4px 0;">{{approver_role}}</td></tr>
</table>
<p style="margin:0 0 24px;">Review the timesheet and approve or request changes.</p>
<p style="margin:0 0 24px;text-align:center;">
  <a href="{{review_url}}" style="display:inline-block;background:{{brand_color}};color:{{brand_on}};text-decoration:none;padding:12px 28px;border-radius:6px;font-weight:600;">Review timesheet</a>
</p>
<p style="margin:0;color:#5b6d6c;font-size:13px;">If the button does not work, copy this address into your browser:<br><a href="{{review_url}}" style="color:{{brand_color}};word-break:break-all;">{{review_url}}</a></p>
HTML;
        $text = "Hello {{user_name}},\n\n{{submitter_name}} submitted a timesheet for approval.\n\n"
            . "Period: {{period}}\nTotal time: {{total_time}}\nYour role: {{approver_role}}\n\n"
            . "Review it here:\n{{review_url}}\n";

        return [
            'subject' => '{{company_name}}: timesheet submitted by {{submitter_name}}',
            'html' => $html,
            'text' => $text,
        ];
    }

    /**
     * @param array<string, string> $vars
     */
    private static function layout(string $inner, array $vars): string
    {
        $company = htmlspecialchars($vars['company_name'] ?? 'TimeTrack', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $headerBg = BrandingHelper::emailHeaderColor();
        $headerFg = BrandingHelper::textOn($headerBg);
        $support = htmlspecialchars($vars['support_email'] ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $year = htmlspecialchars($vars['year'] ?? gmdate('Y'), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
        $supportLine = $support !== ''
            ? '<p style="margin:16px 0 0;color:#5b6d6c;font-size:13px;">Questions? Contact ' . $support . '.</p>'
            : '';

        return <<<HTML
<!DOCTYPE html>
<html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f3f5f2;font-family:system-ui,-apple-system,'Segoe UI',Roboto,Arial,sans-serif;color:#17282a;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f5f2;padding:24px 12px;">
    <tr><td align="center">
      <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;background:#ffffff;border-radius:12px;overflow:hidden;border:1px solid #dde3df;">
        <tr><td style="background:{$headerBg};color:{$headerFg};padding:20px 28px;font-size:18px;font-weight:600;">{$company}</td></tr>
        <tr><td style="padding:28px;">{$inner}{$supportLine}</td></tr>
        <tr><td style="padding:16px 28px;background:#f8faf9;color:#5b6d6c;font-size:12px;">&copy; {$year} {$company}</td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
HTML;
    }

    /**
     * @param array<string, string> $vars
     */
    private static function replace(string $template, array $vars, bool $escapeHtml): string
    {
        return (string) preg_replace_callback('/\{\{\s*([a-zA-Z0-9_]+)\s*\}\}/', static function (array $m) use ($vars, $escapeHtml): string {
            $value = $vars[$m[1]] ?? '';
            if ($escapeHtml && !str_ends_with($m[1], '_html')) {
                return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
            }

            return $value;
        }, $template);
    }
}
