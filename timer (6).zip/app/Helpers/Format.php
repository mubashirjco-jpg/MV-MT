<?php
/**
 * Output formatting and the small set of global functions used inside templates.
 *
 * Storage is always UTC. Anything shown to a person goes through datetime()/date(),
 * which convert to that user's timezone. Durations are plain integer seconds.
 */

declare(strict_types=1);

final class FormatHelper
{
    /** @var array<string, mixed> old input for THIS request (flashed by the previous one) */
    private static array $old = [];

    /** @var array<string, string> validation errors for THIS request */
    private static array $errors = [];

    /** @var array<string, bool> cache of timezone identifiers already validated */
    private static array $validZones = [];

    /**
     * Move flashed form state out of the session so it lives for exactly one request.
     * Called once by the front controller right after the session starts.
     */
    public static function boot(): void
    {
        self::$old    = is_array($_SESSION['_old'] ?? null) ? $_SESSION['_old'] : [];
        self::$errors = is_array($_SESSION['_errors'] ?? null) ? $_SESSION['_errors'] : [];
        unset($_SESSION['_old'], $_SESSION['_errors']);
    }

    /**
     * @param array<string, mixed>  $old
     * @param array<string, string> $errors
     */
    public static function withState(array $old, array $errors): void
    {
        self::$old    = $old;
        self::$errors = $errors;
    }

    /** HTML-escape for element content AND quoted attribute values. This is the XSS defence for all output. */
    public static function e(mixed $value): string
    {
        if ($value === null || is_array($value) || (is_object($value) && !$value instanceof Stringable)) {
            return '';
        }

        return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }

    public static function old(string $key, string $default = ''): string
    {
        $value = self::$old[$key] ?? $default;

        return is_array($value) ? $default : (string) $value;
    }

    /** @return list<mixed> */
    public static function oldArray(string $key): array
    {
        $value = self::$old[$key] ?? [];

        return is_array($value) ? array_values($value) : [];
    }

    public static function error(string $field): ?string
    {
        return self::$errors[$field] ?? null;
    }

    /** @return array<string, string> */
    public static function errors(): array
    {
        return self::$errors;
    }

    /** Application URL for an internal path, honouring app.base_url or the auto-detected folder. */
    public static function url(string $path = '/'): string
    {
        $configured = (string) Config::get('app.base_url', '');
        $base = $configured !== '' ? rtrim($configured, '/') : Request::basePath();

        return $base . '/' . ltrim($path, '/');
    }

    /**
     * Fully-qualified URL (https://host/folder/path) for links that leave the browser session:
     * emails, exports, notifications.
     *
     * url() returns a path only ("/Dev/public/reset-password?..."). That is fine inside a page, but
     * an email client has no site to resolve it against, so the link breaks ("http:///Dev/...").
     *
     * Order of preference:
     *   1. APP_BASE_URL set to a full URL (e.g. https://app.example.com/Dev) - always wins, and is
     *      the safest option because it never depends on the incoming Host header.
     *   2. scheme + host of the current request + url($path).
     */
    public static function absoluteUrl(string $path = '/'): string
    {
        $configured = trim((string) Config::get('app.base_url', ''));
        if (preg_match('#^https?://#i', $configured) === 1) {
            return rtrim($configured, '/') . '/' . ltrim($path, '/');
        }

        try {
            $request = Request::current();
            $scheme  = $request->isHttps() ? 'https' : 'http';
            $host    = $request->host();
        } catch (Throwable) {
            // CLI / cron: there is no request. Fall back to whatever is configured.
            $scheme = 'https';
            $host   = (string) (Config::get('app.allowed_hosts', [])[0] ?? 'localhost');
        }

        return $scheme . '://' . $host . self::url($path);
    }

    /** URL to a file under public/assets with a modification-time query string for cache busting. */
    public static function asset(string $path): string
    {
        $path = ltrim($path, '/');
        $file = PUBLIC_PATH . '/assets/' . $path;
        $version = is_file($file) ? '?v=' . filemtime($file) : '';

        return self::url('/assets/' . $path) . $version;
    }

    /** 3725 => "1:02:05" */
    public static function duration(int $seconds): string
    {
        $seconds = max(0, $seconds);

        return sprintf('%02d:%02d:%02d', intdiv($seconds, 3600), intdiv($seconds % 3600, 60), $seconds % 60);
    }

    /** 3725 => "1h 02m", 540 => "9m" */
    public static function durationShort(int $seconds): string
    {
        $seconds = max(0, $seconds);
        $hours   = intdiv($seconds, 3600);
        $minutes = intdiv($seconds % 3600, 60);

        return $hours > 0 ? sprintf('%dh %02dm', $hours, $minutes) : sprintf('%dm', $minutes);
    }

    /** 5400 => "1.50" (decimal hours, for billing and reports) */
    public static function hours(int $seconds, int $decimals = 2): string
    {
        return number_format(max(0, $seconds) / 3600, $decimals, '.', '');
    }

    public static function money(float $amount, string $currency = 'USD'): string
    {
        return number_format($amount, 2) . ' ' . strtoupper($currency);
    }

    public static function truncate(string $text, int $length, string $suffix = '…'): string
    {
        return mb_strimwidth($text, 0, $length, $suffix, 'UTF-8');
    }

    /** Convert a UTC "Y-m-d H:i:s" database value to the viewer's timezone. Empty string for null/invalid. */
    public static function datetime(?string $utc, ?string $format = null): string
    {
        if ($utc === null || $utc === '') {
            return '';
        }

        try {
            $moment = new DateTimeImmutable($utc, new DateTimeZone('UTC'));
        } catch (Exception) {
            return '';
        }

        $pattern = $format ?? (SettingsService::dateFormat() . ' ' . SettingsService::timeFormat());

        return $moment->setTimezone(new DateTimeZone(self::displayTimezone()))->format($pattern);
    }

    public static function date(?string $utc, ?string $format = null): string
    {
        return self::datetime($utc, $format ?? SettingsService::dateFormat());
    }

    /**
     * Convert a viewer-local "Y-m-d H:i[:s]" string (e.g. from a manual time entry form)
     * to a UTC "Y-m-d H:i:s" string. Returns null when the input is not a valid date.
     */
    public static function toUtc(string $local, ?string $timezone = null): ?string
    {
        $zone = new DateTimeZone($timezone !== null && self::isValidZone($timezone) ? $timezone : self::displayTimezone());

        foreach (['Y-m-d H:i:s', 'Y-m-d H:i', 'Y-m-d\TH:i', 'Y-m-d\TH:i:s'] as $pattern) {
            $parsed = DateTimeImmutable::createFromFormat('!' . $pattern, $local, $zone);
            $errors = DateTimeImmutable::getLastErrors();

            if ($parsed !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0))) {
                return $parsed->setTimezone(new DateTimeZone('UTC'))->format('Y-m-d H:i:s');
            }
        }

        return null;
    }

    public static function isValidZone(string $timezone): bool
    {
        return self::$validZones[$timezone] ??= in_array($timezone, DateTimeZone::listIdentifiers(), true);
    }

    /** The logged-in user's timezone, else the application default, else UTC. */
    public static function displayTimezone(): string
    {
        foreach ([AuthHelper::user()['timezone'] ?? null, SettingsService::systemTimezone()] as $candidate) {
            if (is_string($candidate) && self::isValidZone($candidate)) {
                return $candidate;
            }
        }

        return 'UTC';
    }

    /** Timezone used to compare calendar dates for a specific user. */
    public static function timezoneForUser(int $userId): string
    {
        $current = AuthHelper::id();
        if ($current !== null && (int) $current === $userId) {
            return self::displayTimezone();
        }

        if ($userId > 0) {
            $zone = Database::fetchValue('SELECT timezone FROM users WHERE id = :id', ['id' => $userId]);
            if (is_string($zone) && self::isValidZone($zone)) {
                return $zone;
            }
        }

        $system = SettingsService::systemTimezone();
        return self::isValidZone($system) ? $system : 'UTC';
    }
}

/* ------------------------------------------------------------------
 * Global template helpers. Thin aliases only; logic lives in the classes.
 * ------------------------------------------------------------------ */

if (!function_exists('e')) {
    /** Escape for HTML output. Use on EVERY dynamic value in a template. */
    function e(mixed $value): string
    {
        return FormatHelper::e($value);
    }
}

if (!function_exists('url')) {
    function url(string $path = '/'): string
    {
        return FormatHelper::url($path);
    }
}

if (!function_exists('absolute_url')) {
    function absolute_url(string $path = '/'): string
    {
        return FormatHelper::absoluteUrl($path);
    }
}

if (!function_exists('asset')) {
    function asset(string $path): string
    {
        return FormatHelper::asset($path);
    }
}

if (!function_exists('csrf_field')) {
    function csrf_field(): string
    {
        return CsrfHelper::field();
    }
}

if (!function_exists('csrf_meta')) {
    function csrf_meta(): string
    {
        return CsrfHelper::meta();
    }
}

if (!function_exists('old')) {
    /** Previously submitted value of a form field (after a failed validation redirect). */
    function old(string $key, string $default = ''): string
    {
        return FormatHelper::old($key, $default);
    }
}

if (!function_exists('old_array')) {
    /** @return list<mixed> */
    function old_array(string $key): array
    {
        return FormatHelper::oldArray($key);
    }
}

if (!function_exists('field_error')) {
    function field_error(string $field): ?string
    {
        return FormatHelper::error($field);
    }
}

if (!function_exists('flash_pull')) {
    /**
     * Return and clear queued flash messages: ['success' => [...], 'danger' => [...], ...]
     *
     * @return array<string, list<string>>
     */
    function flash_pull(): array
    {
        $messages = is_array($_SESSION['_flash'] ?? null) ? $_SESSION['_flash'] : [];
        unset($_SESSION['_flash']);

        return $messages;
    }
}

if (!function_exists('auth_user')) {
    function auth_user(): ?array
    {
        return AuthHelper::user();
    }
}

if (!function_exists('can')) {
    /**
     * UI convenience for showing/hiding menu items ONLY. Never rely on it for security:
     * every action is enforced again server-side by the controller's middleware.
     */
    function can(string ...$roles): bool
    {
        return AuthHelper::hasRole(...$roles);
    }
}
