<?php
/**
 * Invitation workflow: create pending users, send SMTP mail, accept, resend, cancel.
 *
 * Tokens are hashed (SHA-256) before storage. SMTP failures leave the invitation
 * pending so the admin can retry. Role assignment never exceeds the inviter's
 * own privileges.
 */

declare(strict_types=1);

final class InvitationService
{
    public const HASH_OPTIONS = ['cost' => 12];

    public const ACCOUNT_STATUSES = ['active', 'inactive'];

    private UserInvitation $invitations;

    public function __construct()
    {
        $this->invitations = new UserInvitation();
    }

    /**
     * Roles the current user is allowed to grant.
     *
     * @return list<array<string, mixed>>
     */
    public function grantableRoles(): array
    {
        $rows = Database::fetchAll('SELECT id, name, display_name FROM roles ORDER BY id ASC');
        $canManageRoles = PermissionHelper::has('roles.manage');
        $actorRole = AuthHelper::role();

        $out = [];
        foreach ($rows as $row) {
            $name = (string) $row['name'];
            if (!in_array($name, AuthHelper::ROLES, true)) {
                continue;
            }
            if (!$this->canGrantRole($name, $canManageRoles, $actorRole)) {
                continue;
            }
            $out[] = $row;
        }

        return $out;
    }

    public function canGrantRole(string $role, ?bool $canManageRoles = null, ?string $actorRole = null): bool
    {
        $canManageRoles ??= PermissionHelper::has('roles.manage');
        $actorRole ??= AuthHelper::role();

        if (!in_array($role, AuthHelper::ROLES, true)) {
            return false;
        }
        if ($role === AuthHelper::ROLE_ADMIN) {
            return $canManageRoles && $actorRole === AuthHelper::ROLE_ADMIN;
        }
        if ($role === AuthHelper::ROLE_MANAGER) {
            return $canManageRoles;
        }

        return PermissionHelper::has('users.create');
    }

    /** @return list<array<string, mixed>> */
    public function projectOptions(): array
    {
        return Database::fetchAll(
            "SELECT id, name, project_code, status
             FROM projects
             WHERE status IN ('Planning','Active','On Hold')
             ORDER BY name ASC
             LIMIT 400"
        );
    }

    /**
     * @param list<int> $projectIds
     * @return list<array<string, mixed>>
     */
    public function taskOptions(array $projectIds = []): array
    {
        if (!Task::installed()) {
            return [];
        }

        $sql = "SELECT t.id, t.name, t.project_id, p.name AS project_name
                FROM tasks t
                INNER JOIN projects p ON p.id = t.project_id
                WHERE t.status NOT IN ('Completed','Done','Cancelled')";
        $params = [];
        if ($projectIds !== []) {
            $placeholders = [];
            foreach (array_values($projectIds) as $i => $id) {
                $key = 'p' . $i;
                $placeholders[] = ':' . $key;
                $params[$key] = $id;
            }
            $sql .= ' AND t.project_id IN (' . implode(', ', $placeholders) . ')';
        }
        $sql .= ' ORDER BY p.name ASC, t.name ASC LIMIT 800';

        return Database::fetchAll($sql, $params);
    }

    /** @return list<array<string, mixed>> */
    public function teamOptions(): array
    {
        if (!SchemaHelper::tableExists('teams')) {
            return [];
        }

        return Database::fetchAll('SELECT id, name FROM teams WHERE status = \'active\' OR status IS NULL ORDER BY name ASC LIMIT 200');
    }

    /**
     * Create a pending invitation and attempt to send the email.
     *
     * @param array<string, mixed> $data
     * @param list<int> $projectIds
     * @param list<int> $taskIds
     * @param list<int> $teamIds
     * @return array{ok: bool, existing?: array<string, mixed>, invitation_id?: int, error?: string}
     */
    public function invite(array $data, array $projectIds, array $taskIds, array $teamIds, bool $confirmExisting = false): array
    {
        $email = strtolower(trim((string) ($data['email'] ?? '')));
        $existing = $this->findUserByEmail($email);
        if ($existing !== null) {
            if (!$confirmExisting) {
                return ['ok' => false, 'existing' => $existing];
            }

            return $this->assignExisting($existing, $data, $projectIds, $taskIds, $teamIds);
        }

        $open = $this->invitations->openByEmail($email);
        if ($open !== null) {
            return ['ok' => false, 'error' => 'An open invitation already exists for this email. Resend or cancel it first.'];
        }

        $roleName = (string) ($data['role'] ?? AuthHelper::ROLE_EMPLOYEE);
        if (!$this->canGrantRole($roleName)) {
            return ['ok' => false, 'error' => 'You cannot assign that role.'];
        }

        $roleId = $this->roleId($roleName);
        $days = max(1, min(90, (int) ($data['expires_days'] ?? SmtpSettings::inviteExpiryDays())));
        $expiresAt = gmdate('Y-m-d H:i:s', time() + ($days * 86400));
        $token = UserInvitation::generateToken();
        $accountStatus = in_array((string) ($data['account_status'] ?? 'active'), self::ACCOUNT_STATUSES, true)
            ? (string) $data['account_status']
            : 'active';

        $projectIds = $this->sanitizeIds($projectIds, 'projects');
        $taskIds = $this->sanitizeTaskIds($taskIds, $projectIds);
        $teamIds = $this->sanitizeIds($teamIds, 'teams');

        $invitationId = Database::transaction(function () use ($data, $email, $roleId, $token, $expiresAt, $accountStatus, $projectIds, $taskIds, $teamIds): int {
            $id = $this->invitations->create([
                'email' => $email,
                'name' => (string) $data['name'],
                'job_title' => $data['job_title'] ?? null,
                'phone' => $data['phone'] ?? null,
                'account_status' => $accountStatus,
                'invited_by' => (int) AuthHelper::id(),
                'role_id' => $roleId,
                'user_id' => null,
                'token_hash' => UserInvitation::hashToken($token),
                'expires_at' => $expiresAt,
                'status' => UserInvitation::STATUS_PENDING,
                'send_count' => 0,
            ]);
            $this->invitations->syncAssignments($id, $projectIds, $taskIds, $teamIds);

            return $id;
        });

        LoggerHelper::logEvent('invitation.created', LoggerHelper::MODULE_INVITE, $invitationId, null, [
            'email_domain' => $this->emailDomain($email),
            'role' => $roleName,
            'projects' => count($projectIds),
            'tasks' => count($taskIds),
        ]);

        $send = $this->deliver($invitationId, $token, MailTemplate::INVITATION);
        if (!$send['ok']) {
            return [
                'ok' => false,
                'invitation_id' => $invitationId,
                'error' => $send['error'] !== '' ? $send['error'] : 'The invitation was saved but the email could not be sent.',
            ];
        }

        return ['ok' => true, 'invitation_id' => $invitationId];
    }

    /**
     * @return array{ok: bool, error: string}
     */
    public function resend(int $id): array
    {
        $row = $this->invitations->findDetailed($id);
        if ($row === null) {
            return ['ok' => false, 'error' => 'Invitation not found.'];
        }

        $status = $this->invitations->effectiveStatus($row);
        if (!in_array($status, UserInvitation::OPEN_STATUSES, true) && $status !== UserInvitation::STATUS_EXPIRED) {
            return ['ok' => false, 'error' => 'Only pending, sent or expired invitations can be resent.'];
        }

        if ($this->recentlySent($row, 60)) {
            return ['ok' => false, 'error' => 'Please wait a minute before resending this invitation.'];
        }

        $days = SmtpSettings::inviteExpiryDays();
        $token = UserInvitation::generateToken();
        $expiresAt = gmdate('Y-m-d H:i:s', time() + ($days * 86400));
        $this->invitations->rotateToken($id, UserInvitation::hashToken($token), $expiresAt);

        LoggerHelper::logEvent('invitation.resent', LoggerHelper::MODULE_INVITE, $id, ['status' => $status], ['status' => UserInvitation::STATUS_PENDING]);

        return $this->deliver($id, $token, MailTemplate::INVITATION_RESENT);
    }

    /**
     * @return array{ok: bool, error: string}
     */
    public function cancel(int $id): array
    {
        $row = $this->invitations->find($id);
        if ($row === null) {
            return ['ok' => false, 'error' => 'Invitation not found.'];
        }
        $status = $this->invitations->effectiveStatus($row);
        if (!in_array($status, UserInvitation::OPEN_STATUSES, true) && $status !== UserInvitation::STATUS_EXPIRED) {
            return ['ok' => false, 'error' => 'This invitation cannot be cancelled.'];
        }

        $this->invitations->cancel($id);
        LoggerHelper::logEvent('invitation.cancelled', LoggerHelper::MODULE_INVITE, $id, ['status' => $status], ['status' => UserInvitation::STATUS_CANCELLED]);

        return ['ok' => true, 'error' => ''];
    }

    /**
     * @return array{ok: bool, error: string, user_id?: int}
     */
    public function accept(string $token, string $password): array
    {
        $row = $this->invitations->findByToken($token);
        if ($row === null) {
            return ['ok' => false, 'error' => 'This invitation link is not valid.'];
        }

        $row = $this->invitations->attachAssignments($row);
        if (!$this->invitations->isAcceptable($row)) {
            $status = $this->invitations->effectiveStatus($row);
            $message = match ($status) {
                UserInvitation::STATUS_ACCEPTED => 'This invitation has already been used.',
                UserInvitation::STATUS_CANCELLED => 'This invitation was cancelled.',
                UserInvitation::STATUS_EXPIRED => 'This invitation has expired. Ask your administrator to resend it.',
                default => 'This invitation cannot be accepted.',
            };

            return ['ok' => false, 'error' => $message];
        }

        $email = strtolower((string) $row['email']);
        if ($this->findUserByEmail($email) !== null) {
            return ['ok' => false, 'error' => 'An account already exists for this email. Sign in instead.'];
        }

        $userId = Database::transaction(function () use ($row, $password, $email): int {
            $mustChangeCol = SchemaHelper::columnExists('users', 'must_change_password');
            $columns = 'role_id, role, name, email, password, phone, job_title, hourly_rate, timezone, status, password_changed_at';
            $values = ':role_id, :role, :name, :email, :password, :phone, :job_title, 0, :timezone, :status, UTC_TIMESTAMP()';
            $params = [
                'role_id' => (int) $row['role_id'],
                'role' => (string) $row['role'],
                'name' => (string) $row['name'],
                'email' => $email,
                'password' => password_hash($password, PASSWORD_BCRYPT, self::HASH_OPTIONS),
                'phone' => $row['phone'] ?? null,
                'job_title' => $row['job_title'] ?? null,
                'timezone' => SettingsService::systemTimezone(),
                'status' => in_array((string) ($row['account_status'] ?? 'active'), self::ACCOUNT_STATUSES, true)
                    ? (string) $row['account_status']
                    : 'active',
            ];
            if ($mustChangeCol) {
                $columns .= ', must_change_password';
                $values .= ', 0';
            }
            Database::execute('INSERT INTO users (' . $columns . ') VALUES (' . $values . ')', $params);
            $userId = Database::lastInsertId();

            $this->applyAssignments(
                $userId,
                array_map(static fn (array $p): int => (int) $p['id'], $row['projects'] ?? []),
                array_map(static fn (array $t): int => (int) $t['id'], $row['tasks'] ?? []),
                array_map(static fn (array $t): int => (int) $t['id'], $row['teams'] ?? [])
            );

            $this->invitations->markAccepted((int) $row['id'], $userId);

            return $userId;
        });

        LoggerHelper::logEvent('invitation.accepted', LoggerHelper::MODULE_INVITE, (int) $row['id'], ['status' => $row['status']], [
            'status' => UserInvitation::STATUS_ACCEPTED,
            'user_id' => $userId,
        ]);
        LoggerHelper::logEvent('user.created', LoggerHelper::MODULE_USER, $userId, null, [
            'name' => (string) $row['name'],
            'email' => $email,
            'role' => (string) $row['role'],
            'via' => 'invitation',
        ]);

        $this->notifyWelcome((string) $row['name'], $email);

        return ['ok' => true, 'error' => '', 'user_id' => $userId];
    }

    /**
     * @param array<string, mixed> $invitation
     * @return array<string, string>
     */
    public function templateVars(array $invitation, string $token = ''): array
    {
        $projects = array_map(static fn (array $p): string => (string) $p['name'], $invitation['projects'] ?? []);
        $tasks = array_map(static fn (array $t): string => (string) $t['name'], $invitation['tasks'] ?? []);
        $teams = array_map(static fn (array $t): string => (string) $t['name'], $invitation['teams'] ?? []);
        $url = $token !== '' ? FormatHelper::absoluteUrl('/accept-invitation?token=' . rawurlencode($token)) : '';
        $logoFile = BrandingHelper::logoFile();
        $logoUrl = $logoFile !== '' ? FormatHelper::absoluteUrl('/uploads/branding/' . $logoFile) : '';
        $company = SettingsService::appName();

        return [
            'user_name' => (string) ($invitation['name'] ?? ''),
            'email' => (string) ($invitation['email'] ?? ''),
            'role' => (string) ($invitation['role_name'] ?? $invitation['role'] ?? ''),
            'team' => $teams === [] ? 'Not assigned' : implode(', ', $teams),
            'projects' => $projects === [] ? 'None yet' : "• " . implode("\n• ", $projects),
            'tasks' => $tasks === [] ? 'None yet' : "• " . implode("\n• ", $tasks),
            'projects_html' => $projects === [] ? 'None yet' : '• ' . implode('<br>• ', array_map(
                static fn (string $n): string => htmlspecialchars($n, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
                $projects
            )),
            'tasks_html' => $tasks === [] ? 'None yet' : '• ' . implode('<br>• ', array_map(
                static fn (string $n): string => htmlspecialchars($n, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
                $tasks
            )),
            'invited_by' => (string) ($invitation['invited_by_name'] ?? 'Your administrator'),
            'invitation_url' => $url,
            'expiry_date' => FormatHelper::datetime((string) ($invitation['expires_at'] ?? ''), 'M j, Y H:i T'),
            'expiry_phrase' => self::expiryPhrase((string) ($invitation['expires_at'] ?? '')),
            'logo_html' => $logoUrl !== ''
                ? '<img src="' . htmlspecialchars($logoUrl, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '" alt="' . htmlspecialchars($company, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '" height="44" style="display:block;height:44px;width:auto;max-width:240px;border:0;outline:none;">'
                : self::fallbackLogoHtml($company),
            'company_name' => $company,
            'login_url' => FormatHelper::absoluteUrl('/login'),
        ];
    }

    /** Email-safe logo stand-in (brand-coloured tile with the app's first letter) when no logo is uploaded. */
    private static function fallbackLogoHtml(string $company): string
    {
        $color = BrandingHelper::colorOrDefault();
        $on = BrandingHelper::textOn($color);
        $letter = mb_strtoupper(mb_substr(trim($company) !== '' ? trim($company) : 'T', 0, 1, 'UTF-8'), 'UTF-8');

        return '<table role="presentation" cellpadding="0" cellspacing="0" align="left"><tr>'
            . '<td width="48" height="48" align="center" valign="middle" style="width:48px;height:48px;border-radius:10px;background:' . htmlspecialchars($color, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
            . ';color:' . htmlspecialchars($on, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')
            . ';font-size:24px;font-weight:700;font-family:Arial,sans-serif;">' . htmlspecialchars($letter, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</td>'
            . '<td style="padding-left:12px;font-size:24px;font-weight:500;color:#000000;font-family:Roboto,Arial,sans-serif;">' . htmlspecialchars($company, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') . '</td>'
            . '</tr></table>';
    }

    private function expiryPhrase(string $expiresAt): string
    {
        $expires = strtotime($expiresAt);
        if ($expires === false) {
            $days = SmtpSettings::inviteExpiryDays();
        } else {
            $days = max(1, (int) ceil(($expires - time()) / 86400));
        }

        return match (true) {
            $days === 14 => 'two weeks',
            $days === 7 => 'one week',
            $days === 1 => '1 day',
            default => $days . ' days',
        };
    }

    /**
     * @param array<string, mixed> $existing
     * @param array<string, mixed> $data
     * @param list<int> $projectIds
     * @param list<int> $taskIds
     * @param list<int> $teamIds
     * @return array{ok: bool, existing?: array<string, mixed>, error?: string, assigned?: bool}
     */
    private function assignExisting(array $existing, array $data, array $projectIds, array $taskIds, array $teamIds): array
    {
        $userId = (int) $existing['id'];
        $roleName = (string) ($data['role'] ?? $existing['role']);
        $roleChanged = $roleName !== (string) $existing['role'];

        if ($roleChanged) {
            if (!$this->canGrantRole($roleName) || !PermissionHelper::has('roles.manage')) {
                return ['ok' => false, 'error' => 'You cannot change this user\'s role. Project and task assignments were not applied.'];
            }
            $roleId = $this->roleId($roleName);
            Database::execute(
                'UPDATE users SET role_id = :role_id, role = :role WHERE id = :id',
                ['role_id' => $roleId, 'role' => $roleName, 'id' => $userId]
            );
            LoggerHelper::logEvent('user.role_assigned', LoggerHelper::MODULE_USER, $userId, ['role' => (string) $existing['role']], ['role' => $roleName]);
        }

        $projectIds = $this->sanitizeIds($projectIds, 'projects');
        $taskIds = $this->sanitizeTaskIds($taskIds, $projectIds);
        $teamIds = $this->sanitizeIds($teamIds, 'teams');
        $this->applyAssignments($userId, $projectIds, $taskIds, $teamIds);

        LoggerHelper::logEvent('invitation.existing_assigned', LoggerHelper::MODULE_INVITE, $userId, null, [
            'projects' => count($projectIds),
            'tasks' => count($taskIds),
        ]);

        if ((string) $existing['status'] === 'active') {
            $this->notifyAssignment($existing, $roleName, $projectIds, $taskIds, $teamIds);
        }

        return ['ok' => true, 'assigned' => true];
    }

    /**
     * @param list<int> $projectIds
     * @param list<int> $taskIds
     * @param list<int> $teamIds
     */
    private function applyAssignments(int $userId, array $projectIds, array $taskIds, array $teamIds): void
    {
        $members = new ProjectMember();
        foreach ($projectIds as $projectId) {
            $members->assign($projectId, $userId, ProjectMember::ROLE_MEMBER);
            LoggerHelper::logEvent('project.member_assigned', LoggerHelper::MODULE_PROJECT, $projectId, null, ['user_id' => $userId]);
        }

        if ($taskIds !== [] && Task::installed()) {
            $taskModel = new Task();
            foreach ($taskIds as $taskId) {
                $task = $taskModel->find($taskId);
                if ($task === null) {
                    continue;
                }
                $projectId = (int) $task['project_id'];
                if (!$members->isMember($projectId, $userId)) {
                    $members->assign($projectId, $userId, ProjectMember::ROLE_MEMBER);
                }
                $allowed = $members->userIdsForProject($projectId);
                $current = Database::fetchAll(
                    'SELECT user_id FROM task_assignees WHERE task_id = :id',
                    ['id' => $taskId]
                );
                $ids = array_map(static fn (array $r): int => (int) $r['user_id'], $current);
                $ids[] = $userId;
                $taskModel->syncAssignees($taskId, $ids, $allowed);
                LoggerHelper::taskAssigned($taskId, $userId, (string) $task['name'], $projectId);
            }
        }

        if ($teamIds !== [] && SchemaHelper::tableExists('team_members')) {
            $groups = new TeamGroup();
            foreach ($teamIds as $teamId) {
                $team = $groups->find($teamId);
                if ($team === null) {
                    continue;
                }
                Database::execute(
                    'INSERT IGNORE INTO team_members (team_id, user_id, created_at) VALUES (:t, :u, UTC_TIMESTAMP())',
                    ['t' => $teamId, 'u' => $userId]
                );
                $projectId = (int) $team['project_id'];
                if (!$members->isMember($projectId, $userId)) {
                    $members->assign($projectId, $userId, ProjectMember::ROLE_MEMBER);
                }
                LoggerHelper::logEvent('team.member_assigned', LoggerHelper::MODULE_USER, $teamId, null, ['user_id' => $userId]);
            }
        }
    }

    /**
     * @return array{ok: bool, error: string}
     */
    private function deliver(int $invitationId, string $token, string $template): array
    {
        $row = $this->invitations->findDetailed($invitationId);
        if ($row === null) {
            return ['ok' => false, 'error' => 'Invitation not found.'];
        }

        if (!SmtpSettings::enabled()) {
            return ['ok' => false, 'error' => 'SMTP is turned off. Enable it in System settings, then resend.'];
        }

        $result = Mailer::sendTemplate((string) $row['email'], $template, $this->templateVars($row, $token));
        if ($result['ok']) {
            $this->invitations->markSent($invitationId);
            LoggerHelper::logEvent('invitation.sent', LoggerHelper::MODULE_INVITE, $invitationId, null, [
                'email_domain' => $this->emailDomain((string) $row['email']),
            ]);
        }

        return $result;
    }

    /** @param array<string, mixed> $row */
    private function recentlySent(array $row, int $seconds): bool
    {
        $last = (string) ($row['last_sent_at'] ?? '');
        if ($last === '') {
            return false;
        }
        $ts = strtotime($last . ' UTC');

        return $ts !== false && (time() - $ts) < $seconds;
    }

    /** @return array<string, mixed>|null */
    private function findUserByEmail(string $email): ?array
    {
        return Database::fetchOne(
            'SELECT u.id, u.name, u.email, r.name AS role, r.display_name AS role_name, u.status
             FROM users u INNER JOIN roles r ON r.id = u.role_id
             WHERE u.email = :email LIMIT 1',
            ['email' => $email]
        );
    }

    private function roleId(string $role): int
    {
        $id = (int) Database::fetchValue('SELECT id FROM roles WHERE name = :name LIMIT 1', ['name' => $role]);
        if ($id < 1) {
            throw new RuntimeException('Unknown role.');
        }

        return $id;
    }

    /**
     * @param list<int> $ids
     * @return list<int>
     */
    private function sanitizeIds(array $ids, string $table): array
    {
        $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn (int $id): bool => $id > 0)));
        if ($ids === [] || !SchemaHelper::tableExists($table)) {
            return [];
        }

        $params = [];
        $placeholders = [];
        foreach ($ids as $i => $id) {
            $key = 'id' . $i;
            $placeholders[] = ':' . $key;
            $params[$key] = $id;
        }
        $rows = Database::fetchAll(
            "SELECT id FROM `{$table}` WHERE id IN (" . implode(', ', $placeholders) . ')',
            $params
        );

        return array_map(static fn (array $r): int => (int) $r['id'], $rows);
    }

    /**
     * @param list<int> $taskIds
     * @param list<int> $projectIds
     * @return list<int>
     */
    private function sanitizeTaskIds(array $taskIds, array $projectIds): array
    {
        $taskIds = $this->sanitizeIds($taskIds, 'tasks');
        if ($taskIds === [] || !Task::installed()) {
            return [];
        }

        $params = [];
        $placeholders = [];
        foreach ($taskIds as $i => $id) {
            $key = 't' . $i;
            $placeholders[] = ':' . $key;
            $params[$key] = $id;
        }
        $sql = 'SELECT id, project_id FROM tasks WHERE id IN (' . implode(', ', $placeholders) . ')';
        $rows = Database::fetchAll($sql, $params);
        $allowedProjects = array_fill_keys($projectIds, true);
        $out = [];
        foreach ($rows as $row) {
            $pid = (int) $row['project_id'];
            if ($projectIds === [] || isset($allowedProjects[$pid])) {
                $out[] = (int) $row['id'];
            }
        }

        return $out;
    }

    private function emailDomain(string $email): string
    {
        $pos = strrpos($email, '@');

        return $pos === false ? '' : substr($email, $pos + 1);
    }

    private function notifyWelcome(string $name, string $email): void
    {
        try {
            Mailer::sendTemplate($email, MailTemplate::WELCOME, [
                'user_name' => $name,
                'email' => $email,
                'login_url' => FormatHelper::absoluteUrl('/login'),
                'company_name' => SettingsService::appName(),
            ]);
        } catch (Throwable $e) {
            LoggerHelper::debug('Welcome email skipped', ['error' => $e->getMessage()]);
        }
    }

    /**
     * @param array<string, mixed> $user
     * @param list<int> $projectIds
     * @param list<int> $taskIds
     * @param list<int> $teamIds
     */
    private function notifyAssignment(array $user, string $roleName, array $projectIds, array $taskIds, array $teamIds): void
    {
        $roleLabel = (string) Database::fetchValue('SELECT display_name FROM roles WHERE name = :n LIMIT 1', ['n' => $roleName]);
        $projects = [];
        if ($projectIds !== []) {
            $params = [];
            $ph = [];
            foreach ($projectIds as $i => $id) {
                $ph[] = ':p' . $i;
                $params['p' . $i] = $id;
            }
            $projects = array_column(Database::fetchAll('SELECT name FROM projects WHERE id IN (' . implode(',', $ph) . ')', $params), 'name');
        }
        $tasks = [];
        if ($taskIds !== []) {
            $params = [];
            $ph = [];
            foreach ($taskIds as $i => $id) {
                $ph[] = ':t' . $i;
                $params['t' . $i] = $id;
            }
            $tasks = array_column(Database::fetchAll('SELECT name FROM tasks WHERE id IN (' . implode(',', $ph) . ')', $params), 'name');
        }

        try {
            Mailer::sendTemplate((string) $user['email'], MailTemplate::ASSIGNMENT, [
                'user_name' => (string) $user['name'],
                'email' => (string) $user['email'],
                'role' => $roleLabel !== '' ? $roleLabel : $roleName,
                'team' => 'Unchanged',
                'projects' => $projects === [] ? 'Unchanged' : "• " . implode("\n• ", $projects),
                'tasks' => $tasks === [] ? 'Unchanged' : "• " . implode("\n• ", $tasks),
                'projects_html' => $projects === [] ? 'Unchanged' : '• ' . implode('<br>• ', array_map(
                    static fn (string $n): string => htmlspecialchars($n, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
                    $projects
                )),
                'tasks_html' => $tasks === [] ? 'Unchanged' : '• ' . implode('<br>• ', array_map(
                    static fn (string $n): string => htmlspecialchars($n, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
                    $tasks
                )),
                'invited_by' => (string) (AuthHelper::user()['name'] ?? 'An administrator'),
                'company_name' => SettingsService::appName(),
            ]);
        } catch (Throwable $e) {
            LoggerHelper::debug('Assignment email skipped', ['error' => $e->getMessage()]);
        }
    }
}
