<?php
/**
 * SMTP configuration stored in `settings` (group "mail").
 *
 * The password is encrypted at rest. Views only receive a boolean "is set"
 * flag — never the secret itself.
 */

declare(strict_types=1);

final class SmtpSettings
{
    public const ENCRYPTIONS = ['tls', 'ssl', 'none'];

    public const DEFAULTS = [
        'smtp_enabled' => '0',
        'smtp_host' => '',
        'smtp_port' => '587',
        'smtp_username' => '',
        'smtp_password' => '',
        'smtp_encryption' => 'tls',
        'smtp_from_name' => '',
        'smtp_from_email' => '',
        'smtp_reply_to' => '',
        'invite_expiry_days' => '7',
    ];

    private const META = [
        'smtp_enabled' => ['type' => 'bool', 'group' => 'mail'],
        'smtp_host' => ['type' => 'string', 'group' => 'mail'],
        'smtp_port' => ['type' => 'int', 'group' => 'mail'],
        'smtp_username' => ['type' => 'string', 'group' => 'mail'],
        'smtp_password' => ['type' => 'string', 'group' => 'mail'],
        'smtp_encryption' => ['type' => 'string', 'group' => 'mail'],
        'smtp_from_name' => ['type' => 'string', 'group' => 'mail'],
        'smtp_from_email' => ['type' => 'string', 'group' => 'mail'],
        'smtp_reply_to' => ['type' => 'string', 'group' => 'mail'],
        'invite_expiry_days' => ['type' => 'int', 'group' => 'mail'],
    ];

    /** @var array<string, string>|null */
    private static ?array $cache = null;

    /** @return array<string, string> */
    public static function all(): array
    {
        if (self::$cache !== null) {
            return self::$cache;
        }

        $out = self::DEFAULTS;
        try {
            $keys = array_keys(self::DEFAULTS);
            $rows = Database::fetchAll(
                'SELECT setting_key, setting_value FROM settings WHERE setting_key IN (' .
                implode(', ', array_fill(0, count($keys), '?')) . ')',
                $keys
            );
            foreach ($rows as $row) {
                $key = (string) $row['setting_key'];
                if (array_key_exists($key, $out)) {
                    $out[$key] = (string) ($row['setting_value'] ?? '');
                }
            }
        } catch (Throwable $e) {
            LoggerHelper::debug('SMTP settings read failed', ['error' => $e->getMessage()]);
        }

        return self::$cache = $out;
    }

    /**
     * Public view of SMTP settings. Password is never included.
     *
     * @return array<string, mixed>
     */
    public static function public(): array
    {
        $all = self::all();
        unset($all['smtp_password']);
        $all['smtp_password_set'] = self::password() !== '';
        $all['configured'] = self::isConfigured();
        $all['gmail_host'] = self::gmailHost();
        $all['delivery_hints'] = self::deliveryHints();

        return $all;
    }

    public static function get(string $key, string $default = ''): string
    {
        $all = self::all();

        return array_key_exists($key, $all) ? $all[$key] : $default;
    }

    public static function password(): string
    {
        $stored = self::get('smtp_password', '');
        if ($stored === '') {
            return '';
        }

        if (CryptoHelper::isEncrypted($stored)) {
            $plain = CryptoHelper::decrypt($stored);

            return is_string($plain) ? $plain : '';
        }

        return '';
    }

    public static function isConfigured(): bool
    {
        $host = trim(self::get('smtp_host'));
        $from = trim(self::get('smtp_from_email'));

        return $host !== '' && $from !== '' && filter_var($from, FILTER_VALIDATE_EMAIL) !== false;
    }

    public static function enabled(): bool
    {
        return in_array(strtolower(self::get('smtp_enabled', '0')), ['1', 'true', 'yes', 'on'], true)
            && self::isConfigured();
    }

    public static function fromName(): string
    {
        $name = trim(self::get('smtp_from_name'));
        if ($name !== '') {
            return $name;
        }

        return SettingsService::appName();
    }

    public static function fromEmail(): string
    {
        $email = trim(self::get('smtp_from_email'));
        if ($email !== '') {
            return $email;
        }

        return SettingsService::systemString('company_email', 'hello@timetrack.local');
    }

    public static function replyTo(): string
    {
        $reply = trim(self::get('smtp_reply_to'));

        return $reply !== '' ? $reply : self::fromEmail();
    }

    public static function inviteExpiryDays(): int
    {
        $days = (int) self::get('invite_expiry_days', '7');

        return max(1, min(90, $days));
    }

    public static function gmailHost(): bool
    {
        $host = strtolower(trim(self::get('smtp_host')));

        return $host === 'smtp.gmail.com' || $host === 'smtp.googlemail.com';
    }

    public static function gmailAddress(string $email): bool
    {
        $domain = strtolower(ltrim((string) strrchr(trim($email), '@'), '@'));

        return in_array($domain, ['gmail.com', 'googlemail.com'], true);
    }

    /**
     * Inbox pitfalls. Never includes secrets.
     *
     * @return list<string>
     */
    public static function deliveryHints(): array
    {
        $hints = [];
        $from = strtolower(trim(self::fromEmail()));
        $user = strtolower(trim(self::get('smtp_username')));
        $enc = strtolower(self::get('smtp_encryption', 'tls'));
        $port = (int) self::get('smtp_port', '587');
        $fromGmail = self::gmailAddress($from);
        $hostGmail = self::gmailHost();
        $passwordSet = self::password() !== '';

        if ($fromGmail && !$hostGmail) {
            $hints[] = 'From is a Gmail address, but the SMTP host is not smtp.gmail.com. Gmail usually files those messages as Spam or drops them. Use smtp.gmail.com, port 587, TLS, and an App Password, with From set to that same Gmail address.';
        }

        if ($hostGmail) {
            if ($user === '' || !$passwordSet) {
                $hints[] = 'Gmail requires the full Gmail address as username and a 16-character App Password (Google Account → Security → 2-Step Verification → App passwords). A normal Google password is rejected.';
            }
            if ($fromGmail && $user !== '' && $user !== $from) {
                $hints[] = 'Gmail From should match the SMTP username, or a Send-as alias of that account. A mismatch often lands in Spam.';
            }
            if ($port === 587 && $enc !== 'tls') {
                $hints[] = 'Gmail on port 587 needs encryption TLS.';
            } elseif ($port === 465 && $enc !== 'ssl') {
                $hints[] = 'Gmail on port 465 needs encryption SSL.';
            } elseif (!in_array($port, [587, 465], true)) {
                $hints[] = 'Gmail SMTP uses port 587 (TLS) or 465 (SSL).';
            }
        }

        return $hints;
    }

    /**
     * @param array<string, string> $values
     */
    public static function save(array $values, bool $replacePassword): void
    {
        foreach ($values as $key => $value) {
            if (!array_key_exists($key, self::DEFAULTS)) {
                continue;
            }
            if ($key === 'smtp_password' && !$replacePassword) {
                continue;
            }
            self::put($key, $value);
        }
        self::$cache = null;
    }

    public static function put(string $key, string $value): void
    {
        if (!isset(self::META[$key])) {
            throw new InvalidArgumentException('Unknown SMTP setting.');
        }

        if ($key === 'smtp_password') {
            if ($value === '') {
                $value = '';
            } else {
                $encrypted = CryptoHelper::encrypt($value);
                if ($encrypted === null) {
                    throw new RuntimeException('Could not store the SMTP password. Configure APP_KEY first.');
                }
                $value = $encrypted;
            }
        }

        $meta = self::META[$key];
        Database::execute(
            'INSERT INTO settings (setting_key, setting_value, setting_type, setting_group, description)
             VALUES (:key, :value, :type, :grp, NULL)
             ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value), updated_at = UTC_TIMESTAMP()',
            [
                'key' => $key,
                'value' => $value,
                'type' => $meta['type'],
                'grp' => $meta['group'],
            ]
        );
        self::$cache = null;
    }

    public static function clearCache(): void
    {
        self::$cache = null;
    }
}
